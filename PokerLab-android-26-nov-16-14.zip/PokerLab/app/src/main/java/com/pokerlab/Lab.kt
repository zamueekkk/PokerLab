package com.pokerlab

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class LabData {
    var n = 0
    var d = Desc(0, 0.0, 0.0, 0.0, 0.0)
    var m100 = 0.0; var se100 = 0.0
    var boot = Pair(Double.NaN, Double.NaN); var nT = 0
    val cx = ArrayList<Double>(); val cm = ArrayList<Double>(); val clo = ArrayList<Double>(); val chi = ArrayList<Double>()
    var dd = Desc(0, 0.0, 0.0, 0.0, 0.0); var jbp = 1.0
    var histL: List<String> = emptyList(); var histV: List<Double> = emptyList()
    var qqT = DoubleArray(0); var qqS = DoubleArray(0)
    var acfV = DoubleArray(0); var acfBand = 0.0
    var cuV: List<Double> = emptyList(); var cuB: List<Double> = emptyList()
    val vm = ArrayList<Double>(); val vlo = ArrayList<Double>(); val vhi = ArrayList<Double>()
    val pm = ArrayList<Double>(); val plo = ArrayList<Double>(); val phi = ArrayList<Double>()
    var shrV: Pair<List<Shr>, Double>? = null; var shrP: Pair<List<Shr>, Double>? = null
    var cal: List<CalPt> = emptyList()
    var aiN = 0; var aiMean = 0.0; var aiSd = 0.0; var aiT = 0.0; var aiP = 1.0
    var aiHL: List<String> = emptyList(); var aiHV: List<Double> = emptyList()
    var chi2 = 0.0; var chiDf = 168.0; var chiP = 1.0; var chiRes: Map<String, Double> = emptyMap(); var chiN = 0; var chiMinE = 0.0
    var ent: List<Pair<String, Double>> = emptyList()
}

fun computeLab(hs: List<Hand>): LabData {
    val L = LabData()
    val n = hs.size
    L.n = n
    if (n < 30) return L
    val x = DoubleArray(n) { hs[it].nb }
    L.d = describe(x)
    L.m100 = L.d.mean * 100
    L.se100 = 100 * L.d.sd / sqrt(n.toDouble())

    // torneos (unidad de remuestreo)
    val tg = LinkedHashMap<String, ArrayList<Hand>>()
    for (h in hs) tg.getOrPut(h.tid) { ArrayList() }.add(h)
    val tl = tg.values.sortedBy { it.first().ts }
    val ts = DoubleArray(tl.size) { i -> tl[i].sumOf { it.nb } }
    val tc = DoubleArray(tl.size) { i -> tl[i].size.toDouble() }
    L.boot = clusterBoot(ts, tc)
    L.nT = tl.size
    val lag = min(10, tl.size / 3)
    if (lag >= 2) { L.acfV = acf(ts, lag); L.acfBand = 1.96 / sqrt(tl.size.toDouble()) }

    // convergencia de winrate, VPIP y PFR
    val step = max(1, n / 120)
    var mean = 0.0; var m2 = 0.0; var sv = 0.0; var sp = 0.0
    for (i in 0 until n) {
        val v = x[i]; val k = i + 1
        val dl = v - mean; mean += dl / k; m2 += dl * (v - mean)
        sv += hs[i].vpip; sp += hs[i].pfr
        if (k >= 200 && (k % step == 0 || k == n)) {
            val se = 100 * sqrt(m2 / (k - 1)) / sqrt(k.toDouble())
            L.cx.add(k.toDouble()); L.cm.add(mean * 100); L.clo.add(mean * 100 - 1.96 * se); L.chi.add(mean * 100 + 1.96 * se)
            val wv = wl(sv, k.toDouble()); val wp = wl(sp, k.toDouble())
            L.vm.add(100 * sv / k); L.vlo.add(wv.first); L.vhi.add(wv.second)
            L.pm.add(100 * sp / k); L.plo.add(wp.first); L.phi.add(wp.second)
        }
    }

    // forma de la distribución (manos con flop)
    val sw = hs.filter { it.saw == 1 }.map { it.nb }.toDoubleArray()
    if (sw.size >= 30) {
        L.dd = describe(sw); L.jbp = jarqueBeraP(L.dd)
        val sorted = sw.sortedArray()
        val m = L.dd.mean; val sd = if (L.dd.sd > 0) L.dd.sd else 1.0
        val np = min(300, sorted.size)
        L.qqT = DoubleArray(np) { normInv((it + 0.5) / np) }
        L.qqS = DoubleArray(np) { val idx = min(sorted.size - 1, ((it + 0.5) / np * sorted.size).toInt()); (sorted[idx] - m) / sd }
        val cnt = DoubleArray(20)
        for (v in sw) { val b = floor((v + 50) / 5).toInt().coerceIn(0, 19); cnt[b]++ }
        L.histL = List(20) { (-50 + 5 * it).toString() }
        L.histV = cnt.map { 100 * it / sw.size }
    }

    // CUSUM (deriva del estilo y del resultado)
    val mv = hs.sumOf { it.vpip }.toDouble() / n
    var c1 = 0.0; var c2 = 0.0
    val cv = ArrayList<Double>(n); val cb = ArrayList<Double>(n)
    for (i in 0 until n) { c1 += hs[i].vpip - mv; c2 += x[i] - L.d.mean; cv.add(c1); cb.add(c2) }
    L.cuV = ds(cv); L.cuB = ds(cb)

    // Bayes empírico y entropía por posición
    val pl = PO.filter { p -> hs.count { it.pos == p } >= 20 }
    if (pl.size >= 2) {
        val ns = pl.map { p -> hs.count { it.pos == p }.toDouble() }
        L.shrV = shrink(pl, pl.map { p -> hs.filter { it.pos == p }.sumOf { it.vpip }.toDouble() }, ns)
        L.shrP = shrink(pl, pl.map { p -> hs.filter { it.pos == p }.sumOf { it.pfr }.toDouble() }, ns)
    }
    L.ent = pl.map { p ->
        val z = hs.filter { it.pos == p }
        val cnt = listOf('f', 'x', 'c', 'r').map { a -> z.count { it.pa == a }.toDouble() }
        val tot = cnt.sum()
        var h = 0.0
        for (c in cnt) if (c > 0) { val q = c / tot; h -= q * ln(q) / ln(2.0) }
        p to h
    }

    // suerte en all-ins: t pareada y calibración
    val ai = hs.filter { it.eq != null }
    if (ai.size >= 3) {
        val dv = DoubleArray(ai.size) { ai[it].nb - ai[it].eq!!.ev }
        val dsc = describe(dv)
        L.aiN = ai.size; L.aiMean = dsc.mean; L.aiSd = dsc.sd
        L.aiT = if (dsc.sd > 0) dsc.mean / (dsc.sd / sqrt(ai.size.toDouble())) else 0.0
        L.aiP = 2 * (1 - normCdf(abs(L.aiT)))
        val hc = DoubleArray(20)
        for (v in dv) { val b = floor((v + 100) / 10).toInt().coerceIn(0, 19); hc[b]++ }
        L.aiHL = List(20) { (-100 + 10 * it).toString() }
        L.aiHV = hc.map { 100 * it / dv.size }
        val cal = ArrayList<CalPt>()
        for (b in 0 until 10) {
            val z = ai.filter { val e = it.eq!!.e; e >= b / 10.0 && (e < (b + 1) / 10.0 || (b == 9 && e <= 1.0)) }
            if (z.size >= 4) {
                val w = z.count { it.nb > 0 }
                val ci = wl(w.toDouble(), z.size.toDouble())
                cal.add(CalPt(z.sumOf { it.eq!!.e } / z.size, w.toDouble() / z.size, ci.first / 100, ci.second / 100, z.size))
            }
        }
        L.cal = cal
    }

    // uniformidad de las cartas repartidas (chi-cuadrado)
    val cnt = HashMap<String, Int>(); var nc = 0
    for (h in hs) { val c = h.cards ?: continue; val k = hk(c); cnt[k] = (cnt[k] ?: 0) + 1; nc++ }
    if (nc >= 500) {
        var chi = 0.0; var minE = 1e9
        val res = HashMap<String, Double>()
        for (z in GRID_CLASSES) {
            val e = nc * clsSizeOf(z) / 1326.0
            val o = (cnt[z] ?: 0).toDouble()
            chi += (o - e) * (o - e) / e
            res[z] = (o - e) / sqrt(e)
            minE = min(minE, e)
        }
        L.chi2 = chi; L.chiP = chi2Sf(chi, 168.0); L.chiRes = res; L.chiN = nc; L.chiMinE = minE
    }
    return L
}

@Composable
private fun Formula(t: String) {
    Text(
        t, color = PC.Mu, fontSize = 11.sp, fontFamily = FontFamily.Monospace, lineHeight = 15.sp,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color.White.copy(alpha = .04f)).padding(8.dp)
    )
}

@Composable
fun TabLab(e: Env) {
    val hs = e.hs; val vm = e.vm
    val ver = vm.evVer
    val Ld by produceState<LabData?>(null, hs, ver) { value = withContext(Dispatchers.Default) { derived(hs, ver).lab } }
    var horizon by remember { mutableIntStateOf(5000) }
    val fan by produceState<Pair<List<Double>, List<DoubleArray>>?>(null, hs, horizon) {
        value = null
        value = withContext(Dispatchers.Default) {
            val x = DoubleArray(hs.size) { hs[it].nb }
            if (x.size < 30) null else {
                val block = horizon / 50
                Pair((0..50).map { it * block.toDouble() }, fanSim(x, horizon, block, 1200))
            }
        }
    }
    val L = Ld
    if (L == null) { Muted("Calculando el laboratorio estadístico…"); return }
    if (L.n < 30) { Note("El laboratorio necesita al menos 30 manos en el filtro actual."); return }
    val d = L.d
    val mu = d.mean; val sg = d.sd
    val needN = if (sg > 0) ceil((196 * sg / 5).let { it * it }).toLong() else 0L
    val detN = if (mu > 0) ceil((1.645 * sg / mu).let { it * it }).toLong() else 0L
    val pPos = normCdf(L.m100 / L.se100)

    Note("Laboratorio estadístico: cada análisis indica el método, sus supuestos y cómo leerlo. Todo se calcula en tu teléfono con los datos del filtro actual.")

    // 1. inferencia del winrate
    Sec("1 · Inferencia del winrate (bb/100)") {
        Kpis(
            listOf(
                kp("bb/100", f1(L.m100), "± " + f1(1.96 * L.se100) + " · IC95% normal", toneOf(L.m100)),
                kp("IC95% bootstrap", if (L.boot.first.isNaN()) "–" else f1(L.boot.first) + " a " + f1(L.boot.second), "remuestreo de ${L.nT} torneos"),
                kp("P(winrate > 0)", f1(100 * pPos) + "%", "Φ(x̄ / EE), prior plano"),
                kp("Desv. típica / 100 manos", f1(sg * 10) + " bb", "σ·√100"),
                kp("Manos para IC ±5", if (needN > 0) fmtN(needN) else "–", "n = (1.96·100·σ/5)²"),
                kp("Manos para probar μ>0", if (detN > 0) fmtN(detN) else "–", "95% con tu winrate actual")
            )
        )
        Spacer(Modifier.height(10.dp))
        Muted("Convergencia: media acumulada con banda de confianza al 95%; si la banda aún contiene 0, los datos no bastan para afirmar que ganas.")
        FunnelChart(L.cx, L.cm, L.clo, L.chi, unit = " bb/100")
        Formula("EE = s / √n        IC95% = x̄ ± 1.96·EE\nP(μ>0) ≈ Φ(x̄/EE)\nBootstrap por clústeres: remuestrea TORNEOS (no manos) 2000 veces y toma percentiles 2.5–97.5; respeta la correlación entre manos de un mismo torneo.")
    }

    // 2. forma de la distribución
    Sec("2 · Forma de la distribución por mano (manos con flop)") {
        Kpis(
            listOf(
                kp("Manos analizadas", fmtN(L.dd.n)), kp("Asimetría γ₁", f2(L.dd.skew), if (L.dd.skew > 0) "cola derecha (grandes botes)" else "cola izquierda"),
                kp("Curtosis exceso γ₂", f1(L.dd.kurt), "0 = normal"), kp("Jarque–Bera p", fmtP(L.jbp), if (L.jbp < 0.05) "rechaza normalidad" else "compatible con normal")
            )
        )
        Spacer(Modifier.height(10.dp))
        Muted("Histograma (% de manos con flop por resultado en bb; los extremos acumulan colas):")
        BarChart(L.histL, L.histV, true)
        Spacer(Modifier.height(8.dp))
        Muted("Gráfico Q-Q frente a la normal: si los puntos se alejan de la diagonal en los extremos, las colas son pesadas.")
        QQPlot(L.qqT, L.qqS)
        Formula("γ₁ = m₃/m₂^1.5     γ₂ = m₄/m₂² − 3\nJB = n/6·(γ₁² + γ₂²/4) ~ χ²(2)   →   p = e^(−JB/2)\nColas pesadas ⇒ el IC normal subestima la incertidumbre: usa el bootstrap.")
    }

    // 3. simulación y riesgo
    Sec("3 · Riesgo y simulación Monte Carlo") {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            listOf(2000, 5000, 10000, 20000).forEach { hz ->
                FilterChip(selected = horizon == hz, onClick = { horizon = hz }, label = { Text(fmtN(hz) + " manos") })
            }
        }
        Spacer(Modifier.height(8.dp))
        val f = fan
        if (f == null) Muted("Simulando 1 200 trayectorias…")
        else {
            FanChart(f.first, f.second)
            Muted("Banda clara: percentiles 5–95; banda oscura: 25–75; línea: mediana. Resultado acumulado en bb.")
            Kpis(
                listOf(
                    kp("Mediana a ${fmtN(horizon)}", f1(f.second[2].last()) + " bb", "", toneOf(f.second[2].last())),
                    kp("Percentil 5", f1(f.second[0].last()) + " bb", "mal escenario", toneOf(f.second[0].last())),
                    kp("Percentil 95", f1(f.second[4].last()) + " bb", "buen escenario", toneOf(f.second[4].last())),
                    kp("P(terminar en negativo)", if (mu > 0) f1(100 * normCdf(-mu * horizon / (sg * sqrt(horizon.toDouble())))) + "%" else "≥ 50%", "aprox. normal")
                )
            )
        }
        Spacer(Modifier.height(10.dp))
        Table(
            listOf("Bankroll (bb)", "Riesgo de ruina"),
            listOf(50, 100, 200, 500, 1000, 2000).map { b ->
                val ror = if (mu > 0) exp(-2 * mu * b / (sg * sg)) else 1.0
                listOf<Any>(b.toString(), Tone(f1(100 * min(1.0, ror)) + "%", if (ror < .05) 1 else if (ror > .3) -1 else 0))
            }, listOf(120, 140)
        )
        Formula("Trayectorias: muestreo con reemplazo de tus manos (iid).\nRiesgo de ruina (movimiento browniano con deriva):  RoR = exp(−2·μ·B / σ²)\nμ, σ² = media y varianza por mano; B = bankroll en bb.\nSupuestos: manos independientes y winrate constante; los torneos reales tienen estructura de premios, así que úsalo como cota orientativa.")
    }

    // 4. suerte en all-ins
    if (L.aiN >= 3) {
        Sec("4 · Suerte en all-ins: contraste y calibración") {
            Kpis(
                listOf(
                    kp("All-ins con EV", L.aiN.toString()), kp("Real − EV por all-in", f1(L.aiMean) + " bb", "± " + f1(1.96 * L.aiSd / sqrt(L.aiN.toDouble())), toneOf(L.aiMean)),
                    kp("t pareada", f2(L.aiT), "H₀: real = EV"), kp("p (dos colas)", fmtP(L.aiP), if (L.aiP < 0.05) "desviación significativa" else "compatible con azar")
                )
            )
            Spacer(Modifier.height(10.dp))
            Muted("Diagrama de calibración: si tu equity calculada es correcta, los puntos siguen la diagonal. Verde = el IC de Wilson contiene la predicción.")
            CalibrationPlot(L.cal)
            Spacer(Modifier.height(8.dp))
            Muted("Distribución de (resultado real − EV) por all-in, en bb:")
            BarChart(L.aiHL, L.aiHV, true)
            Formula("dᵢ = real_i − EV_i      t = d̄ / (s_d/√n) ~ t(n−1) ≈ N(0,1)\nCalibración: por tramos de equity, frecuencia observada de victoria con IC de Wilson.\nNo incluye ICM; los empates cuentan como no-ganados en la frecuencia observada.")
        }
    }

    // 5. estabilidad del estilo
    Sec("5 · Estabilidad del estilo y del resultado") {
        Muted("CUSUM de VPIP: suma acumulada de desviaciones respecto a tu media. Una pendiente sostenida indica cambio de estilo (juegas más o menos manos que antes).")
        LineChart(L.cuV, true)
        Spacer(Modifier.height(8.dp))
        Muted("CUSUM del resultado: pendiente positiva = período por encima de tu media; negativa = por debajo.")
        LineChart(L.cuB, true)
        Spacer(Modifier.height(8.dp))
        Muted("Convergencia del VPIP con banda de Wilson 95% (cuánto se estabiliza con la muestra):")
        FunnelChart(L.cx, L.vm, L.vlo, L.vhi, PC.Gd, false, "%")
        Muted("Convergencia del PFR:")
        FunnelChart(L.cx, L.pm, L.plo, L.phi, PC.Blue, false, "%")
        if (L.acfV.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Muted("Autocorrelación del resultado entre torneos consecutivos (barras ámbar = fuera de la banda de ruido blanco):")
            AcfChart(L.acfV, L.acfBand)
        }
        Formula("CUSUM_t = Σ_{i≤t} (x_i − x̄)\nIC Wilson: (p̂ + z²/2n ± z·√(p̂(1−p̂)/n + z²/4n²)) / (1 + z²/n)\nACF_k = Σ(x_i−x̄)(x_{i+k}−x̄) / Σ(x_i−x̄)²   banda ±1.96/√T")
    }

    // 6. Bayes empírico por posición
    val sv = L.shrV; val sp = L.shrP
    if (sv != null && sp != null) {
        Sec("6 · Estimación bayesiana por posición (shrinkage)") {
            Muted("VPIP por posición: punto = media posterior; barra = intervalo creíble 95%; banda verde = rango de referencia (20–30%).")
            ForestPlot(sv.first.map { ForestRow(it.label + " (n=" + it.n.toInt() + ")", it.post * 100, it.lo * 100, it.hi * 100, 20.0, 30.0) }, 0.0, 70.0) { f1(it) }
            Spacer(Modifier.height(6.dp))
            Muted("PFR por posición (referencia 14–22%):")
            ForestPlot(sp.first.map { ForestRow(it.label + " (n=" + it.n.toInt() + ")", it.post * 100, it.lo * 100, it.hi * 100, 14.0, 22.0) }, 0.0, 70.0) { f1(it) }
            Spacer(Modifier.height(6.dp))
            Table(
                listOf("Pos", "Manos", "VPIP bruto", "VPIP Bayes", "PFR bruto", "PFR Bayes"),
                sv.first.indices.map { i ->
                    listOf<Any>(sv.first[i].label, sv.first[i].n.toInt(), f1(sv.first[i].raw * 100) + "%", f1(sv.first[i].post * 100) + "%", f1(sp.first[i].raw * 100) + "%", f1(sp.first[i].post * 100) + "%")
                }
            )
            Formula("Modelo beta-binomial: x_i ~ Bin(n_i, p_i),  p_i ~ Beta(α, β)\nPrior por momentos: κ = α+β = p̄(1−p̄)/τ² − 1  (κ VPIP = ${f1(sv.second)}, κ PFR = ${f1(sp.second)})\nPosterior: Beta(α+x, β+n−x). Las posiciones con poca muestra se acercan a la media global; las grandes casi no cambian.")
        }
    }

    // 7. uniformidad de las cartas
    if (L.chiN >= 500) {
        Sec("7 · ¿Las cartas que recibes son uniformes?") {
            Kpis(
                listOf(
                    kp("Manos con cartas", fmtN(L.chiN)), kp("χ² (168 g.l.)", f1(L.chi2), "esperado ≈ 168"),
                    kp("p-valor", fmtP(L.chiP), if (L.chiP < 0.01) "sospechoso: revisa los datos" else "consistente con el azar"),
                    kp("Esperado mínimo", f1(L.chiMinE), if (L.chiMinE < 5) "<5: aproximación débil" else "aproximación χ² válida")
                )
            )
            Spacer(Modifier.height(10.dp))
            RangeGrid(
                cell = { z ->
                    val r = L.chiRes[z] ?: 0.0
                    val a = (min(abs(r), 3.0) / 3.0).toFloat()
                    RCell(bg = (if (r >= 0) PC.Gd else PC.Bd).copy(alpha = .08f + .7f * a), label = z, sub = (if (r >= 0) "+" else "") + f1(r), txt = if (a > .5f) Color.White else PC.Tx, hot = abs(r) > 3)
                }
            )
            Spacer(Modifier.height(6.dp))
            Muted("Residuos estandarizados de Pearson por clase de mano: verde = más veces de lo esperado, rojo = menos; |r|>3 (borde rojo) es muy raro por azar.")
            Formula("Esperado_c = N·|c|/1326     χ² = Σ (O_c − E_c)²/E_c ~ χ²(168)\nResiduo_c = (O_c − E_c)/√E_c  ~ N(0,1) aprox.\nCon 169 clases es normal que ~5% superen |r|>2 solo por azar.")
        }
    }

    // 8. entropía
    if (L.ent.isNotEmpty()) {
        Sec("8 · Entropía de tus acciones preflop por posición") {
            BarChart(L.ent.map { it.first }, L.ent.map { it.second }, true)
            Muted("Bits de Shannon sobre {fold, check, call, raise}. Máximo teórico 2 bits (acciones equiprobables); valores bajos = jugada predecible, valores altos = mezcla de acciones.")
            Formula("H = −Σ p_a·log₂(p_a)     p_a = frecuencia de cada acción en esa posición")
        }
    }
}
