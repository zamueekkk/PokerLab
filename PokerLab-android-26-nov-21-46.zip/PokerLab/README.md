# Poker Lab · Android (Kotlin + Jetpack Compose)

Port nativo de `poker-lab.html`: analizador de torneos CoinPoker que corre 100% en el teléfono.

## Cómo generar el APK
1. Abre la carpeta `PokerLab` con **Android Studio** (Koala 2024.1 o más nuevo; usa JDK 17, ya incluido).
2. Deja que sincronice Gradle (descarga Gradle 8.7 y las dependencias; necesita internet la primera vez).
3. Menú **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)**.
   El archivo queda en `app/build/outputs/apk/debug/app-debug.apk`.
   (Para un APK firmado: **Build ▸ Generate Signed App Bundle / APK**.)
4. Instálalo en el teléfono (activa "instalar apps desconocidas") o ejecútalo directo con ▶.

Requisitos del dispositivo: Android 8.0 (API 26) o superior.

## Uso
- Botón **＋** (barra superior): elige uno o varios `.txt` de historial de CoinPoker. Se guardan en el
  almacenamiento privado de la app y se recargan solos al abrirla (menú ⋮ ▸ Borrar historial para limpiarlos).
- Menú ☰: las 20 secciones (Resumen, Nivel, Perfil, Preflop, Postflop, All-ins & EV, Solver, Fugas, ...).
- Filtros arriba: torneo (todos / freerolls / con buy-in / uno concreto) y rango de fechas.
- Toca cualquier mano para repetirla en la mesa (⏮ ◀ ▶ ⏭, reproducción automática, deslizador).
  En una calle con 2 jugadores aparece "Solver CFR HU · revisar spot".
- ⋮ ▸ Exportar CSV del filtro actual.

## Novedades de esta versión
- Navegación inferior (Resumen · Preflop · Postflop · Rangos · Solver · Más).
- Tablas con primera columna fija y scroll horizontal; estadísticas como tarjetas con barra de rango e IC95.
- Rangos: matriz 13x13 táctil (pintar/arrastrar, 100/50/25%, Top N%), comparación por posición.
- Solver: editor visual de rangos IP/OOP, selector de mesa, árbol navegable, equity por mano.

## Perfil persistente y rendimiento
- Las manos analizadas se guardan en una caché binaria (`hands.bin`, GZIP) y los EV ya calculados en `ev.bin`: al abrir la app no se vuelve a leer ni analizar nada.
- Solo se calculan los EV que faltan (p. ej. tras importar archivos nuevos), en paralelo con hasta 4 hilos, y se guardan al terminar.
- El evaluador de manos ya no reserva listas ni ordena en cada evaluación (varias veces más rápido).
- Filtros, pestaña, periodo y métricas se recuerdan entre sesiones; los cálculos derivados (nivel, contexto, laboratorio) se comparten entre pestañas.

## Laboratorio estadístico (pestaña «Laboratorio»)
Inferencia del winrate (IC normal, bootstrap por torneos, P(μ>0), tamaño de muestra), forma de la distribución (asimetría, curtosis, Jarque–Bera, histograma, Q-Q), simulación Monte Carlo con riesgo de ruina, suerte en all-ins (t pareada y diagrama de calibración), CUSUM, convergencia con bandas de Wilson, autocorrelación, shrinkage bayesiano por posición, χ² de uniformidad de las cartas y entropía de acciones. Cada análisis lista su fórmula y supuestos. En «Perfil» hay además un diagrama de bosque y p-valores / h de Cohen por estadística.

## Capa científica en todas las pestañas
Cada pestaña termina con una «capa científica» (sección numerada §N.M, con fórmulas y supuestos): precisión de las estimaciones (EE, margen, n necesaria), perfil z frente a la banda, contrastes A vs B con corrección Benjamini–Hochberg y h de Cohen, incertidumbre del nivel, Pareto de puntos perdidos, matriz de correlación por torneo, IC por posición, homogeneidad χ² y tendencia de Cochran–Armitage, defensa frente a MDF con contraste, embudo de suerte y calibración (Brier), gráfico de volcán de subgrupos, coste de errores, supervivencia Kaplan–Meier, ANOVA con η², potencia y efecto mínimo detectable, Lorenz/Gini y outliers MAD, ECDF con banda DKW, bayes de rivales y convergencia del CFR+. Aspecto de laboratorio: papel milimetrado, marcas de registro, tira de metadatos (N, α, IC, cobertura de EV, rango de fechas).

## Rediseño visual
- Icono nuevo (adaptativo + monocromo para Android 13): pica con degradado y curva de EV sobre fondo técnico oscuro. Misma marca en splash, menú y pantalla de inicio.
- Iconos propios dibujados en Canvas, barra inferior y menú lateral rediseñados, cabecera con contador de manos.
- Superficies de vidrio oscuro con borde degradado, tarjeta hero con el nivel en el Resumen, gráficas con degradados y rejilla punteada.
- Barras de estado y navegación transparentes con iconos claros (también si el teléfono está en modo claro).

## Estructura (app/src/main/java/com/pokerlab)
- `Parser.kt`      lee el historial y calcula los contadores de cada mano
- `Stats.kt`       tabla de estadísticas con rangos de referencia, Wilson, nivel estimado, alertas
- `Equity.kt`      evaluador de 7 cartas, equity multiway con side pots, EV de all-ins
- `Solver.kt`      solver CFR+ heads-up nativo (reemplaza al TexasSolver externo del HTML)
- `Replay.kt`      reconstrucción paso a paso de la mano
- `RangeUi.kt`    matriz 13x13 (visor, editor táctil con presets, mini-mapas, selector de mesa)
- `SolverUi.kt`    pantalla del solver: navegador de árbol, matriz de estrategia/rango/equity por nodo
- `Brand.kt`       logo, iconos, botones, fondo y chips propios
- `Store.kt`       caché binaria del perfil
- `SciMath.kt`     distribuciones (normal, beta, χ²), bootstrap, simulación, Bayes empírico
- `SciCharts.kt`   bosque, Q-Q, abanico Monte Carlo, calibración, ACF, embudo
- `Lab.kt`         pestaña Laboratorio
- `Derived.kt`     cálculos compartidos entre pestañas
- `Sci.kt` / `SciTabs.kt`  pruebas estadísticas, componentes de laboratorio y las capas científicas por pestaña
- `Charts.kt`      gráficas en Canvas (líneas, barras, donut, radar, heatmaps, mesa)
- `Components.kt`  componentes (secciones, KPIs, tablas, cartas, repetidor)
- `Tabs1/2/3.kt`   las pestañas
- `Vm.kt`, `MainActivity.kt`  estado, navegación, importación
