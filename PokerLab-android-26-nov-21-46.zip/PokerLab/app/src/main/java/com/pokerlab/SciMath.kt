package com.pokerlab

import java.util.Locale
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

// ===================== funciones especiales =====================
fun erfc(x: Double): Double {
    val z = abs(x); val t = 1.0 / (1.0 + 0.5 * z)
    val r = t * exp(-z * z - 1.26551223 + t * (1.00002368 + t * (0.37409196 + t * (0.09678418 + t * (-0.18628806 + t * (0.27886807 + t * (-1.13520398 + t * (1.48851587 + t * (-0.82215223 + t * 0.17087277)))))))))
    return if (x >= 0) r else 2.0 - r
}

fun normCdf(x: Double): Double = 0.5 * erfc(-x / sqrt(2.0))

/** Cuantil de la normal estándar (algoritmo de Acklam, error relativo < 1.2e-9). */
fun normInv(p: Double): Double {
    val a = doubleArrayOf(-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02, 1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00)
    val b = doubleArrayOf(-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02, 6.680131188771972e+01, -1.328068155288572e+01)
    val c = doubleArrayOf(-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00, -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00)
    val d = doubleArrayOf(7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00, 3.754408661907416e+00)
    val pl = 0.02425
    if (p <= 0.0) return -8.0
    if (p >= 1.0) return 8.0
    if (p < pl) {
        val q = sqrt(-2 * ln(p))
        return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1)
    }
    if (p > 1 - pl) {
        val q = sqrt(-2 * ln(1 - p))
        return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1)
    }
    val q = p - 0.5; val r = q * q
    return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1)
}

fun lgamma(x: Double): Double {
    val c = doubleArrayOf(76.18009172947146, -86.50532032941677, 24.01409824083091, -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5)
    var y = x
    val tmp0 = x + 5.5
    val tmp = tmp0 - (x + 0.5) * ln(tmp0)
    var ser = 1.000000000190015
    for (j in 0..5) { y += 1.0; ser += c[j] / y }
    return -tmp + ln(2.5066282746310005 * ser / x)
}

private fun betacf(a: Double, b: Double, x: Double): Double {
    val fpmin = 1e-300
    val qab = a + b; val qap = a + 1; val qam = a - 1
    var c = 1.0
    var d = 1 - qab * x / qap
    if (abs(d) < fpmin) d = fpmin
    d = 1 / d
    var h = d
    for (m in 1..200) {
        val m2 = 2 * m
        var aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1 + aa * d; if (abs(d) < fpmin) d = fpmin
        c = 1 + aa / c; if (abs(c) < fpmin) c = fpmin
        d = 1 / d; h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1 + aa * d; if (abs(d) < fpmin) d = fpmin
        c = 1 + aa / c; if (abs(c) < fpmin) c = fpmin
        d = 1 / d
        val del = d * c
        h *= del
        if (abs(del - 1) < 3e-12) break
    }
    return h
}

/** Función beta incompleta regularizada I_x(a,b): CDF de la distribución Beta. */
fun betaCdf(a: Double, b: Double, x: Double): Double {
    if (x <= 0) return 0.0
    if (x >= 1) return 1.0
    val bt = exp(lgamma(a + b) - lgamma(a) - lgamma(b) + a * ln(x) + b * ln(1 - x))
    return if (x < (a + 1) / (a + b + 2)) bt * betacf(a, b, x) / a else 1 - bt * betacf(b, a, 1 - x) / b
}

fun betaInv(a: Double, b: Double, p: Double): Double {
    var lo = 0.0; var hi = 1.0
    repeat(60) { val mid = (lo + hi) / 2; if (betaCdf(a, b, mid) < p) lo = mid else hi = mid }
    return (lo + hi) / 2
}

private fun gser(a: Double, x: Double): Double {
    var ap = a; var sum = 1.0 / a; var del = sum
    for (n in 1..500) { ap += 1; del *= x / ap; sum += del; if (abs(del) < abs(sum) * 1e-12) break }
    return sum * exp(-x + a * ln(x) - lgamma(a))
}

private fun gcf(a: Double, x: Double): Double {
    val fpmin = 1e-300
    var b = x + 1 - a; var c = 1 / fpmin; var d = 1 / b; var h = d
    for (i in 1..500) {
        val an = -i * (i - a)
        b += 2
        d = an * d + b; if (abs(d) < fpmin) d = fpmin
        c = b + an / c; if (abs(c) < fpmin) c = fpmin
        d = 1 / d
        val del = d * c
        h *= del
        if (abs(del - 1) < 1e-12) break
    }
    return exp(-x + a * ln(x) - lgamma(a)) * h
}

/** Gamma incompleta regularizada P(a,x). */
fun gammaP(a: Double, x: Double): Double = if (x <= 0) 0.0 else if (x < a + 1) gser(a, x) else 1 - gcf(a, x)

/** P(X > x) para una chi-cuadrado con k grados de libertad. */
fun chi2Sf(x: Double, k: Double): Double = max(0.0, 1 - gammaP(k / 2, x / 2))

fun fmtP(p: Double): String = if (p < 0.001) "<0.001" else String.format(Locale.US, "%.3f", p)

// ===================== descriptivos =====================
class Desc(val n: Int, val mean: Double, val sd: Double, val skew: Double, val kurt: Double)

fun describe(x: DoubleArray): Desc {
    val n = x.size
    if (n < 2) return Desc(n, x.firstOrNull() ?: 0.0, 0.0, 0.0, 0.0)
    val m = x.average()
    var s2 = 0.0; var s3 = 0.0; var s4 = 0.0
    for (v in x) { val d = v - m; s2 += d * d; s3 += d * d * d; s4 += d * d * d * d }
    val v = s2 / n
    val sk = if (v > 0) (s3 / n) / v.pow(1.5) else 0.0
    val ku = if (v > 0) (s4 / n) / (v * v) - 3 else 0.0
    return Desc(n, m, sqrt(s2 / (n - 1)), sk, ku)
}

/** p-valor de Jarque–Bera (H0: normalidad): JB ~ chi2(2), así que P = exp(-JB/2). */
fun jarqueBeraP(d: Desc): Double = exp(-(d.n / 6.0 * (d.skew * d.skew + d.kurt * d.kurt / 4)) / 2)

fun jarqueBera(d: Desc): Double = d.n / 6.0 * (d.skew * d.skew + d.kurt * d.kurt / 4)

// ===================== remuestreo y simulación =====================
/** Bootstrap por clústeres (torneos) del bb/100: respeta la correlación entre manos de un mismo torneo. */
fun clusterBoot(sum: DoubleArray, cnt: DoubleArray, B: Int = 2000, seed: Long = 12345L): Pair<Double, Double> {
    val t = sum.size
    if (t < 3) return Pair(Double.NaN, Double.NaN)
    val r = java.util.SplittableRandom(seed)
    val out = DoubleArray(B)
    for (b in 0 until B) {
        var s = 0.0; var c = 0.0
        for (i in 0 until t) { val k = r.nextInt(t); s += sum[k]; c += cnt[k] }
        out[b] = 100 * s / c
    }
    out.sort()
    return Pair(out[(B * 0.025).toInt()], out[min(B - 1, (B * 0.975).toInt())])
}

/** Simulación Monte Carlo de trayectorias acumuladas muestreando manos observadas; devuelve cuantiles 5,25,50,75,95. */
fun fanSim(x: DoubleArray, steps: Int, block: Int, paths: Int, seed: Long = 7L): List<DoubleArray> {
    val pts = steps / block
    val r = java.util.SplittableRandom(seed)
    val res = Array(pts + 1) { DoubleArray(paths) }
    for (p in 0 until paths) {
        var c = 0.0
        for (k in 1..pts) {
            for (j in 0 until block) c += x[r.nextInt(x.size)]
            res[k][p] = c
        }
    }
    for (k in 1..pts) res[k].sort()
    return doubleArrayOf(.05, .25, .5, .75, .95).map { q ->
        DoubleArray(pts + 1) { k -> if (k == 0) 0.0 else res[k][min(paths - 1, (q * paths).toInt())] }
    }
}

fun acf(x: DoubleArray, maxLag: Int): DoubleArray {
    val n = x.size
    if (n < 3) return DoubleArray(maxLag)
    val m = x.average()
    var den = 0.0
    for (v in x) den += (v - m) * (v - m)
    return DoubleArray(maxLag) { k ->
        val lag = k + 1
        if (lag >= n || den == 0.0) 0.0 else {
            var num = 0.0
            for (i in 0 until n - lag) num += (x[i] - m) * (x[i + lag] - m)
            num / den
        }
    }
}

// ===================== Bayes empírico =====================
class Shr(val label: String, val n: Double, val raw: Double, val post: Double, val lo: Double, val hi: Double)

/** Estimación beta-binomial con prior estimado por momentos (shrinkage); devuelve las estimaciones y la fuerza del prior κ. */
fun shrink(labels: List<String>, xs: List<Double>, ns: List<Double>): Pair<List<Shr>, Double> {
    val k = labels.size
    val total = ns.sum()
    val pb = xs.sum() / total
    var s2 = 0.0
    for (i in 0 until k) { val p = xs[i] / ns[i]; s2 += ns[i] * (p - pb) * (p - pb) }
    s2 /= total
    val tau2 = max(s2 - k * pb * (1 - pb) / total, 1e-6)
    val kap = (pb * (1 - pb) / tau2 - 1).coerceIn(2.0, 2000.0)
    val a = pb * kap; val b = (1 - pb) * kap
    val out = (0 until k).map { i ->
        val al = a + xs[i]; val be = b + ns[i] - xs[i]
        Shr(labels[i], ns[i], xs[i] / ns[i], al / (al + be), betaInv(al, be, .025), betaInv(al, be, .975))
    }
    return Pair(out, kap)
}
