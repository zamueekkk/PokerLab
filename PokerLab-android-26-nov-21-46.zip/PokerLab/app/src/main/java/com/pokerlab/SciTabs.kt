package com.pokerlab

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

@Composable
fun SciAddendum(id: String, e: Env) {
    if (e.hs.size < 30) return
    when (id) {
        "res" -> SciRes(e)
        "seg" -> SciSeg(e)
        "niv" -> SciNiv(e)
        "per" -> SciPer(e)
        "pre" -> SciPre(e)
        "post" -> SciPost(e)
        "ev" -> SciEv(e)
        "fug" -> SciFug(e)
        "rev" -> SciRev(e)
        "tor" -> SciTor(e)
        "ran" -> SciRan(e)
        "pos" -> SciPos(e)
        "pat" -> SciPat(e)
        "man" -> SciMan(e)
        "hnd" -> SciHnd(e)
        "gra" -> SciGra(e)
        "av" -> SciAv(e)
        "cla" -> SciCl(e)
    }
}

private fun axisOf(rows: List<ForestRow>): Pair<Double, Double> {
    val lo = rows.minOf { it.lo ?: it.est }; val hi = rows.maxOf { it.hi ?: it.est }
    val pad = max(1.0, (hi - lo) * .08)
    return Pair(lo - pad, hi + pad)
}

// ===================== RESUMEN =====================
@Composable
private fun SciRes(e: Env) {
    val hs = e.hs; val s = e.s
    val keys = listOf("vpip", "pfr", "rfi", "t3", "f3", "stl", "cb", "fcb", "wtsd", "wsd")
    LabDivider("Capa científica · resumen")
    Sec("Precisión de las estimaciones") {
        PrecisionTable(s, keys)
        Caption("Cuánta confianza merece cada cifra del panel: EE, margen y muestra necesaria para ±2 puntos.")
        Formula("EE = √(p̂(1−p̂)/n)    margen = 1.96·EE\nn p/ ±2 pt = 1.96²·p̂(1−p̂)/0.02²    fiabilidad r = n/(n+30)\nWilson: (p̂ + z²/2n ± z√(p̂(1−p̂)/n + z²/4n²)) / (1 + z²/n)")
    }
    Sec("Perfil estandarizado frente a la banda ideal") {
        val zs = keys.mapNotNull { id ->
            val r = SR(SM[id]!!, s, NOCTX)
            if (r.v == null || !r.ok) null else r.e.name.take(9) to (r.v - (r.e.lo + r.e.hi) / 2) / ((r.e.hi - r.e.lo) / 2)
        }
        BarChart(zs.map { it.first }, zs.map { it.second }, true)
        Caption("z = (valor − centro de la banda) / semiancho. |z| ≤ 1 dentro del rango; |z| > 1 fuera; |z| > 2 desviación marcada.")
    }
    val blocks = hs.chunked(1000).filter { it.size >= 200 }
    if (blocks.size >= 2) {
        Sec("Estabilidad del winrate por bloques de 1 000 manos") {
            val rows = blocks.mapIndexed { i, z ->
                val d = describe(DoubleArray(z.size) { z[it].nb })
                val se = 100 * d.sd / sqrt(z.size.toDouble())
                ForestRow("H " + (i * 1000 + 1) + "+", d.mean * 100, d.mean * 100 - 1.96 * se, d.mean * 100 + 1.96 * se, null, null)
            }
            val ax = axisOf(rows)
            ForestPlot(rows, ax.first, ax.second) { f1(it) }
            Caption("bb/100 con IC95% por bloque. Si los intervalos se solapan casi todos, el winrate es estable; si no, hay heterogeneidad real entre rachas.")
        }
    }
}

// ===================== SEGUIMIENTO =====================
private class SegRow(val st: StatDef, val pa: Double, val pb: Double, val z: Z2)

@Composable
private fun SciSeg(e: Env) {
    val vm = e.vm; val hs = e.hs
    val ra = prng(vm.cpa, vm.H); val rb = prng(vm.cpb, vm.H)
    val hA = hs.filter { it.ts >= ra[0] && it.ts <= ra[1] }; val hB = hs.filter { it.ts >= rb[0] && it.ts <= rb[1] }
    if (hA.size < 30 || hB.size < 30) return
    val sA = S(hA); val sB = S(hB)
    val rs = ST.filter { it.f == null && it.u == "%" && it.w > 0 }.mapNotNull { st ->
        val na = gc(sA, st.d); val nb = gc(sB, st.d)
        if (na < 20 || nb < 20) return@mapNotNull null
        val z = twoProp(gc(sA, st.n), na, gc(sB, st.n), nb) ?: return@mapNotNull null
        SegRow(st, gc(sA, st.n) / na, gc(sB, st.n) / nb, z)
    }.sortedBy { it.z.p }
    val q = bhAdjust(rs.map { it.z.p })
    val w = welch(sA.nb / sA.n, B(sA).sd, sA.n.toDouble(), sB.nb / sB.n, B(sB).sd, sB.n.toDouble())
    LabDivider("Capa científica · contraste A vs B")
    Sec("Contraste del resultado (Welch)") {
        Kpis(
            listOf(
                kp("Δ bb/100 (A−B)", f1(w.diff * 100), "± " + f1(196 * w.se) + " · IC95%", toneOf(w.diff)),
                kp("t de Welch", f2(w.t), sigText(w.p)),
                kp("Contrastes con q<0.05", q.count { it < 0.05 }.toString() + " / " + rs.size, "tras corrección BH")
            )
        )
        Formula("t = (x̄_A − x̄_B) / √(s_A²/n_A + s_B²/n_B)     IC95% = Δ ± 1.96·EE")
    }
    Sec("Contraste de proporciones con control de falsos descubrimientos") {
        Table(
            listOf("Estadística", "A", "B", "Δ pts", "IC95% Δ", "z", "p", "q (BH)", "h", "Sig."),
            rs.mapIndexed { i, r ->
                listOf<Any>(
                    r.st.name, f1(100 * r.pa) + "%", f1(100 * r.pb) + "%", Tone((if (r.z.diff >= 0) "+" else "") + f1(100 * r.z.diff), if (q[i] < .05) toneOf(r.z.diff) else 0),
                    f1(100 * (r.z.diff - 1.96 * r.z.se)) + " a " + f1(100 * (r.z.diff + 1.96 * r.z.se)), f2(r.z.z), fmtP(r.z.p), fmtP(q[i]), f2(r.z.h), starsOf(q[i])
                )
            }, listOf(170, 60, 60, 66, 110, 52, 62, 62, 52, 48)
        )
        Caption("Cada fila es una prueba z de dos proporciones; q es el p ajustado por Benjamini–Hochberg (FDR) porque se contrastan varias estadísticas a la vez.")
        Formula("z = (p̂_A − p̂_B) / √(p̂(1−p̂)(1/n_A + 1/n_B))    h = 2·asin√p̂_A − 2·asin√p̂_B\nBH: q_(i) = mín_{j≥i} p_(j)·m/j  (m = nº de contrastes)")
    }
    val fr = rs.take(12)
    if (fr.isNotEmpty()) {
        Sec("Diagrama de bosque del tamaño del efecto (h de Cohen)") {
            val rows = fr.map { ForestRow(it.st.name.take(22), it.z.h, it.z.h - 1.96 * it.z.hse, it.z.h + 1.96 * it.z.hse, -0.2, 0.2) }
            val m = max(0.5, rows.maxOf { max(abs(it.lo ?: 0.0), abs(it.hi ?: 0.0)) } + .05)
            ForestPlot(rows, -m, m) { f2(it) }
            Caption("Banda verde: efecto despreciable (|h| < 0.2). Fuera de la banda y sin cruzar 0 = cambio real y relevante.")
        }
    }
}

// ===================== NIVEL =====================
@Composable
private fun SciNiv(e: Env) {
    val hs = e.hs
    val L = derived(hs, e.vm.evVer).level
    val (lo, hi) = levelInterval(L)
    LabDivider("Capa científica · incertidumbre del nivel")
    Sec("Intervalo del puntaje") {
        Kpis(
            listOf(
                kp("Nivel ajustado", f1(L.adj), "intervalo ≈ [" + f1(lo) + ", " + f1(hi) + "]"),
                kp("Anchura", f1(hi - lo) + " pts", if (hi - lo > 12) "estimación muy incierta" else "estimación razonable"),
                kp("Peso de los datos", f1(100 * L.sh) + "%", "n/(n+1200)")
            )
        )
        Formula("Puntaje_cat = Σ s_i·w_i·r_i / Σ w_i·r_i      s_i = 100 dentro de la banda, decae linealmente fuera\nNivel = 38 + (Σ_cat pesos·Puntaje_cat − 38)·n/(n+1200)\nIntervalo: se recalcula con los extremos del IC de Wilson de cada estadística (propagación de la incertidumbre).")
    }
    Sec("Pareto de puntos perdidos") {
        val imp = L.imp.take(8)
        ParetoChart(imp.map { it.r.e.name }, imp.map { it.gain })
        Caption("Barras: puntos de nivel que ganarías llevando cada estadística a su rango; línea ámbar: % acumulado. Prioriza las primeras barras (regla 80/20).")
    }
    Sec("Aporte ponderado por categoría") {
        val cats = L.cw.keys.toList()
        BarChart(cats.map { CATN[it]?.take(8) ?: "Result." }, cats.map { (L.C[it]!!.v ?: 0.0) * L.cw[it]!! }, true)
        Caption("Puntaje de la categoría × su peso en la fórmula; la suma de barras es el puntaje observado antes del ajuste por muestra.")
    }
}

// ===================== PERFIL =====================
@Composable
private fun SciPer(e: Env) {
    val hs = e.hs; val s = e.s
    LabDivider("Capa científica · perfil")
    Sec("Fiabilidad de todas las estadísticas de proporción") {
        PrecisionTable(s, ST.filter { it.f == null && it.u == "%" && it.w > 0 }.map { it.id })
        Caption("Fiab. r = n/(n+30): las estadísticas con r < 0.5 aún no son interpretables.")
    }
    val T = derived(hs, e.vm.evVer).tours.filter { it.hs.size >= 30 }
    if (T.size >= 8) {
        Sec("Matriz de correlación entre estadísticas (por torneo)") {
            val ms = listOf<Pair<String, (Tour) -> Double?>>(
                "VPIP" to { t: Tour -> val o = gc(t.s, "vpip_o"); if (o > 0) 100 * gc(t.s, "vpip_x") / o else null },
                "PFR" to { t: Tour -> val o = gc(t.s, "pfr_o"); if (o > 0) 100 * gc(t.s, "pfr_x") / o else null },
                "3-bet" to { t: Tour -> val o = gc(t.s, "t3_o"); if (o > 0) 100 * gc(t.s, "t3_x") / o else null },
                "C-bet" to { t: Tour -> val o = gc(t.s, "cb_o"); if (o > 0) 100 * gc(t.s, "cb_x") / o else null },
                "WTSD" to { t: Tour -> val o = gc(t.s, "saw"); if (o > 0) 100 * gc(t.s, "sd") / o else null },
                "bb/100" to { t: Tour -> B(t.s).m }
            )
            val cols = ms.map { m -> T.map { m.second(it) } }
            val k = ms.size
            val r = Array(k) { i ->
                DoubleArray(k) { j ->
                    if (i == j) 1.0 else {
                        val xs = ArrayList<Double>(); val ys = ArrayList<Double>()
                        for (t in T.indices) { val a = cols[i][t]; val b = cols[j][t]; if (a != null && b != null) { xs.add(a); ys.add(b) } }
                        if (xs.size >= 6) pearson(xs.toDoubleArray(), ys.toDoubleArray()) else Double.NaN
                    }
                }
            }
            CorrHeat(ms.map { it.first }, r)
            Caption("Pearson r entre estadísticas calculadas en cada torneo (≥30 manos; " + T.size + " torneos). Verde: se mueven juntas; rojo: en sentido opuesto.")
            Formula("r = Σ(x−x̄)(y−ȳ) / √(Σ(x−x̄)²·Σ(y−ȳ)²)   |r| ≈ 0.3 débil, 0.5 moderada, 0.7 fuerte\nCorrelación ≠ causalidad; con pocos torneos, r es muy inestable.")
        }
    }
}

// ===================== PREFLOP =====================
@Composable
private fun SciPre(e: Env) {
    val hs = e.hs
    val ps = PO.map { p -> p to S(hs.filter { it.pos == p }) }.filter { it.second.n >= 20 }
    LabDivider("Capa científica · preflop")
    if (ps.size >= 2) {
        fun rowsOf(id: String, a: Double?, b: Double?) = ps.mapNotNull { (p, sg) ->
            val n = gc(sg, id + "_o")
            if (n < 10) null else { val x = gc(sg, id + "_x"); val w = wl(x, n); ForestRow(p + " (n=" + n.toInt() + ")", 100 * x / n, w.first, w.second, a, b) }
        }
        Sec("Intervalos de confianza por posición") {
            for ((id, nm, band) in listOf(Triple("vpip", "VPIP", 20.0 to 30.0), Triple("pfr", "PFR", 14.0 to 22.0), Triple("rfi", "RFI", 18.0 to 35.0))) {
                val rows = rowsOf(id, band.first, band.second)
                if (rows.isEmpty()) continue
                Muted(nm + " con IC95% de Wilson (banda verde: referencia general)")
                ForestPlot(rows, 0.0, min(100.0, rows.maxOf { it.hi ?: it.est } + 8)) { f1(it) }
            }
            Caption("Si el IC de una posición no toca la banda, la desviación respecto a la referencia es estadísticamente distinguible.")
        }
        Sec("¿Juegas igual en todas las posiciones? (homogeneidad)") {
            val items = listOf("vpip" to "VPIP", "pfr" to "PFR", "rfi" to "RFI").mapNotNull { (id, nm) ->
                val xs = ps.map { gc(it.second, id + "_x") }.toDoubleArray(); val ns = ps.map { gc(it.second, id + "_o") }.toDoubleArray()
                val ok = ns.indices.filter { ns[it] >= 10 }
                val r = chi2Hom(ok.map { xs[it] }.toDoubleArray(), ok.map { ns[it] }.toDoubleArray())
                if (r == null) null else kp("χ² " + nm, f1(r.first), r.third.toString() + " g.l. · " + sigText(r.second))
            }
            Kpis(items)
            Formula("χ² = Σ (O−E)²/E sobre la tabla posición×{sí,no}, g.l. = k−1.\nUn p muy pequeño es lo esperado: se juega distinto por posición. Lo informativo es el tamaño de la diferencia.")
        }
    }
    val B_ = listOf(0.0 to 8.0, 8.0 to 12.0, 12.0 to 15.0, 15.0 to 20.0, 20.0 to 30.0, 30.0 to 1e9)
    val gs = B_.map { (a, b) -> hs.filter { it.stack / it.bb >= a && it.stack / it.bb < b } }.map { S(it) }
    val ok = gs.indices.filter { gc(gs[it], "vpip_o") >= 20 }
    if (ok.size >= 3) {
        val x = ok.map { gc(gs[it], "vpip_x") }.toDoubleArray(); val n = ok.map { gc(gs[it], "vpip_o") }.toDoubleArray()
        val tr = trendCA(x, n, ok.map { (it + 1).toDouble() }.toDoubleArray())
        val tp = trendCA(ok.map { gc(gs[it], "pfr_x") }.toDoubleArray(), n, ok.map { (it + 1).toDouble() }.toDoubleArray())
        Sec("Tendencia con la profundidad de stack (Cochran–Armitage)") {
            Kpis(
                listOf(
                    kp("Tendencia VPIP", if (tr == null) "–" else f2(tr.first), if (tr == null) "" else (if (tr.first > 0) "sube con el stack · " else "baja con el stack · ") + sigText(tr.second)),
                    kp("Tendencia PFR", if (tp == null) "–" else f2(tp.first), if (tp == null) "" else (if (tp.first > 0) "sube con el stack · " else "baja con el stack · ") + sigText(tp.second))
                )
            )
            Formula("Z = Σ s_i(x_i − n_i p̂) / √(p̂(1−p̂)(Σ n_i s_i² − (Σ n_i s_i)²/N)),  s_i = orden del tramo de stack\nZ > 0: la frecuencia crece al aumentar el stack; Z < 0: decrece.")
        }
    }
}

// ===================== POSTFLOP =====================
@Composable
private fun SciPost(e: Env) {
    val s = e.s
    LabDivider("Capa científica · postflop")
    Sec("Reacción ante apuestas por calle con IC95%") {
        val rows = ArrayList<ForestRow>()
        for (st in SK) for ((k, nm) in listOf("fold" to "fold", "call" to "call", "raise" to "raise")) {
            val n = gc(s, k + "_" + st + "_o")
            if (n >= 10) { val x = gc(s, k + "_" + st + "_x"); val w = wl(x, n); rows.add(ForestRow(st + " " + nm + " (n=" + n.toInt() + ")", 100 * x / n, w.first, w.second, null, null)) }
        }
        if (rows.isEmpty()) Muted("Sin muestra suficiente.") else {
            ForestPlot(rows, 0.0, min(100.0, rows.maxOf { it.hi ?: it.est } + 8)) { f1(it) }
            Caption("Frecuencia de fold/call/raise cuando enfrentas una apuesta, con intervalos de Wilson.")
        }
    }
    Sec("Defensa observada frente a la defensa mínima (MDF)") {
        val rows = SK.mapNotNull { st ->
            val m = gc(s, "mdf_n_" + st)
            if (m < 15) null else {
                val folds = gc(s, "mf_x_" + st); val defend = 1 - folds / m
                val mdf = gc(s, "mdf_s_" + st) / m
                val se0 = sqrt(mdf * (1 - mdf) / m)
                val z = if (se0 > 0) (defend - mdf) / se0 else 0.0
                val p = normCdf(z)
                listOf<Any>(st, m.toInt(), f1(100 * defend) + "%", f1(100 * mdf) + "%", Tone((if (defend - mdf >= 0) "+" else "") + f1(100 * (defend - mdf)), if (p < .05) -1 else 0), f2(z), fmtP(p), if (p < .05) "defiendes menos que el MDF: explotable por faroles" else "compatible con MDF o por encima")
            }
        }
        Table(listOf("Calle", "n", "Defiendes", "MDF medio", "Dif. pts", "z", "p (1 cola)", "Lectura"), rows, listOf(70, 50, 80, 80, 70, 52, 80, 300))
        Formula("MDF = bote / (bote + apuesta) = 1 − fold_equity_requerida\nH₀: defensa ≥ MDF.   z = (d̂ − MDF)/√(MDF(1−MDF)/n),  p = Φ(z) (una cola).\nSolo defender ≥ MDF impide que un farol con cualquier mano sea rentable (supone rivales que apuestan faroles).")
    }
    val a = twoProp(gc(s, "cbIP_x"), gc(s, "cbIP_o"), gc(s, "cbOP_x"), gc(s, "cbOP_o"))
    if (a != null && gc(s, "cbIP_o") >= 15 && gc(s, "cbOP_o") >= 15) {
        Sec("C-bet en posición vs fuera de posición") {
            Kpis(
                listOf(
                    kp("C-bet IP", q(s, "cbIP_x", "cbIP_o"), "n=" + gc(s, "cbIP_o").toInt()), kp("C-bet OOP", q(s, "cbOP_x", "cbOP_o"), "n=" + gc(s, "cbOP_o").toInt()),
                    kp("Δ (IP−OOP)", f1(100 * a.diff) + " pts", "IC95% ±" + f1(196 * a.se)), kp("Contraste z", f2(a.z), sigText(a.p) + " · h=" + f2(a.h))
                )
            )
        }
    }
}

// ===================== ALL-INS & EV =====================
@Composable
private fun SciEv(e: Env) {
    val hs = e.hs
    val Lh = hs.filter { it.eq != null }.sortedWith(CMP)
    LabDivider("Capa científica · all-ins")
    if (Lh.size < 5) { Note("Se necesitan al menos 5 all-ins con EV calculado para la capa científica."); return }
    val d = DoubleArray(Lh.size) { Lh[it].nb - Lh[it].eq!!.ev }
    val dd = describe(d)
    var c = 0.0
    val xs = ArrayList<Double>(); val mid = ArrayList<Double>(); val lo = ArrayList<Double>(); val hi = ArrayList<Double>()
    for (i in d.indices) {
        c += d[i]
        val k = i + 1.0
        xs.add(k); mid.add(c); lo.add(-1.96 * dd.sd * sqrt(k)); hi.add(1.96 * dd.sd * sqrt(k))
    }
    val wins = Lh.map { if (it.nb > 0) 1.0 else 0.0 }
    val brier = Lh.indices.sumOf { (Lh[it].eq!!.e - wins[it]) * (Lh[it].eq!!.e - wins[it]) } / Lh.size
    val pbar = wins.average()
    val base = pbar * (1 - pbar)
    Sec("Embudo de la suerte acumulada") {
        FunnelChart(xs, mid, lo, hi, PC.Wn, true, " bb")
        Caption("Suerte acumulada (real − EV) frente a la banda ±1.96·s·√k esperada bajo azar puro. Fuera de la banda = desviación significativa.")
        Formula("Bajo H₀ (sin suerte sistemática) la suma de k diferencias tiene media 0 y desviación s·√k.\ns = ${f1(dd.sd)} bb por all-in")
    }
    Sec("Calidad de las predicciones de equity") {
        Kpis(
            listOf(
                kp("Brier", f2(brier), "0 perfecto · " + f2(base) + " base"),
                kp("Skill de Brier", f2(if (base > 0) 1 - brier / base else 0.0), "1 − B/B_base"),
                kp("Equity media", f1(100 * Lh.sumOf { it.eq!!.e } / Lh.size) + "%", "victorias: " + f1(100 * pbar) + "%")
            )
        )
        Spacer(Modifier.height(8.dp))
        CalibrationPlot(calPts(Lh))
        Caption("Fiabilidad: si el cálculo es correcto, frecuencia observada ≈ equity predicha. Verde: el IC de Wilson contiene la diagonal.")
        val bins = DoubleArray(10)
        for (h in Lh) bins[min(9, (h.eq!!.e * 10).toInt())]++
        BarChart(List(10) { (it * 10).toString() + "-" + (it * 10 + 10) }, bins.map { 100 * it / Lh.size }, true)
        Caption("Distribución de la equity con la que entras en tus all-ins (% de all-ins por tramo).")
        Formula("Brier = (1/n) Σ (e_i − y_i)²   y_i = 1 si ganaste.   Skill = 1 − Brier/[p̄(1−p̄)]")
    }
}

// ===================== FUGAS =====================
private fun fugDims(): List<Pair<String, (Hand) -> String?>> = listOf(
    "Posición" to { h: Hand -> h.pos },
    "Rol" to { h: Hand -> if (h.saw == 1) (if (h.agg == 1) "Agresor" else "Defensor") else null },
    "Posición post" to { h: Hand -> if (h.ip == true) "En posición" else if (h.ip == false) "Fuera pos." else null },
    "Tipo de bote" to { h: Hand -> if (h.saw == 1) listOf("Limpeado", "SRP", "3-bet", "4-bet+")[min(h.pt, 3)] else null },
    "Profundidad" to { h: Hand -> val d = h.stack / h.bb; if (d < 10) "<10 bb" else if (d < 20) "10-20 bb" else if (d < 40) "20-40 bb" else "40+ bb" },
    "Zona M" to { h: Hand -> if (h.M >= 20) "Verde" else if (h.M >= 10) "Amarilla" else if (h.M >= 6) "Naranja" else "Roja" },
    "Franja" to { h: Hand -> listOf("00-06", "06-12", "12-18", "18-24")[min(3, h.hour / 6)] }
)

private class FgAcc { var n = 0.0; var s = 0.0; var q = 0.0 }
private class FgRes(val dim: String, val lab: String, val n: Int, val eff: Double, val se: Double, val p: Double)

@Composable
private fun SciFug(e: Env) {
    val hs = e.hs
    val res = androidx.compose.runtime.remember(hs) {
        var N = 0.0; var SUM = 0.0; var SS = 0.0
        for (h in hs) { N++; SUM += h.nb; SS += h.nb * h.nb }
        val out = ArrayList<FgRes>()
        for ((dn, fn) in fugDims()) {
            val m = LinkedHashMap<String, FgAcc>()
            for (h in hs) { val l = fn(h) ?: continue; val a = m.getOrPut(l) { FgAcc() }; a.n++; a.s += h.nb; a.q += h.nb * h.nb }
            for ((l, a) in m) {
                val nc = N - a.n
                if (a.n < 40 || nc < 40) continue
                val mg = a.s / a.n; val vg = max(0.0, (a.q - a.n * mg * mg) / (a.n - 1))
                val sc = SUM - a.s; val qc = SS - a.q; val mc = sc / nc; val vc = max(0.0, (qc - nc * mc * mc) / (nc - 1))
                val w = welch(mg, sqrt(vg), a.n, mc, sqrt(vc), nc)
                out.add(FgRes(dn, l, a.n.toInt(), w.diff * 100, w.se * 100, w.p))
            }
        }
        out
    }
    if (res.size < 3) return
    val q = bhAdjust(res.map { it.p })
    val order = res.indices.sortedBy { res[it].p }
    LabDivider("Capa científica · fugas")
    Sec("Gráfico de volcán de los subgrupos") {
        VolcanoPlot(res.indices.map { i -> VPt(res[i].eff, min(10.0, -ln(max(res[i].p, 1e-10)) / ln(10.0)), res[i].dim + ":" + res[i].lab, q[i] < .05) }, " bb")
        Caption("Cada punto es un subgrupo frente al resto de tus manos. Eje X: diferencia en bb/100; eje Y: −log₁₀ p. Línea ámbar: p = 0.05 sin corregir; color = significativo tras BH.")
    }
    Sec("Subgrupos más extremos (q de Benjamini–Hochberg)") {
        Table(
            listOf("Dimensión", "Grupo", "n", "Δ bb/100", "IC95%", "p", "q (BH)", "Sig."),
            order.take(12).map { i ->
                val r = res[i]
                listOf<Any>(r.dim, r.lab, r.n, Tone((if (r.eff >= 0) "+" else "") + f1(r.eff), if (q[i] < .05) toneOf(r.eff) else 0), f1(r.eff - 1.96 * r.se) + " a " + f1(r.eff + 1.96 * r.se), fmtP(res[i].p), fmtP(q[i]), starsOf(q[i]))
            }, listOf(110, 100, 56, 74, 110, 62, 62, 48)
        )
        Formula("Welch grupo vs complemento: t = (x̄_g − x̄_c)/√(s_g²/n_g + s_c²/n_c).\nSe realizan ${res.size} contrastes: sin corrección, ~5% saldrían «significativos» por azar. BH controla la tasa de falsos descubrimientos.")
    }
}

// ===================== REVISIÓN =====================
@Composable
private fun SciRev(e: Env) {
    val hs = e.hs
    val m = LinkedHashMap<String, ArrayList<Double>>()
    for (h in hs) for ((t, _) in flags(h)) m.getOrPut(t) { ArrayList() }.add(h.nb)
    if (m.isEmpty()) return
    LabDivider("Capa científica · coste de los errores")
    val rows = m.entries.map { (t, v) ->
        val d = describe(v.toDoubleArray())
        val w = wl(v.size.toDouble(), hs.size.toDouble())
        val se = if (v.size > 1) d.sd / sqrt(v.size.toDouble()) else 0.0
        listOf<Any>(t, v.size, f2(100.0 * v.size / hs.size) + "%", f2(w.first) + "–" + f2(w.second), Tone(f2(d.mean), toneOf(d.mean)), f2(d.mean - 1.96 * se) + " a " + f2(d.mean + 1.96 * se), Tone(f1(v.sum()), toneOf(v.sum())), Tone(f1(v.sum() / hs.size * 100), toneOf(v.sum())))
    }
    Sec("Frecuencia y coste con intervalos") {
        Table(listOf("Alerta", "Casos", "Frecuencia", "IC95% Wilson", "bb/mano", "IC95% media", "Total bb", "bb/100 manos"), rows, listOf(190, 56, 80, 100, 66, 120, 66, 90))
        Formula("coste esperado por 100 manos = frecuencia × coste medio × 100\nIC de la frecuencia: Wilson; IC del coste medio: x̄ ± 1.96·s/√n.")
    }
    Sec("Pareto del coste total") {
        val z = m.entries.map { (t, v) -> t to abs(v.sum()) }.sortedByDescending { it.second }.take(8)
        ParetoChart(z.map { it.first }, z.map { it.second })
        Caption("Coste absoluto acumulado de cada tipo de alerta; ataca primero las barras de la izquierda.")
    }
}

// ===================== TORNEOS =====================
@Composable
private fun SciTor(e: Env) {
    val T = derived(e.hs, e.vm.evVer).tours
    if (T.size < 5) return
    val km = kaplanMeier(T.map { it.hs.size.toDouble() }.toDoubleArray(), T.map { it.bust }.toBooleanArray())
    val bust = T.count { it.bust }
    val wb = wl(bust.toDouble(), T.size.toDouble())
    val sp = spearman(T.map { it.hs.size.toDouble() }.toDoubleArray(), T.map { it.s.nb }.toDoubleArray())
    LabDivider("Capa científica · torneos")
    Sec("Supervivencia de torneos (Kaplan–Meier)") {
        Kpis(
            listOf(
                kp("Torneos", T.size.toString(), "$bust eliminados"), kp("Tasa de eliminación", f1(100.0 * bust / T.size) + "%", "IC95% " + f1(wb.first) + "–" + f1(wb.second)),
                kp("Mediana de supervivencia", if (km.median != null) fmtN(km.median) + " manos" else "no alcanzada", "S(t) ≤ 0.5"),
                kp("ρ de Spearman (manos vs neto)", f2(sp.first), sigText(sp.second))
            )
        )
        Spacer(Modifier.height(8.dp))
        FunnelChart(km.t, km.s.map { it * 100 }, km.lo.map { it * 100 }, km.hi.map { it * 100 }, PC.Blue, false, "%")
        Caption("Probabilidad de seguir vivo tras t manos, con banda de Greenwood 95%. Los torneos sin eliminación (en curso o terminados en premio) se tratan como censurados.")
        Formula("S(t) = Π_{t_i ≤ t} (1 − d_i/n_i)     Var[S] = S²·Σ d_i/(n_i(n_i−d_i))   (Greenwood)")
    }
    Sec("Distribución del resultado por torneo") {
        val nets = T.map { it.s.nb }
        val lo = nets.min(); val hi = nets.max()
        val w = max(1e-9, (hi - lo) / 12)
        val cnt = DoubleArray(12)
        for (v in nets) cnt[min(11, ((v - lo) / w).toInt())]++
        BarChart(List(12) { f1(lo + w * it) }, cnt.map { 100 * it / nets.size }, true)
        Caption("% de torneos por tramo de resultado neto (bb). Una cola derecha larga es normal en MTT: pocos torneos aportan casi todo el beneficio.")
        val d = describe(nets.toDoubleArray())
        Muted("Media " + f1(d.mean) + " bb · mediana " + f1(nets.sorted()[nets.size / 2]) + " bb · asimetría " + f2(d.skew) + " · curtosis exceso " + f1(d.kurt))
    }
}

// ===================== RANGO =====================
@Composable
private fun SciRan(e: Env) {
    val hs = e.hs
    class CC { var n = 0; var v = 0 }
    val m = HashMap<String, CC>()
    var N = 0; var V = 0
    for (h in hs) { val c = h.cards ?: continue; val o = m.getOrPut(hk(c)) { CC() }; o.n++; o.v += h.vpip; N++; V += h.vpip }
    if (N < 300) return
    val pAll = V.toDouble() / N
    val rows = m.entries.filter { it.value.n >= 15 }.map { (k, o) ->
        val p = o.v.toDouble() / o.n
        val z = (p - pAll) / sqrt(pAll * (1 - pAll) / o.n)
        Triple(k, o, z)
    }
    if (rows.size < 5) return
    val pv = rows.map { 2 * (1 - normCdf(abs(it.third))) }
    val q = bhAdjust(pv)
    val order = rows.indices.sortedByDescending { abs(rows[it].third) }.take(10)
    LabDivider("Capa científica · rangos")
    Sec("Clases de mano que se desvían de tu VPIP medio") {
        Table(
            listOf("Mano", "n", "VPIP", "Δ vs media", "IC95% Wilson", "z", "p", "q (BH)", "Sig."),
            order.map { i ->
                val (k, o, z) = rows[i]
                val w = wl(o.v.toDouble(), o.n.toDouble())
                listOf<Any>(k, o.n, f1(100.0 * o.v / o.n) + "%", Tone((if (z >= 0) "+" else "") + f1(100 * (o.v.toDouble() / o.n - pAll)), if (q[i] < .05) toneOf(z) else 0), f1(w.first) + "–" + f1(w.second), f2(z), fmtP(pv[i]), fmtP(q[i]), starsOf(q[i]))
            }, listOf(70, 50, 64, 80, 110, 52, 62, 62, 48)
        )
        Formula("H₀: la clase se juega con la misma frecuencia que tu media (p̂₀ = ${f1(100 * pAll)}%).\nz = (p̂_c − p̂₀)/√(p̂₀(1−p̂₀)/n_c). Con ${rows.size} clases contrastadas se aplica BH.\nEn la matriz, la métrica «z» colorea cada celda con este estadístico.")
    }
}

// ===================== POSICIONES / AVANZADO =====================
@Composable
private fun GroupInference(title: String, labels: List<String>, groups: List<List<Hand>>, note: String) {
    val items = labels.indices.filter { groups[it].size >= 10 }
    if (items.size < 2) return
    Sec(title) {
        val rows = items.map { i ->
            val z = groups[i]
            val d = describe(DoubleArray(z.size) { z[it].nb })
            val se = 100 * d.sd / sqrt(z.size.toDouble())
            ForestRow(labels[i] + " (n=" + z.size + ")", d.mean * 100, d.mean * 100 - 1.96 * se, d.mean * 100 + 1.96 * se, null, null)
        }
        val ax = axisOf(rows)
        ForestPlot(rows, ax.first, ax.second) { f1(it) }
        Caption("bb/100 con IC95% por grupo.")
        val a = anovaOf(items.map { groups[it] })
        if (a != null) Kpis(listOf(kp("ANOVA F(" + a.d1 + ", " + a.d2 + ")", f2(a.f), sigText(a.p)), kp("η² (efecto)", f2(a.eta2), if (a.eta2 < .01) "efecto pequeño" else if (a.eta2 < .06) "efecto moderado" else "efecto grande")))
        Muted(note)
    }
}

@Composable
private fun SciPos(e: Env) {
    val hs = e.hs
    LabDivider("Capa científica · posiciones")
    GroupInference("Diferencias de resultado entre posiciones", PO, PO.map { p -> hs.filter { it.pos == p } }, "H₀: el winrate es igual en todas las posiciones. En póker el ruido por mano es enorme, así que η² suele ser pequeño aunque el p sea bajo.")
    Formula("F = [SSB/(k−1)] / [SSW/(N−k)] ~ F(k−1, N−k)     η² = SSB/(SSB+SSW)\nP(F > f) = I_x(d₂/2, d₁/2),  x = d₂/(d₂+d₁f)   (beta incompleta regularizada)")
}

@Composable
private fun SciAv(e: Env) {
    val hs = e.hs
    LabDivider("Capa científica · avanzado")
    val zones = listOf("Verde" to (20.0 to 1e9), "Amarilla" to (10.0 to 20.0), "Naranja" to (6.0 to 10.0), "Roja" to (0.0 to 6.0))
    GroupInference("Zonas de M: inferencia", zones.map { it.first }, zones.map { (_, r) -> hs.filter { it.M >= r.first && it.M < r.second } }, "Compara el winrate entre zonas de presión de ciegas; las zonas con poca muestra muestran intervalos anchos.")
    val by = HashMap<String, ArrayList<Hand>>()
    for (h in hs) by.getOrPut(h.tid) { ArrayList() }.add(h)
    val stg = listOf(ArrayList<Hand>(), ArrayList<Hand>(), ArrayList<Hand>())
    for (z0 in by.values) { val z = z0.sortedWith(CMP); z.forEachIndexed { i, h -> stg[min(2, 3 * i / z.size)].add(h) } }
    GroupInference("Etapas del torneo: inferencia", listOf("Inicio", "Medio", "Final"), stg, "Tercios de cada torneo en orden cronológico.")
    val nj = listOf("2" to (2..2), "3" to (3..3), "4-5" to (4..5), "6-9" to (6..9))
    GroupInference("Jugadores en mesa: inferencia", nj.map { it.first }, nj.map { (_, r) -> hs.filter { it.n in r } }, "Heads-up y mesas cortas tienen mucha más varianza por mano.")
}

// ===================== PATRONES =====================
@Composable
private fun SciPat(e: Env) {
    val hs = e.hs; val s = e.s
    val x = derived(hs, e.vm.evVer).ctx
    val R_ = rows(s, x).filter { it.e.f == null && it.e.u == "%" && it.z >= 20 && it.e.w > 0 }
    if (R_.isEmpty()) return
    LabDivider("Capa científica · patrones")
    Sec("Efecto mínimo detectable con tu muestra (potencia 80%)") {
        Table(
            listOf("Estadística", "n", "p̂", "MDE (pts)", "Banda ideal", "¿Fuera de banda?"),
            R_.map { r ->
                val p = (r.v ?: 0.0) / 100
                val mde = 2.8 * sqrt(max(1e-6, p * (1 - p)) / r.z) * 100
                listOf<Any>(r.e.name, fmtN(r.z), f1(100 * p) + "%", f1(mde), fmtB(r.e.lo) + "–" + fmtB(r.e.hi), if (r.pv != null && r.pv < .05) Tone("sí · p=" + fmtP(r.pv), -1) else "no")
            }, listOf(180, 56, 60, 72, 90, 130)
        )
        Formula("MDE ≈ (z_{1−α/2} + z_{1−β})·√(p̂(1−p̂)/n) = 2.8·EE   (α = 0.05, potencia 80%)\nDesviaciones menores que el MDE no se pueden distinguir del ruido con esta muestra.")
    }
    val ef = R_.filter { it.eff != null && abs(it.eff) > 0 }.sortedByDescending { abs(it.eff!!) }.take(8)
    if (ef.isNotEmpty()) Sec("Pareto del tamaño del efecto (|h| de Cohen)") {
        ParetoChart(ef.map { it.e.name }, ef.map { abs(it.eff!!) })
        Caption("|h| frente al límite más cercano de la banda ideal: 0.2 pequeño, 0.5 medio, 0.8 grande.")
    }
}

// ===================== MANOS CLAVE =====================
@Composable
private fun SciMan(e: Env) {
    val x = e.hs.map { it.nb }
    if (x.size < 50) return
    val sorted = x.sorted()
    val med = sorted[sorted.size / 2]
    val mad = x.map { abs(it - med) }.sorted()[x.size / 2]
    val out = if (mad > 0) x.count { abs(0.6745 * (it - med) / mad) > 3.5 } else 0
    val ab = x.map { abs(it) }
    val gini = giniOf(ab)
    val srt = ab.sortedDescending()
    val tot = ab.sum()
    val top1 = srt.take(max(1, srt.size / 100)).sum() / tot
    val lor = ab.sorted()
    val lz = ArrayList<Double>(); var acc = 0.0
    val step = max(1, lor.size / 100)
    for (i in lor.indices) { acc += lor[i]; if ((i + 1) % step == 0) lz.add(100 * acc / tot) }
    val diag = List(lz.size) { 100.0 * (it + 1) / lz.size }
    LabDivider("Capa científica · manos clave")
    Sec("Concentración del resultado (Lorenz y Gini)") {
        Kpis(
            listOf(
                kp("Gini de |resultado|", f2(gini), if (gini > .8) "muy concentrado" else "concentrado"), kp("Top 1% de manos", f1(100 * top1) + "%", "del movimiento total"),
                kp("Outliers (MAD)", out.toString(), "|z robusto| > 3.5"), kp("Mediana / MAD", f2(med) + " / " + f2(mad), "bb")
            )
        )
        Spacer(Modifier.height(8.dp))
        MultiLine(listOf(lz, diag), listOf(PC.Ac2, PC.Mu), listOf("Curva de Lorenz", "Igualdad perfecta"))
        Caption("% acumulado del movimiento total de fichas (|resultado|) frente al % de manos ordenadas de menor a mayor. Cuanto más se curva, más depende tu resultado de pocas manos.")
        Formula("Gini = 2·Σ i·x_(i) / (n·Σ x) − (n+1)/n\nz robusto = 0.6745·(x − mediana)/MAD; |z| > 3.5 marca valores atípicos (Iglewicz–Hoaglin).")
    }
}

// ===================== EXPLORADOR =====================
@Composable
private fun SciHnd(e: Env) {
    val vm = e.vm; val hs = e.hs; val f = vm.hf
    val q = f.q.trim().lowercase()
    val L = hs.filter { h ->
        (f.pos == "all" || h.pos == f.pos) &&
            (f.r == "all" || (if (f.r == "w") h.nb > 0 else if (f.r == "l") h.nb < 0 else if (f.r == "ai") h.anyAI == 1 else h.sd == 1)) &&
            (q.isEmpty() || (h.id + " " + h.tn + " " + (h.cards ?: emptyList()).joinToString("") + " " + (h.cards?.let { hk(it) } ?: "") + " " + (h.hc ?: "")).lowercase().contains(q))
    }
    if (L.size < 10) return
    LabDivider("Capa científica · selección")
    Sec("Resumen estadístico de la selección") {
        val d = describe(DoubleArray(L.size) { L[it].nb })
        val se = d.sd / sqrt(L.size.toDouble())
        val srt = L.map { it.nb }.sorted()
        val rest = hs.size - L.size
        val dAll = describe(DoubleArray(hs.size) { hs[it].nb })
        val wl0 = wl(L.count { it.nb > 0 }.toDouble(), L.size.toDouble())
        val cmp = if (rest >= 10) {
            val ids = L.map { it.id }.toHashSet()
            val sr = hs.filter { it.id !in ids }
            val dr = describe(DoubleArray(sr.size) { sr[it].nb })
            welch(d.mean, d.sd, L.size.toDouble(), dr.mean, dr.sd, sr.size.toDouble())
        } else null
        Kpis(
            listOf(
                kp("Manos", fmtN(L.size), pc(L.size.toDouble(), hs.size.toDouble()) + " del filtro"),
                kp("Media ± IC95%", f2(d.mean) + " ± " + f2(1.96 * se), "bb por mano", toneOf(d.mean)),
                kp("Mediana · RIC", f2(srt[srt.size / 2]), "Q1 " + f2(srt[srt.size / 4]) + " · Q3 " + f2(srt[3 * srt.size / 4])),
                kp("% ganadas", pc(L.count { it.nb > 0 }.toDouble(), L.size.toDouble()), "IC95% " + f1(wl0.first) + "–" + f1(wl0.second)),
                kp("Asimetría", f2(d.skew), "curtosis " + f1(d.kurt)),
                kp("vs resto", if (cmp == null) "–" else f2(cmp.diff * 100) + " bb/100", if (cmp == null) "" else sigText(cmp.p))
            )
        )
        Muted("Media global: " + f2(dAll.mean) + " bb por mano. El contraste usa la t de Welch con la selección frente al resto de tus manos.")
    }
}

// ===================== GRÁFICAS =====================
@Composable
private fun SciGra(e: Env) {
    val hs = e.hs
    val sw = hs.filter { it.saw == 1 }.map { it.nb }.sorted()
    LabDivider("Capa científica · gráficas")
    if (sw.size >= 50) {
        Sec("Función de distribución empírica con banda DKW") {
            val n = sw.size
            val eps = sqrt(ln(2 / 0.05) / (2.0 * n))
            val np = 150
            val xs = ArrayList<Double>(); val mid = ArrayList<Double>(); val lo = ArrayList<Double>(); val hi = ArrayList<Double>()
            for (i in 0 until np) {
                val k = min(n - 1, (i.toDouble() / (np - 1) * (n - 1)).toInt())
                val F = (k + 1.0) / n
                xs.add(sw[k]); mid.add(F * 100); lo.add(max(0.0, F - eps) * 100); hi.add(min(1.0, F + eps) * 100)
            }
            FunnelChart(xs, mid, lo, hi, PC.Blue, false, "%")
            Caption("ECDF del resultado por mano (manos con flop) y banda de confianza 95% de Dvoretzky–Kiefer–Wolfowitz (ε = " + f2(eps) + ").")
            Formula("F̂_n(x) = #{x_i ≤ x}/n     P(sup|F̂−F| > ε) ≤ 2·exp(−2nε²)   →   ε = √(ln(2/α)/(2n))")
        }
    }
    val w = min(1000, hs.size / 3)
    if (w >= 100) {
        Sec("bb/100 móvil con banda de confianza (ventana " + fmtN(w) + ")") {
            val x = DoubleArray(hs.size) { hs[it].nb }
            val sd = describe(x).sd
            val pre = DoubleArray(x.size + 1)
            for (i in x.indices) pre[i + 1] = pre[i] + x[i]
            val step = max(1, (x.size - w) / 120)
            val xs = ArrayList<Double>(); val mid = ArrayList<Double>(); val lo = ArrayList<Double>(); val hi = ArrayList<Double>()
            var i = w
            while (i <= x.size) {
                val m = (pre[i] - pre[i - w]) / w * 100
                val se = 100 * sd / sqrt(w.toDouble())
                xs.add(i.toDouble()); mid.add(m); lo.add(m - 1.96 * se); hi.add(m + 1.96 * se)
                i += step
            }
            FunnelChart(xs, mid, lo, hi, PC.Ac2, true, " bb/100")
            Caption("Media móvil de bb/100 con banda ±1.96·σ·100/√w. Una ventana por encima o por debajo de 0 con la banda separada indica rachas reales, no ruido.")
        }
    }
}

// ===================== CLARO =====================
@Composable
private fun SciCl(e: Env) {
    LabDivider("Capa científica · claro")
    Sec("Intervalos de confianza de las métricas clave") {
        PrecisionTable(e.s, listOf("vpip", "pfr", "t3", "cb", "wtsd", "wsd"))
        Caption("Cada porcentaje mostrado arriba debe leerse con este margen de error.")
    }
}
