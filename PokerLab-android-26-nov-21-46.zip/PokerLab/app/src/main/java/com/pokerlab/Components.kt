package com.pokerlab

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneOffset
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

val LocalOpen = staticCompositionLocalOf<(String) -> Unit> { {} }

fun Modifier.rise(): Modifier = composed {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, tween(450)) }
    graphicsLayer { alpha = a.value; translationY = (1 - a.value) * 36f }
}

@Composable
fun Muted(t: String, size: Int = 12) {
    Text(t, color = PC.Mu, fontSize = size.sp, lineHeight = (size + 5).sp, modifier = Modifier.padding(vertical = 2.dp))
}

class SecCounter(val tab: Int) {
    var n = 0
    fun next(): String { n++; return "$tab.$n" }
}

val LocalSecCounter = staticCompositionLocalOf<SecCounter?> { null }

@Composable
fun Sec(title: String, content: @Composable ColumnScope.() -> Unit) {
    val counter = LocalSecCounter.current
    val num = remember { counter?.next() }
    Column(Modifier.fillMaxWidth().rise().glass(18.dp, true).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(3.dp).height(14.dp).background(Brush.verticalGradient(listOf(PC.Ac2, PC.AcDeep)), RoundedCornerShape(2.dp)))
            Spacer(Modifier.width(8.dp))
            if (num != null) {
                Text("§" + num, color = PC.Ac2, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(7.dp))
            }
            Text(title.uppercase(), fontWeight = FontWeight.SemiBold, fontSize = 11.sp, letterSpacing = 1.sp, color = PC.Tx)
        }
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
fun Note(text: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).glass(12.dp).height(IntrinsicSize.Min)) {
        Box(Modifier.width(3.dp).fillMaxHeight().background(Brush.verticalGradient(listOf(PC.Ac2, PC.AcDeep))))
        Text(text, color = PC.Tx, fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.padding(12.dp))
    }
}

class Kpi(val label: String, val value: String, val sub: String = "", val tone: Int = 0, val spark: List<Double>? = null)

@Composable
fun KpiCard(k: Kpi, modifier: Modifier = Modifier) {
    val accent = when (k.tone) { 1 -> PC.Gd; -1 -> PC.Bd; else -> PC.Ac2 }
    Row(modifier.rise().glass(14.dp).height(IntrinsicSize.Min)) {
        Box(Modifier.width(3.dp).fillMaxHeight().background(Brush.verticalGradient(listOf(accent, accent.copy(alpha = .25f)))))
        Column(Modifier.padding(horizontal = 12.dp, vertical = 11.dp)) {
            Text(k.label.uppercase(), color = PC.Mu, fontSize = 10.sp, letterSpacing = .6.sp, maxLines = 1)
            Spacer(Modifier.height(2.dp))
            Text(
                k.value, fontSize = 21.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace,
                color = when (k.tone) { 1 -> PC.Gd; -1 -> PC.Bd; else -> PC.Tx }
            )
            if (k.sub.isNotEmpty()) Text(k.sub, color = PC.Mu, fontSize = 11.sp, lineHeight = 14.sp)
            k.spark?.let { Spacer(Modifier.height(4.dp)); Spark(it) }
        }
    }
}

@Composable
fun Kpis(items: List<Kpi>) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { KpiCard(it, Modifier.weight(1f)) }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

fun kp(label: String, value: String, sub: String = "", tone: Int = 0, spark: List<Double>? = null) = Kpi(label, value, sub, tone, spark)
fun toneOf(x: Double) = if (x >= 0) 1 else -1

// ===================== celdas de tabla =====================
class Tone(val t: String, val tone: Int = 0)
class PillC(val t: String)
class BulletC(val v: Double?, val lo: Double, val hi: Double, val h: Double?)
class CardsC(val c: List<String>?)
class TxtC(val t: String)

fun nbc(x: Double) = Tone(f1(x), toneOf(x))

@Composable
fun Pill(t: String) {
    val c = when {
        t.contains("Bajo") || t.contains("Alto") -> PC.Wn
        t.contains("En rango") || t == "Mejora" -> PC.Gd
        t == "Retroceso" -> PC.Bd
        t == "ALL-IN" -> PC.Ac2
        else -> PC.Mu
    }
    val sh = RoundedCornerShape(99.dp)
    Text(
        t, color = c, fontSize = 11.5.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.clip(sh).background(c.copy(alpha = .12f)).border(1.dp, c.copy(alpha = .35f), sh).padding(horizontal = 9.dp, vertical = 2.dp)
    )
}

@Composable
fun BulletMini(b: BulletC) {
    if (b.v == null || b.lo < 0) return
    val M = max(max(b.hi * 1.6, b.h ?: 0.0), b.v).let { if (it == 0.0) 1.0 else it }
    Canvas(Modifier.width(110.dp).height(14.dp)) {
        val y = size.height / 2
        drawRoundRect(PC.P2, Offset(0f, y - 3.dp.toPx()), Size(size.width, 6.dp.toPx()), CornerRadius(3.dp.toPx()))
        drawRoundRect(PC.Gd.copy(alpha = .45f), Offset((b.lo / M * size.width).toFloat(), y - 3.dp.toPx()), Size(((b.hi - b.lo) / M * size.width).toFloat(), 6.dp.toPx()), CornerRadius(3.dp.toPx()))
        drawRoundRect(PC.Tx, Offset((min(b.v / M, .98) * size.width).toFloat(), y - 7.dp.toPx()), Size(3.dp.toPx(), 14.dp.toPx()), CornerRadius(2.dp.toPx()))
    }
}

@Composable
fun CellView(c: Any, align: TextAlign = TextAlign.End) {
    when (c) {
        is Tone -> Text(c.t, color = when (c.tone) { 1 -> PC.Gd; -1 -> PC.Bd; else -> PC.Tx }, fontSize = 13.sp, textAlign = align, fontFamily = FontFamily.Monospace)
        is PillC -> Pill(c.t)
        is BulletC -> BulletMini(c)
        is CardsC -> Cards(c.c)
        is TxtC -> Text(c.t, color = PC.Mu, fontSize = 12.sp, lineHeight = 16.sp, maxLines = 5, textAlign = TextAlign.Start)
        else -> {
            val t = c.toString()
            val num = t.isNotEmpty() && (t[0].isDigit() || t[0] == '+' || t[0] == '-' || t[0] == '–')
            Text(t, color = PC.Tx, fontSize = 13.sp, textAlign = align, fontFamily = if (num) FontFamily.Monospace else FontFamily.Default)
        }
    }
}

@Composable
fun Table(headers: List<String>, rows: List<List<Any>>, widths: List<Int>? = null, onRow: ((Int) -> Unit)? = null, rowH: Int = 40) {
    if (rows.isEmpty()) { Muted("Sin datos."); return }
    val ws = widths ?: headers.indices.map { if (it == 0) 120 else 84 }
    val first = minOf(ws[0], 136)
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(PC.P)) {
        // columna fija
        Column(Modifier.width(first.dp).background(PC.P)) {
            Box(Modifier.height(34.dp).fillMaxWidth().background(PC.P2).padding(horizontal = 8.dp), contentAlignment = Alignment.CenterStart) {
                Text(headers[0], color = PC.Mu, fontSize = 11.sp, maxLines = 1)
            }
            rows.forEachIndexed { ri, r ->
                Box(
                    Modifier.height(rowH.dp).fillMaxWidth().then(if (onRow != null) Modifier.clickable { onRow(ri) } else Modifier).padding(horizontal = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) { CellView(r[0], TextAlign.Start) }
                HorizontalDivider(color = PC.Ln)
            }
        }
        // columnas con scroll horizontal
        Column(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
            Row(Modifier.height(34.dp).background(PC.P2), verticalAlignment = Alignment.CenterVertically) {
                headers.drop(1).forEachIndexed { i, h ->
                    Text(h, color = PC.Mu, fontSize = 11.sp, textAlign = TextAlign.End, maxLines = 2, lineHeight = 13.sp, modifier = Modifier.width(ws[i + 1].dp).padding(horizontal = 8.dp))
                }
            }
            rows.forEachIndexed { ri, r ->
                Row(Modifier.height(rowH.dp).then(if (onRow != null) Modifier.clickable { onRow(ri) } else Modifier), verticalAlignment = Alignment.CenterVertically) {
                    r.drop(1).forEachIndexed { i, c ->
                        Box(Modifier.width(ws[i + 1].dp).padding(horizontal = 8.dp), contentAlignment = if (c is TxtC) Alignment.CenterStart else Alignment.CenterEnd) { CellView(c) }
                    }
                }
                HorizontalDivider(color = PC.Ln)
            }
        }
    }
}

fun statTable(rs: List<SRes>): Pair<List<String>, List<List<Any>>> =
    listOf("Stat", "Valor", "IC95% Wilson", "Muestra", "Ref. MTT", "Rango", "Veredicto") to rs.map { r ->
        listOf<Any>(
            r.e.name, fv(r), if (r.l != null && r.h != null) f1(r.l) + "–" + f1(r.h) + "%" else "–",
            (if (r.a != null) fmtN(r.a) + "/" else "") + fmtN(r.z),
            fmtB(r.e.lo) + "–" + fmtB(r.e.hi) + unitOf(r.e), BulletC(r.v, r.e.lo, r.e.hi, r.h), PillC(verdict(r))
        )
    }

fun fmtB(x: Double): String = if (x == Math.floor(x)) x.toLong().toString() else x.toString()

@Composable
fun StatTbl(rs: List<SRes>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { rs.forEach { StatCard(it) } }
}

@Composable
fun StatCard(r: SRes) {
    val e = r.e
    Column(Modifier.fillMaxWidth().glass(12.dp).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(e.name, color = PC.Tx, fontSize = 13.sp)
                Muted("ref " + fmtB(e.lo) + "–" + fmtB(e.hi) + unitOf(e) + " · n=" + fmtN(r.z) + (if (r.l != null && r.h != null) " · IC95 " + f1(r.l) + "–" + f1(r.h) + "%" else "") + (if (r.pv != null && r.pv < 0.5) " · p=" + fmtP(r.pv) + " · h=" + f2(r.eff) else ""), 11)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(fv(r), color = PC.Tx, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace)
                Pill(verdict(r))
            }
        }
        if (r.v != null) {
            Spacer(Modifier.height(6.dp))
            val M = max(max(e.hi * 1.6, r.v), r.h ?: 0.0).let { if (it == 0.0) 1.0 else it }
            Canvas(Modifier.fillMaxWidth().height(14.dp)) {
                val y = size.height / 2
                fun cx(v: Double) = (min(100.0, 100 * v / M) / 100 * size.width).toFloat()
                drawRoundRect(PC.P, Offset(0f, y - 4.dp.toPx()), Size(size.width, 8.dp.toPx()), CornerRadius(4.dp.toPx()))
                drawRoundRect(PC.Gd.copy(alpha = .35f), Offset(cx(e.lo), y - 4.dp.toPx()), Size(cx(e.hi) - cx(e.lo), 8.dp.toPx()), CornerRadius(4.dp.toPx()))
                if (r.l != null && r.h != null) drawRect(PC.Tx.copy(alpha = .55f), Offset(cx(r.l), y - 1.dp.toPx()), Size(cx(r.h) - cx(r.l), 2.dp.toPx()))
                drawRoundRect(PC.Ac, Offset(cx(r.v) - 2.dp.toPx(), y - 7.dp.toPx()), Size(4.dp.toPx(), 14.dp.toPx()), CornerRadius(2.dp.toPx()))
            }
        }
    }
}

@Composable
fun Bullets(rs: List<SRes>) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        rs.forEach { r ->
            if (r.v == null) return@forEach
            val e = r.e
            val M = max(max(e.hi * 1.6, r.v), r.h ?: 0.0).let { if (it == 0.0) 1.0 else it }
            Column {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(e.name, color = PC.Tx, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Text(fv(r), color = PC.Tx, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Spacer(Modifier.width(8.dp))
                    Pill(verdict(r))
                }
                Spacer(Modifier.height(4.dp))
                Canvas(Modifier.fillMaxWidth().height(16.dp)) {
                    val y = size.height / 2
                    fun cx(v: Double) = (min(100.0, 100 * v / M) / 100 * size.width).toFloat()
                    drawRoundRect(PC.P2, Offset(0f, y - 5.dp.toPx()), Size(size.width, 10.dp.toPx()), CornerRadius(6.dp.toPx()))
                    drawRoundRect(PC.Gd.copy(alpha = .35f), Offset(cx(e.lo), y - 5.dp.toPx()), Size(cx(e.hi) - cx(e.lo), 10.dp.toPx()), CornerRadius(6.dp.toPx()))
                    if (r.l != null && r.h != null) drawRect(PC.Tx.copy(alpha = .5f), Offset(cx(r.l), y - 1.dp.toPx()), Size(cx(r.h) - cx(r.l), 2.dp.toPx()))
                    drawRoundRect(PC.Ac, Offset(cx(r.v) - 2.dp.toPx(), y - 9.dp.toPx()), Size(4.dp.toPx(), 18.dp.toPx()), CornerRadius(2.dp.toPx()))
                }
            }
        }
        Muted("La franja verde es el rango ideal, la línea fina el intervalo de confianza y el marcador rojo tu valor.")
    }
}

// ===================== cartas y manos =====================
val SUIT = mapOf('s' to "♠", 'h' to "♥", 'd' to "♦", 'c' to "♣")

@Composable
fun CardChip(c: String, small: Boolean = false) {
    if (c.length < 2) return
    val red = c[1] == 'h' || c[1] == 'd'
    val r = if (c[0] == 'T') "10" else c[0].toString()
    val shape = RoundedCornerShape(5.dp)
    Box(
        Modifier.padding(end = 3.dp).clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF2B1A21), Color(0xFF21141A))))
            .border(1.dp, if (red) Color(0xFF6B2A3A) else Color(0xFF4A2A35), shape)
            .padding(horizontal = if (small) 4.dp else 6.dp, vertical = 1.dp)
    ) {
        Text(r + (SUIT[c[1]] ?: ""), color = if (red) PC.Bd else PC.Tx, fontWeight = FontWeight.Bold, fontSize = if (small) 12.sp else 14.sp)
    }
}

@Composable
fun Cards(l: List<String>?, small: Boolean = false) {
    if (l.isNullOrEmpty()) Text("?", color = PC.Mu) else Row { l.forEach { CardChip(it, small) } }
}

@Composable
fun HandMini(h: Hand, modifier: Modifier = Modifier) {
    val open = LocalOpen.current
    val b = remember(h.id) { bdOf(h.raw) }
    Column(
        modifier.glass(14.dp).clickable { open(h.id) }.padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Cards(h.cards)
            Pill(h.pos)
            if (h.ai == 1) Pill("ALL-IN")
            Spacer(Modifier.weight(1f))
            Text((if (h.nb > 0) "+" else "") + f1(h.nb) + " bb", color = if (h.nb >= 0) PC.Gd else PC.Bd, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(6.dp))
        if (b.isEmpty()) Muted("sin flop") else Row { b.forEach { CardChip(it, true) } }
        Muted(h.tn.take(28) + " · " + f1(h.stack / h.bb) + " bb · " + (if (h.fs == "end") "llegó al final" else "fold en " + h.fs))
    }
}

@Composable
fun HandGrid(hs: List<Hand>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { hs.forEach { HandMini(it, Modifier.fillMaxWidth()) } }
}

@Composable
fun HandSec(title: String, hs: List<Hand>) {
    if (hs.isNotEmpty()) Sec(title) { HandGrid(hs) }
}

@Composable
fun HandDetail(h: Hand) {
    val open = LocalOpen.current
    val b = remember(h.id) { bdOf(h.raw) }
    val shows = remember(h.id) { Regex("""^(\S+): shows \[(\w\w) (\w\w)\] \((.*?)\)""", RegexOption.MULTILINE).findAll(h.raw).toList() }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Mesa: ", color = PC.Mu, fontSize = 13.sp)
            if (b.isEmpty()) Muted("sin flop") else b.forEach { CardChip(it, true) }
        }
        if (shows.isEmpty()) Muted("Sin showdown")
        shows.forEach { m ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (m.groupValues[1] == "Hero") "Tú: " else "Rival ${m.groupValues[1].take(4)}: ", fontSize = 13.sp, color = PC.Tx)
                Cards(listOf(m.groupValues[2], m.groupValues[3]), true)
                Muted(" " + m.groupValues[4])
            }
        }
        Muted("Resultado ${f1(h.nb)} bb · ${h.n} jugadores · ciega ${trimD(h.bb)} · stack ${f1(h.stack / h.bb)} bb${if (h.ai == 1) " · ALL-IN" else ""} · ${if (h.fs == "end") "llegaste al final" else "foldeaste en " + h.fs}")
        OutlinedButton(onClick = { open(h.id) }) { Text("▶ Repetir en la mesa") }
    }
}

fun trimD(x: Double) = if (x == Math.floor(x)) x.toLong().toString() else x.toString()

// ===================== controles =====================
@Composable
fun Drop(label: String, options: List<Pair<String, String>>, value: String, onPick: (String) -> Unit) {
    var e by remember { mutableStateOf(false) }
    val sh = RoundedCornerShape(99.dp)
    Box {
        Row(
            Modifier.clip(sh).background(Color.White.copy(alpha = .05f)).border(1.dp, PC.Edge1, sh).clickable { e = true }.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (label.isNotEmpty()) Text(label, color = PC.Mu, fontSize = 12.sp, maxLines = 1)
            Text(options.firstOrNull { it.first == value }?.second ?: value, color = PC.Tx, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            Spacer(Modifier.width(6.dp))
            Text("▾", color = PC.Mu, fontSize = 11.sp)
        }
        DropdownMenu(expanded = e, onDismissRequest = { e = false }) {
            options.forEach { (k, t) -> DropdownMenuItem(text = { Text(t) }, onClick = { onPick(k); e = false }) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateField(label: String, value: String, onChange: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val sh = RoundedCornerShape(99.dp)
    Text(
        if (value.isEmpty()) label else value, color = if (value.isEmpty()) PC.Mu else PC.Tx, fontSize = 13.sp,
        modifier = Modifier.clip(sh).background(Color.White.copy(alpha = .05f)).border(1.dp, PC.Edge1, sh).clickable { open = true }.padding(horizontal = 14.dp, vertical = 8.dp)
    )
    if (open) {
        val st = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { open = false },
            confirmButton = {
                TextButton(onClick = {
                    st.selectedDateMillis?.let { onChange(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate().toString()) }
                    open = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { onChange(""); open = false }) { Text("Borrar") } }
        ) { DatePicker(state = st) }
    }
}

// ===================== repetidor de manos =====================
@Composable
fun ReplayDialog(h: Hand, onClose: () -> Unit, onSolve: (Hand, RpData, Int) -> Unit) {
    val d = remember(h.id) { buildReplay(h) }
    var i by remember(h.id) { mutableIntStateOf(0) }
    var playing by remember(h.id) { mutableStateOf(false) }
    val end = d.steps.size - 1
    LaunchedEffect(playing) {
        if (playing) {
            while (playing && i < end) { delay(1100); i++ }
            playing = false
        }
    }
    val s = d.steps[i.coerceIn(0, end)]
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize().padding(10.dp), shape = RoundedCornerShape(22.dp), color = Color(0xFF130B0F), border = BorderStroke(1.dp, PC.Edge1)) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Mano #${h.id} · ${h.pos} · ${f1(h.nb)} bb", fontWeight = FontWeight.SemiBold, color = PC.Tx, modifier = Modifier.weight(1f), fontSize = 14.sp
                    )
                    TextButton(onClick = onClose) { Text("✕ Cerrar") }
                }
                Box(Modifier.weight(1f).fillMaxWidth()) { RpTable(h, d, s) }
                Spacer(Modifier.height(8.dp))
                Text("Paso ${i + 1}/${d.steps.size} — ${s.t}", color = PC.Mu, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                if (rpCanSolve(s)) {
                    TextButton(onClick = { onSolve(h, d, i) }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Solver CFR HU · revisar spot") }
                }
                Slider(
                    value = i.toFloat(), onValueChange = { i = it.toInt() }, valueRange = 0f..max(end, 1).toFloat(),
                    colors = SliderDefaults.colors(thumbColor = PC.Ac, activeTrackColor = PC.Ac)
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { i = 0 }) { Text("⏮") }
                    OutlinedButton(onClick = { i = max(0, i - 1) }) { Text("◀") }
                    PrimaryButton(if (playing) "⏸ Pausa" else "▶ Reproducir", { if (playing) playing = false else { if (i >= end) i = 0; playing = true } })
                    OutlinedButton(onClick = { i = min(end, i + 1) }) { Text("▶") }
                    OutlinedButton(onClick = { i = end }) { Text("⏭") }
                }
            }
        }
    }
}

@Composable
private fun RpTable(h: Hand, d: RpData, s: RpStep) {
    val n = d.seats.size
    val hi = max(0, d.seats.indexOfFirst { it.second == "Hero" })
    fun u(v: Double) = f1(v / h.bb)
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val W = maxWidth; val Hh = maxHeight
        Box(
            Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 30.dp)
                .clip(RoundedCornerShape(50)).background(Brush.radialGradient(listOf(PC.Felt1, PC.Felt2)))
                .border(8.dp, PC.Rail, RoundedCornerShape(50))
        )
        // tablero y bote
        Row(Modifier.align(Alignment.Center).offset(y = (-26).dp)) {
            for (j in 0 until 5) {
                val c = s.bd.getOrNull(j)
                if (c != null) CardChip(c) else Box(Modifier.width(34.dp).height(24.dp).background(Color.White.copy(alpha = .08f), RoundedCornerShape(5.dp)).padding(end = 3.dp))
            }
        }
        Text("Bote ${u(s.pot)} bb · ${s.street}", color = PC.Mu, fontSize = 12.sp, modifier = Modifier.align(Alignment.Center).offset(y = 14.dp))
        d.seats.forEachIndexed { j, z ->
            val k = (j - hi + n) % n
            val a = PI / 2 + k * 2 * PI / n
            val fx = (0.5 + 0.40 * cos(a)).toFloat(); val fy = (0.5 + 0.43 * sin(a)).toFloat()
            val bx = (0.5 + 0.22 * cos(a)).toFloat(); val by = (0.5 + 0.24 * sin(a)).toFloat()
            val dx = (0.5 + 0.31 * cos(a)).toFloat(); val dy = (0.5 + 0.34 * sin(a)).toFloat()
            val o = s.P[z.second] ?: return@forEachIndexed
            val active = s.a == z.second
            Column(
                Modifier.offset(W * fx - 34.dp, Hh * fy - 30.dp).width(68.dp)
                    .graphicsLayer { alpha = if (o.f) .35f else 1f }
                    .clip(RoundedCornerShape(10.dp)).background(PC.P2)
                    .border(1.dp, if (active) PC.Ac else PC.Ln, RoundedCornerShape(10.dp)).padding(4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(if (z.second == "Hero") "Hero" else z.second.take(7), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = PC.Tx, maxLines = 1)
                Text(u(o.st) + " bb", color = PC.Mu, fontSize = 10.sp)
                if (!o.f) {
                    val c = o.c
                    if (c != null) Row { c.forEach { CardChip(it, true) } } else Text("♠ ♠", fontSize = 13.sp, color = PC.Ac)
                }
            }
            if (o.bet > 0) Text(
                u(o.bet), color = PC.P, fontWeight = FontWeight.Bold, fontSize = 11.sp,
                modifier = Modifier.offset(W * bx - 16.dp, Hh * by - 9.dp).clip(RoundedCornerShape(99.dp)).background(PC.Tx).padding(horizontal = 8.dp)
            )
            if (z.first == d.bt) Text(
                "D", color = PC.P, fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.offset(W * dx - 10.dp, Hh * dy - 10.dp).width(20.dp).clip(RoundedCornerShape(99.dp)).background(Color.White)
            )
        }
    }
}
