package com.pokerlab

import java.util.Locale
import kotlin.math.*

fun f1(x: Double?): String = if (x == null || x.isNaN() || x.isInfinite()) "–" else String.format(Locale.US, "%.1f", x)
fun f2(x: Double?): String = if (x == null || x.isNaN() || x.isInfinite()) "–" else String.format(Locale.US, "%.2f", x)
fun pc(a: Double, b: Double, d: Int = 1): String =
    if (b != 0.0) String.format(Locale.US, "%." + d + "f%%", 100 * a / b) else "–"
fun fmtN(n: Number): String = java.text.NumberFormat.getIntegerInstance().format(n.toLong())

class Agg {
    var n = 0
    var nb = 0.0
    val arr = ArrayList<Double>()
    val c = HashMap<String, Double>()
}

fun S(hs: List<Hand>): Agg {
    val s = Agg()
    for (h in hs) {
        s.n++; s.nb += h.nb; s.arr.add(h.nb)
        for ((k, v) in h.c) s.c[k] = (s.c[k] ?: 0.0) + v
    }
    return s
}

fun gc(s: Agg, k: String): Double = s.c[k] ?: 0.0
fun q(s: Agg, a: String, b: String, d: Int = 1): String = pc(gc(s, a), gc(s, b), d)

class Bres(val m: Double, val ci: Double, val sd: Double)

fun B(s: Agg): Bres {
    val n = s.n
    val m = if (n > 0) s.nb / n else 0.0
    val v = if (n > 1) s.arr.sumOf { (it - m) * (it - m) } / (n - 1) else 0.0
    return Bres(m * 100, 196 * sqrt(v / max(n, 1)), sqrt(v))
}

fun wl(a: Double, b: Double): Pair<Double, Double> {
    if (b == 0.0) return Pair(0.0, 100.0)
    val p = a / b; val z = 1.96
    val d = 1 + z * z / b
    val c = p + z * z / (2 * b)
    val m = z * sqrt(p * (1 - p) / b + z * z / (4 * b * b))
    return Pair(100 * (c - m) / d, 100 * (c + m) / d)
}

fun scr(v: Double?, lo: Double, hi: Double, t: Double): Double? {
    if (v == null) return null
    return if (v >= lo && v <= hi) 100.0 else max(0.0, 100 * (1 - (if (v < lo) lo - v else v - hi) / t))
}

class Ctx(
    val bad: Int, val sev: Int, val tilt: Double?, val tn: Int,
    val adjM: Double, val ci: Double, val evn: Int, val luck: Double
)

val NOCTX = Ctx(0, 0, null, 0, 0.0, 0.0, 0, 0.0)

class StatDef(
    val id: String, val name: String, val cat: String, val lo: Double, val hi: Double, val t: Double, val w: Double,
    val tl: String = "", val th: String = "", val min: Int = 20,
    val n: String = id + "_x", val d: String = id + "_o", val u: String = "%",
    val f: ((Agg, Ctx) -> Pair<Double?, Double>)? = null
)

private fun nn(a: Double?, b: Double): Pair<Double?, Double> = Pair(a, b)

val ST: List<StatDef> = run {
    val l = ArrayList<StatDef>()
    fun X(
        id: String, name: String, cat: String, lo: Number, hi: Number, t: Number, w: Number,
        tl: String = "", th: String = "", min: Int = 20, n: String = id + "_x", d: String = id + "_o",
        u: String = "%", f: ((Agg, Ctx) -> Pair<Double?, Double>)? = null
    ) {
        l.add(StatDef(id, name, cat, lo.toDouble(), hi.toDouble(), t.toDouble(), w.toDouble(), tl, th, min, n, d, u, f))
    }
    X("vpip", "VPIP", "Pre", 20, 30, 12, 2, "Entras en pocas manos: amplía en CO/BTN/SB con suited y conectadas jugables.", "Entras en demasiadas manos: poda manos débiles fuera de posición (blinds vs raise, UTG/MP).")
    X("pfr", "PFR", "Pre", 14, 22, 10, 2, "Subes poco: cada mano que juegas debería poder entrar subiendo (más agresión = más fold equity).", "Subes demasiado: revisa aperturas anchas desde UTG/MP.")
    X("gap", "Brecha VPIP–PFR", "Pre", 3, 8, 8, 1.5, "Casi no pagas: perfecto, pero vigila no ser demasiado transparente.", "Mucho call/limp: cada call preflop sin posición pierde ~EV. Sube o foldea.", u = "pt",
        f = { s, _ -> val a = gc(s, "vpip_o"); if (a > 0) nn(100 * (gc(s, "vpip_x") / a - gc(s, "pfr_x") / gc(s, "pfr_o")), a) else nn(null, 0.0) })
    X("rfi", "RFI (abres primero en el bote)", "Pre", 18, 35, 15, 1.5, "Abres poco cuando todos foldean: pierdes el robo de ciegas+antes (EV directo).", "Abres demasiado ancho desde posiciones tempranas.")
    X("lim", "Limp / overlimp", "Pre", 0, 4, 8, 1.5, "—", "Limpear regala iniciativa y deja entrar a las ciegas baratas. Sube (aislando) o foldea.")
    X("iso", "Subir a limpers (iso)", "Pre", 30, 65, 25, .7, "Dejas pasar limpers débiles: aislarlos en posición es una de las jugadas más rentables.", "Aíslas demasiado: cuidado con manos marginales fuera de posición.")
    X("t3", "3-bet (vs open)", "Pre", 5, 9, 5, 1.5, "Casi no re-subes: añade 3-bets de valor (QQ+/AK) y faroles con A5s-A2s/suited conectadas en posición.", "3-betear demasiado te deja sin manos para 4-bets rivales. Baja faroles.")
    X("sq", "Squeeze (vs open + caller)", "Pre", 3, 10, 6, .4, "Poco squeeze: con open+caller hay dinero muerto; squeezear con rango polarizado es rentable.", "Squeeze excesivo.")
    X("b4", "4-bet (tras abrir y recibir 3-bet)", "Pre", 5, 14, 8, .8, "Rara vez 4-beteas: foldear todo ante 3-bets te hace explotable (ver Fold a 3-bet).", "4-betear demasiado ancho.")
    X("f3", "Fold a 3-bet (tras abrir)", "Pre", 55, 70, 25, 1.5, "Foldeas poco ante 3-bet: con manos dominadas pierdes mucho. Más 4-bet de farol/valor y folds de manos débiles.", "Foldeas demasiado: un 3-bet a ≈3× el open es rentable como farol puro si foldeas más de ≈65%. Defiende con pares medios, Axs y broadways.")
    X("f4", "Fold a 4-bet (tras 3-betear)", "Pre", 40, 68, 25, .6, "Pagas/5-beteas mucho: tu 3-bet debe tener farol que foldea.", "Foldeas demasiado ante 4-bet: incluye algunas manos de 5-bet/call.")
    X("ffo", "Fold cuando te abren (info)", "Pre", 60, 80, 20, 0)
    X("cfo", "Call cuando te abren (info)", "Pre", 8, 22, 12, 0)
    X("stl", "Steal CO/BTN/SB", "Torneo", 33, 50, 20, 1.5, "Robas poco las ciegas: con antes, cada robo exitoso paga ciegas+antes (≈2.5–3 bb) sin ver flop.", "Robas demasiado: te castigan con 3-bets.")
    X("bbf", "Fold BB vs steal", "Torneo", 40, 58, 25, 1.5, "Foldeas poco en BB: pagas con manos dominadas.", "Foldeas demasiado en BB: con pot odds de ~30% a cerrar el trato (ya pusiste 1bb) deberías defender más de la mitad del rango vs BTN.")
    X("bb3", "3-bet BB vs steal", "Torneo", 7, 16, 8, .7, "Poco 3-bet desde BB: mezcla farol (A5s, suited) y valor.", "Demasiado 3-bet desde BB.")
    X("sb3", "3-bet SB vs steal (info)", "Torneo", 8, 20, 10, 0)
    X("shv", "Open-shove (≤15 bb, primero en el bote)", "Torneo", 25, 80, 35, 0)
    X("cvs", "Pagar all-in preflop (cuando te lo suben)", "Torneo", 15, 45, 25, 0)
    X("cb", "C-bet flop", "Post", 50, 70, 30, 2, "C-betteas poco como agresor: dejas pasar fold equity y bote.", "C-bet en exceso, sobre todo multiway y en flops mojados.")
    X("cbIP", "C-bet flop en posición (info)", "Post", 55, 80, 30, .3)
    X("cbOP", "C-bet flop fuera de posición (info)", "Post", 40, 65, 30, .3)
    X("cbH", "C-bet heads-up (info)", "Post", 55, 80, 30, .3)
    X("cbM", "C-bet multiway (info)", "Post", 25, 50, 30, .3)
    X("fcb", "Fold a C-bet (flop)", "Post", 40, 55, 25, 1.5, "Foldeas poco a c-bets: defiendes con manos que no alcanzan (ver defensa vs MDF).", "Foldeas demasiado a c-bets: te explotan apostando todo. Defiende pares, proyectos y overcards con backdoors.")
    X("rcb", "Raise a C-bet (info)", "Post", 5, 16, 10, .5)
    X("dnk", "Donk bet (flop)", "Post", 0, 7, 8, 1, "—", "Donk bet frecuente: pierdes la ventaja de checkear para pagar o subir. Usa check-raise.")
    X("xr_flop", "Check-raise flop", "Post", 6, 14, 8, 1, "Casi no check-raisees: sin check-raise tu rango de check es débil y explotable.", "Check-raise excesivo.")
    X("b2", "2º barril (turn tras c-bet)", "Post", 45, 60, 25, 1.5, "Abandonas muchas manos en turn tras c-betear: no capitalizas el flop.", "Barril turn excesivo: frena en turns peligrosos.")
    X("b3", "3er barril (river)", "Post", 35, 60, 25, 1, "Poco 3er barril: pierdes valor y faroles de river.", "3er barril demasiado frecuente.")
    X("fold_flop", "Fold a apuesta en flop (cualquiera)", "Post", 35, 52, 25, 1, "Foldeas poco en flop.", "Foldeas demasiado en flop.")
    X("fold_turn", "Fold a apuesta en turn", "Post", 40, 55, 25, 1, "Foldeas poco en turn.", "Foldeas demasiado en turn: los barriles te sacan de manos.")
    X("fold_river", "Fold a apuesta en river", "Post", 40, 55, 25, 1, "Pagas demasiado en river: bluff-catch solo con manos que bloquean faroles.", "Foldeas demasiado en river: te farolean sin riesgo.")
    X("wtsd", "WTSD", "Post", 25, 32, 10, 1.5, "Llegas poco a showdown: defiende más.", "Llegas demasiado: foldea más en river con manos de bluff-catch débiles.", n = "sd", d = "saw")
    X("wsd", "W\$SD", "Post", 48, 55, 15, 1.5, "Ganas poco en showdown: pagas con manos débiles.", "Muy alto: quizá foldeas demasiado y solo llegas con nuts.", n = "wsd", d = "sd")
    X("wsf", "Ganas cuando ves flop (WWSF)", "Post", 44, 52, 12, 1.2, "Pierdes mucho tras ver flop: demasiados botes perdidos sin pelear o sin showdown.", "—", n = "wsf", d = "saw")
    X("af", "Agresión (AF)", "Post", 1.5, 3, 1.5, 1.5, "Pagas más de lo que apuestas/subes.", "Muy agresivo: ¿tienes manos para respaldarlo?", u = "x",
        f = { s, _ ->
            var b = 0.0; var c = 0.0
            for (k in SK) { b += gc(s, "ab_$k"); c += gc(s, "ac_$k") }
            if (c > 0) nn(b / c, c) else nn(null, c)
        })
    X("afq", "Frecuencia de agresión (AFq)", "Post", 36, 52, 15, 1, "Poca frecuencia de apuesta/subida.", "Demasiada frecuencia.",
        f = { s, _ ->
            var b = 0.0; var c = 0.0; var f = 0.0
            for (k in SK) { b += gc(s, "ab_$k"); c += gc(s, "ac_$k"); f += gc(s, "af_$k") }
            val z = b + c + f
            if (z > 0) nn(100 * b / z, z) else nn(null, z)
        })
    X("osz", "Tamaño de open (bb)", "Mate", 2, 2.6, 1.2, 1, "Abres muy pequeño: dejas entrar a todo el mundo barato.", "Abres muy grande: arriesgas más para ganar lo mismo (con antes, 2–2.3 bb suele bastar).", u = "bb",
        f = { s, _ -> val z = gc(s, "osz_n"); if (z > 0) nn(gc(s, "osz_s") / z, z) else nn(null, z) })
    X("cbsz", "Tamaño de c-bet (% del bote)", "Mate", 25, 70, 30, 1, "C-bets muy pequeñas: tus manos fuertes no cobran suficiente.", "C-bets muy grandes: arriesgas mucho para ganar poco; en flops secos 33% suele bastar.",
        f = { s, _ -> val z = gc(s, "cbsz_n"); if (z > 0) nn(100 * gc(s, "cbsz_s") / z, z) else nn(null, z) })
    X("rbsz", "Tamaño de apuestas en river (% bote)", "Mate", 40, 100, 40, .7, "Apuestas muy pequeñas en river.", "Apuestas excesivas en river: tus faroles necesitan fold% más alto.",
        f = { s, _ -> val z = gc(s, "bsz_n_river"); if (z > 0) nn(100 * gc(s, "bsz_s_river") / z, z) else nn(null, z) })
    for (k in SK) X("mdf_$k", "Defensa vs MDF ($k)", "Mate", 85, 115, 40, .8, "Defiendes menos que el MDF: tu fold% te hace explotable por faroles.", "Defiendes más que el MDF: pagas de más (salvo que el rival farolee demasiado).",
        f = { s, _ ->
            val m = gc(s, "mdf_n_$k")
            if (m > 0) nn(100 * (1 - gc(s, "mf_x_$k") / m) / (gc(s, "mdf_s_$k") / m), m) else nn(null, 0.0)
        })
    X("flagr", "Manos con alerta heurística", "Disc", 0, 8, 20, 2, "—", "Muchas manos marcadas (limp, fold premium, calls débiles…). Revisa la pestaña Revisión.",
        f = { s, x -> nn(100.0 * x.bad / s.n, s.n.toDouble()) })
    X("sev", "Alertas graves", "Disc", 0, 2, 6, 1.5, "—", "Errores graves frecuentes (fold con premium, fold con M<6 con mano jugable…).",
        f = { s, x -> nn(100.0 * x.sev / s.n, s.n.toDouble()) })
    X("tilt", "Δ VPIP tras pérdida grande (≥10 bb)", "Disc", -3, 3, 15, 1.5, "Juegas más tight tras perder: posible miedo.", "Juegas más suelto tras perder: señal de tilt. Respira y vuelve a tu rango.", min = 30, u = "pt",
        f = { _, x -> nn(x.tilt, x.tn.toDouble()) })
    l
}

val SM: Map<String, StatDef> = ST.associateBy { it.id }
val CATN = linkedMapOf(
    "Pre" to "Preflop", "Post" to "Postflop", "Torneo" to "Torneo / stacks cortos",
    "Mate" to "Matemática (sizing y defensa)", "Disc" to "Disciplina"
)

class SRes(
    val e: StatDef, val v: Double?, val z: Double, val a: Double?, val l: Double?, val h: Double?,
    val ok: Boolean, val sc: Double?, val r: Double, val pv: Double? = null, val eff: Double? = null
)

fun SR(e: StatDef, s: Agg, x: Ctx): SRes {
    val v: Double?; val z: Double
    var a: Double? = null; var l: Double? = null; var h: Double? = null
    if (e.f != null) {
        val p = e.f.invoke(s, x); v = p.first; z = p.second
    } else {
        val aa = gc(s, e.n); z = gc(s, e.d)
        a = aa
        v = if (z > 0) 100 * aa / z else null
        val w = wl(aa, z); l = w.first; h = w.second
    }
    val ok = v != null && z >= e.min
    var pv: Double? = null; var eff: Double? = null
    val av = a
    if (e.f == null && e.u == "%" && av != null && z > 0 && v != null) {
        val ph = av / z; val lo = e.lo / 100; val hi = e.hi / 100
        if (ph < lo && lo > 0 && lo < 1) {
            val se0 = sqrt(lo * (1 - lo) / z)
            pv = normCdf((ph - lo) / se0); eff = 2 * asin(sqrt(ph)) - 2 * asin(sqrt(lo))
        } else if (ph > hi && hi > 0 && hi < 1) {
            val se0 = sqrt(hi * (1 - hi) / z)
            pv = 1 - normCdf((ph - hi) / se0); eff = 2 * asin(sqrt(ph)) - 2 * asin(sqrt(hi))
        } else { pv = 1.0; eff = 0.0 }
    }
    return SRes(e, v, z, a, l, h, ok, if (ok) scr(v, e.lo, e.hi, e.t) else null, z / (z + 30), pv, eff)
}

fun unitOf(e: StatDef): String = when (e.u) { "%" -> "%"; "x" -> ""; "pt" -> " pts"; else -> " " + e.u }
fun fv(r: SRes): String = if (r.v == null) "–" else (if (r.e.u == "x") f2(r.v) else f1(r.v)) + unitOf(r.e)

fun verdict(r: SRes): String {
    val e = r.e
    if (r.z == 0.0 || r.v == null) return "–"
    if (r.z < e.min) return "Muestra corta"
    if (r.l != null && r.h != null)
        return if (r.h < e.lo) "▼ Bajo" else if (r.l > e.hi) "▲ Alto" else if (r.v >= e.lo && r.v <= e.hi) "En rango" else "Inconcluso"
    return if (r.v < e.lo) "▼ Bajo" else if (r.v > e.hi) "▲ Alto" else "En rango"
}

fun rows(s: Agg, x: Ctx, cat: List<String>? = null): List<SRes> =
    ST.filter { cat == null || cat.contains(it.cat) }.map { SR(it, s, x) }

// ===== heurísticas de mano =====
fun chen(c: List<String>): Double {
    val V = mapOf('A' to 10.0, 'K' to 8.0, 'Q' to 7.0, 'J' to 6.0, 'T' to 5.0)
    fun v(x: Char): Double = V[x] ?: (x.digitToInt() / 2.0)
    val a = c[0][0]; val b = c[1][0]
    val hi: Char; val lo: Char
    if (RK.indexOf(a) <= RK.indexOf(b)) { hi = a; lo = b } else { hi = b; lo = a }
    if (a == b) return max(5.0, v(a) * 2)
    var s = v(hi)
    if (c[0][1] == c[1][1]) s += 2
    val g = RK.indexOf(lo) - RK.indexOf(hi) - 1
    s -= listOf(0, 1, 2, 4, 5)[min(g, 4)]
    if (g <= 1 && RK.indexOf(hi) > 2) s += 1
    return ceil(s)
}

fun flags(h: Hand): List<Pair<String, Int>> {
    h.fl?.let { return it }
    val cs = h.cards
    if (cs == null) { h.fl = emptyList(); return emptyList() }
    val o = ArrayList<Pair<String, Int>>()
    val c = chen(cs); val p = h.pos
    if (h.pa == 'c' && h.pr == 0 && h.pl == 0 && p != "SB") o.add("Limp primero en el bote" to 1)
    if (c >= 10 && h.pa == 'f' && h.pr <= 1 && h.M >= 8) o.add("Fold de mano premium" to 3)
    if (h.pa == 'r' && h.pr == 0 && h.pl == 0 && (p == "UTG" || p == "MP") && c < 6 && h.M > 12) o.add("Open débil en posición temprana" to 2)
    if (h.pa == 'c' && h.pr >= 1 && p != "BB" && c < 5.5 && h.M > 10) o.add("Call preflop con mano débil" to 2)
    if (h.M < 6 && h.pa == 'f' && h.pr == 0 && c >= 8 && p != "BB") o.add("Fold con M<6 (debía jamear)" to 3)
    if (h.sd == 1 && h.nb <= -20) o.add("Showdown muy caro (≥20 bb)" to 2)
    h.fl = o
    return o
}

fun ctx(hs: List<Hand>, s: Agg): Ctx {
    var bad = 0; var sev = 0
    for (h in hs) {
        val f = flags(h)
        if (f.isNotEmpty()) bad++
        if (f.any { it.second == 3 }) sev++
    }
    val by = HashMap<String, ArrayList<Hand>>()
    for (h in hs) by.getOrPut(h.tid) { ArrayList() }.add(h)
    var a1 = 0.0; var n1 = 0; var a0 = 0.0; var n0 = 0
    for (z in by.values) for (i in 1 until z.size) {
        if (z[i - 1].nb <= -10) { n1++; a1 += z[i].vpip } else { n0++; a0 += z[i].vpip }
    }
    val E = evSum(hs); val b = B(s)
    return Ctx(
        bad, sev, if (n1 >= 30 && n0 > 0) 100 * (a1 / n1 - a0 / n0) else null, n1,
        if (E.n > 0) (s.nb - E.luck) / s.n * 100 else b.m, b.ci, E.n, E.luck
    )
}

// ===== torneos =====
class Tour(val id: String, val name: String, val hs: ArrayList<Hand>) {
    var s0 = 0.0; var end = 0.0; var bust = false; var peak = 0.0; var t0 = 0L; var dur = 0.0
    var s: Agg = Agg()
}

fun tours(hs: List<Hand>): List<Tour> {
    val m = LinkedHashMap<String, Tour>()
    for (h in hs) m.getOrPut(h.tid) { Tour(h.tid, h.tn, ArrayList()) }.hs.add(h)
    return m.values.map { t ->
        t.hs.sortWith(CMP)
        val a = t.hs.first(); val z = t.hs.last()
        t.s0 = a.stack; t.end = z.stack + z.net; t.bust = t.end < 1
        t.peak = t.hs.maxOf { it.stack / it.bb }
        t.s = S(t.hs); t.t0 = a.ts; t.dur = (z.ts - a.ts) / 60000.0
        t
    }.sortedBy { it.t0 }
}

class DepB(val l: String, val s: Agg)

fun dep(hs: List<Hand>): List<DepB> =
    listOf(Triple("<10 bb", 0.0, 10.0), Triple("10–20 bb", 10.0, 20.0), Triple("20–40 bb", 20.0, 40.0), Triple("40+ bb", 40.0, 1e9))
        .map { (l, a, b) -> DepB(l, S(hs.filter { it.stack / it.bb >= a && it.stack / it.bb < b })) }

// ===== nivel =====
class Tier(val lo: Int, val name: String, val desc: String)

val TIERS = listOf(
    Tier(0, "Principiante", "Fundamentos por construir: rangos por posición y la regla “sube o foldea”."),
    Tier(20, "Novato", "Conoces lo básico pero hay fugas grandes (calls débiles, poco 3-bet, fold excesivo)."),
    Tier(30, "Recreativo bajo", "Juegas demasiadas manos o demasiado pasivo; el postflop es reactivo."),
    Tier(38, "Recreativo", "Rangos razonables en algunas posiciones, pero sin plan postflop consistente."),
    Tier(45, "Recreativo alto", "Buena base preflop; fallas en defensa de ciegas y barriles."),
    Tier(52, "Regular bajo", "Estadísticas cerca de rango; la ejecución aún varía mucho entre sesiones."),
    Tier(58, "Regular", "Perfil sólido de MTT: la mayoría de stats en rango y pocos errores graves."),
    Tier(64, "Regular alto", "Sizing coherente y defensas cercanas al MDF; ajustes por stack."),
    Tier(70, "Avanzado", "Rangos y frecuencias casi de referencia; fugas muy específicas."),
    Tier(78, "Semi-pro", "Todo en rango con muestra grande y resultado EV positivo."),
    Tier(86, "Profesional", "Consistencia alta, disciplina total, ajustes explotativos."),
    Tier(93, "Élite", "Referencia de solver en frecuencias y sizing con resultados sostenidos.")
)

class CatSc(val v: Double?, val W: Double)
class Imp(val r: SRes, val gain: Double)
class Lvl(
    val x: Ctx, val R: List<SRes>, val C: Map<String, CatSc>, val cw: Map<String, Double>,
    val raw: Double, val adj: Double, val a0: Double, val cap: Double, val fr: Double,
    val imp: List<Imp>, val ti: Tier, val tr: Tier, val nx: Tier?, val sh: Double
)

fun level(hs: List<Hand>, s: Agg, xin: Ctx? = null): Lvl {
    val x = xin ?: ctx(hs, s)
    val R_ = ST.map { SR(it, s, x) }
    val cw = linkedMapOf("Pre" to .27, "Post" to .30, "Torneo" to .10, "Mate" to .10, "Disc" to .13, "Res" to .10)
    val C = HashMap<String, CatSc>()
    for (c in cw.keys) {
        if (c == "Res") continue
        val z = R_.filter { it.e.cat == c && it.sc != null && it.e.w > 0 }
        val W = z.sumOf { it.e.w * it.r }
        C[c] = CatSc(if (W > 0) z.sumOf { it.sc!! * it.e.w * it.r } / W else null, W)
    }
    C["Res"] = CatSc(max(0.0, min(100.0, 40 + x.adjM - .5 * x.ci)), 1.0)
    val ok = cw.keys.filter { C[it]!!.v != null }
    val sw = ok.sumOf { cw[it]!! }
    val raw = ok.sumOf { C[it]!!.v!! * cw[it]!! } / sw
    val K = 1200.0; val prior = 38.0
    val sh = s.n / (s.n + K)
    val a0 = prior + (raw - prior) * sh
    val fr = hs.count { Regex("freeroll", RegexOption.IGNORE_CASE).containsMatchIn(it.tn) }.toDouble() / max(s.n, 1)
    val cap = if (fr > .7) 72.0 else 100.0
    val adj = min(a0, cap)
    val imp = R_.filter { it.sc != null && it.e.w > 0 && it.sc < 95 }.map { r ->
        val c = r.e.cat
        val gain = (100 - r.sc!!) * (r.e.w * r.r / C[c]!!.W) * (cw[c]!! / sw) * sh
        Imp(r, gain)
    }.sortedByDescending { it.gain }
    val ti = TIERS.lastOrNull { adj >= it.lo } ?: TIERS[0]
    val tr = TIERS.lastOrNull { raw >= it.lo } ?: TIERS[0]
    val nx = TIERS.getOrNull(TIERS.indexOf(ti) + 1)
    return Lvl(x, R_, C, cw, raw, adj, a0, cap, fr, imp, ti, tr, nx, sh)
}

fun isFreeroll(h: Hand) = h.tn.contains("freeroll", ignoreCase = true)
