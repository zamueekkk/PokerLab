package com.pokerlab

import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        setContent { PokerLabTheme { AppRoot() } }
    }
}

@Composable
fun TabBody(id: String, e: Env) {
    when (id) {
        "res" -> TabRes(e)
        "seg" -> TabSeg(e)
        "niv" -> TabNiv(e)
        "per" -> TabPer(e)
        "lab" -> TabLab(e)
        "pre" -> TabPre(e)
        "post" -> TabPost(e)
        "ev" -> TabEV(e)
        "solver" -> TabSolver(e)
        "fug" -> TabFug(e)
        "rev" -> TabRev(e)
        "tor" -> TabTor(e)
        "ran" -> TabRan(e)
        "pos" -> TabPos(e)
        "pat" -> TabPat(e)
        "man" -> TabMan(e)
        "hnd" -> TabHnd(e)
        "riv" -> TabRiv(e)
        "gra" -> TabGra(e)
        "av" -> TabAv(e)
        "cla" -> TabCl(e)
    }
    SciAddendum(id, e)
}

private val CL = linkedMapOf("all" to "Todo", "7" to "7 días", "30" to "30 días", "90" to "90 días", "mes" to "Este mes", "c" to "Personalizado")

@Composable
fun AppRoot() {
    val vm: MainVm = viewModel()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.importUris(it) }
    val export = rememberCsvExporter()
    var menu by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var editName by remember { mutableStateOf(false) }
    val pick = { picker.launch(arrayOf("text/plain", "*/*")) }

    BackHandler(enabled = vm.tour != null || drawer.isOpen) {
        if (drawer.isOpen) scope.launch { drawer.close() } else vm.tour = null
    }

    CompositionLocalProvider(LocalOpen provides { id -> vm.openReplay(id) }) {
        Box(Modifier.fillMaxSize().appBackground()) {
            ModalNavigationDrawer(
                drawerState = drawer,
                drawerContent = {
                    ModalDrawerSheet(
                        drawerContainerColor = Color(0xFF110A0E),
                        drawerShape = RoundedCornerShape(topEnd = 26.dp, bottomEnd = 26.dp)
                    ) {
                        Column(Modifier.verticalScroll(rememberScrollState()).statusBarsPadding().navigationBarsPadding().padding(bottom = 12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
                                LogoMark(52.dp)
                                Spacer(Modifier.width(14.dp))
                                Column {
                                    Text("Poker Lab", fontWeight = FontWeight.Bold, fontSize = 21.sp, color = PC.Tx)
                                    Text(if (vm.H.isEmpty()) "Analizador de torneos" else fmtN(vm.H.size) + " manos cargadas", fontSize = 12.sp, color = PC.Mu, fontFamily = FontFamily.Monospace)
                                }
                            }
                            HorizontalDivider(color = PC.Ln, modifier = Modifier.padding(horizontal = 20.dp))
                            val items = if (vm.H.isEmpty()) TABS.filterKeys { it == "solver" } else TABS
                            items.forEach { (k, v) ->
                                GROUPS[k]?.let {
                                    if (vm.H.isNotEmpty()) Text(it.uppercase(), color = PC.Mu.copy(alpha = .75f), fontSize = 10.sp, letterSpacing = 1.2.sp, modifier = Modifier.padding(start = 24.dp, top = 16.dp, bottom = 4.dp))
                                }
                                DrawerItem(TAB_ICON[k] ?: "grid", v, vm.tab == k && vm.tour == null) { vm.tab = k; vm.tour = null; scope.launch { drawer.close() } }
                            }
                        }
                    }
                }
            ) {
                Scaffold(
                    containerColor = Color.Transparent,
                    topBar = {
                        AppHeader(vm, onMenu = { scope.launch { drawer.open() } }, onAdd = pick) {
                            Box {
                                IconBtn("more", { menu = true })
                                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                    DropdownMenuItem(text = { Text("Cargar historial (.txt)") }, onClick = { menu = false; pick() })
                                    if (vm.H.isNotEmpty()) {
                                        DropdownMenuItem(text = { Text("Exportar CSV (filtro actual)") }, onClick = { menu = false; export(vm.filtered()) })
                                        DropdownMenuItem(text = { Text("Editar perfil") }, onClick = { menu = false; editName = true })
                                        DropdownMenuItem(text = { Text("Borrar historial guardado") }, onClick = { menu = false; confirmClear = true })
                                    }
                                }
                            }
                        }
                    },
                    bottomBar = { BottomNav(vm) { scope.launch { drawer.open() } } }
                ) { pad ->
                    Column(Modifier.padding(pad).fillMaxSize()) {
                        if (vm.importing) LinearProgressIndicator(Modifier.fillMaxWidth(), color = PC.Ac, trackColor = PC.P2)
                        when {
                            vm.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = PC.Ac) }
                            vm.H.isEmpty() && vm.tab != "solver" -> EmptyState(onPick = pick, onSolver = { vm.tab = "solver" })
                            else -> Content(vm)
                        }
                    }
                }
            }
        }

        val rid = vm.replayId
        if (rid != null) {
            val h = vm.H.find { it.id == rid }
            if (h != null) ReplayDialog(h, { vm.replayId = null }) { hh, d, i -> vm.sendToSolver(hh, d, i) }
        }
        if (vm.askName || editName) NameDialog(vm, editName) { editName = false }
        if (confirmClear) AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Borrar historial") },
            text = { Text("Se eliminarán las manos guardadas en este dispositivo. Tus archivos .txt originales no se tocan.") },
            confirmButton = { TextButton(onClick = { vm.clearAll(); confirmClear = false }) { Text("Borrar") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun AppHeader(vm: MainVm, onMenu: () -> Unit, onAdd: () -> Unit, more: @Composable () -> Unit) {
    val tours = remember(vm.H) { vm.H.map { it.tid }.toSet().size }
    val title = if (vm.tour != null) "Torneo" else TABS[vm.tab] ?: ""
    val sub = if (vm.H.isEmpty()) "Sin historial cargado" else fmtN(vm.H.size) + " manos · " + tours + " torneos"
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        IconBtn("menu", onMenu)
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = PC.Tx, maxLines = 1)
            Text(sub, fontSize = 11.5.sp, color = PC.Mu, fontFamily = FontFamily.Monospace, maxLines = 1)
        }
        IconBtn("plus", onAdd, PC.Ac2)
        more()
    }
}

@Composable
private fun DrawerItem(icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp).clip(RoundedCornerShape(14.dp))
            .background(if (selected) PC.Ac.copy(alpha = .16f) else Color.Transparent).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TabIcon(icon, if (selected) PC.Ac2 else PC.Mu, 20.dp)
        Spacer(Modifier.width(14.dp))
        Text(label, fontSize = 14.sp, color = if (selected) PC.Tx else PC.Mu, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun Content(vm: MainVm) {
    val scroll = rememberScrollState()
    LaunchedEffect(vm.tab, vm.tour, vm.tt) { scroll.scrollTo(0) }
    val counter = remember(vm.tab, vm.tour, vm.tt) { SecCounter(TABS.keys.indexOf(vm.tab) + 1) }
    CompositionLocalProvider(LocalSecCounter provides counter) {
        Column(Modifier.fillMaxSize()) {
            if (vm.tour == null && vm.H.isNotEmpty()) FilterBar(vm)
            Column(
                Modifier.weight(1f).verticalScroll(scroll).padding(horizontal = 14.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                val t = vm.tour
                if (t != null) TourScreen(vm, t) else MainTab(vm)
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun MainTab(vm: MainVm) {
    val seg = vm.tab == "seg"
    val fh = remember(vm.H, vm.sel, vm.dr, seg) { vm.filtered() }
    val s = remember(fh) { S(fh) }
    if (vm.tab != "solver" && fh.isNotEmpty()) LabStrip(fh, vm.evVer)
    if (vm.tab == "solver") TabSolver(Env(vm, fh, s))
    else if (fh.isEmpty()) Muted("Sin manos en este filtro.")
    else TabBody(vm.tab, Env(vm, fh, s))
}

@Composable
private fun FilterBar(vm: MainVm) {
    val T = remember(vm.H) { tours(vm.H) }
    val opts = remember(T, vm.H.size) {
        listOf("all" to "Todos (${vm.H.size} manos)", "fr" to "Solo freerolls", "pd" to "Solo con buy-in") + T.map { it.id to (it.name.take(30) + " · " + it.id + " (" + it.hs.size + ")") }
    }
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        Drop("Torneo ", opts, vm.sel) { vm.sel = it }
        if (vm.tab != "seg") {
            Box(Modifier.width(1.dp).height(22.dp).background(PC.Ln))
            CL.forEach { (k, v) ->
                FilterChip(selected = vm.dr.m == k, onClick = { vm.dr = Rng(k, vm.dr.f, vm.dr.t) }, label = { Text(v) })
            }
            if (vm.dr.m == "c") {
                DateField("Desde", vm.dr.f) { vm.dr = Rng("c", it, vm.dr.t) }
                DateField("Hasta", vm.dr.t) { vm.dr = Rng("c", vm.dr.f, it) }
            }
        }
    }
}

@Composable
private fun BottomNav(vm: MainVm, onMore: () -> Unit) {
    val items = listOf("res" to "Resumen", "pre" to "Preflop", "post" to "Postflop", "ran" to "Rangos", "solver" to "Solver")
    Row(
        Modifier.fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xFF1B1016), Color(0xFF120A0E))))
            .drawBehind { drawLine(PC.Edge1, Offset(0f, 0f), Offset(size.width, 0f), 1.dp.toPx()) }
            .navigationBarsPadding().padding(horizontal = 6.dp, vertical = 6.dp)
    ) {
        items.forEach { (k, l) -> NavItem(TAB_ICON[k] ?: "grid", l, vm.tab == k && vm.tour == null) { vm.tab = k; vm.tour = null } }
        NavItem("menu", "Más", false, onMore)
    }
}

@Composable
private fun RowScope.NavItem(icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) PC.Ac.copy(alpha = .2f) else Color.Transparent, label = "nav")
    Column(
        Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.width(54.dp).height(30.dp).clip(RoundedCornerShape(15.dp)).background(bg), contentAlignment = Alignment.Center) {
            TabIcon(icon, if (selected) PC.Ac2 else PC.Mu, 22.dp)
        }
        Spacer(Modifier.height(2.dp))
        Text(label, fontSize = 11.sp, color = if (selected) PC.Tx else PC.Mu, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1)
    }
}

@Composable
private fun FeatureRow(icon: String, title: String, sub: String) {
    Row(Modifier.fillMaxWidth().glass(14.dp).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(PC.Ac.copy(alpha = .16f)), contentAlignment = Alignment.Center) { TabIcon(icon, PC.Ac2, 22.dp) }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = PC.Tx, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(sub, color = PC.Mu, fontSize = 12.sp, lineHeight = 16.sp)
        }
    }
}

@Composable
private fun EmptyState(onPick: () -> Unit, onSolver: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        LogoMark(112.dp)
        Spacer(Modifier.height(18.dp))
        Text("Poker Lab", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = PC.Tx)
        Spacer(Modifier.height(4.dp))
        Text("Análisis científico de tus torneos de póker", color = PC.Mu, textAlign = TextAlign.Center, fontSize = 14.sp)
        Spacer(Modifier.height(22.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            FeatureRow("grid", "Rangos 13×13 interactivos", "Mapas de VPIP, PFR y resultado por mano y posición")
            FeatureRow("tree", "Solver CFR+ heads-up", "Estrategia por nodo, equity y revisión de tus decisiones")
            FeatureRow("gauge", "Perfil y nivel estimado", "Estadísticas con IC 95 % frente a rangos de referencia")
        }
        Spacer(Modifier.height(22.dp))
        PrimaryButton("Cargar historial (.txt)", onPick, Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        GhostButton("Abrir el solver", onSolver, Modifier.fillMaxWidth())
        Spacer(Modifier.height(14.dp))
        Muted("Todo se procesa en tu teléfono; no se sube nada.")
    }
}

@Composable
private fun NameDialog(vm: MainVm, edit: Boolean, onDone: () -> Unit) {
    var v by remember { mutableStateOf(vm.uname) }
    AlertDialog(
        onDismissRequest = { vm.skipName(); onDone() },
        containerColor = PC.P2,
        title = { Text(if (edit) "Tu perfil" else "Bienvenido a Poker Lab") },
        text = {
            Column {
                Text("¿Cómo quieres que te llame?", color = PC.Mu)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(v, { v = it.take(24) }, singleLine = true, placeholder = { Text("Tu nombre") })
            }
        },
        confirmButton = { TextButton(onClick = { vm.setName(v.ifBlank { "Jugador" }); onDone() }) { Text("Entrar a la mesa") } },
        dismissButton = { TextButton(onClick = { vm.skipName(); onDone() }) { Text("Omitir") } }
    )
}
