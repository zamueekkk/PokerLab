package com.pokerlab

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Línea central con banda de confianza (convergencia / embudo). */
@Composable
fun FunnelChart(xs: List<Double>, mid: List<Double>, lo: List<Double>, hi: List<Double>, color: Color = PC.Ac2, zero: Boolean = true, unit: String = "") {
    if (xs.size < 3) { Muted("Pocas manos."); return }
    val tm = rememberTextMeasurer()
    val prog = rememberProg(xs, 1000)
    Canvas(Modifier.fillMaxWidth().height(210.dp)) {
        val g = geo()
        var a = lo.min(); var b = hi.max()
        if (zero) { a = min(a, 0.0); b = max(b, 0.0) }
        val (y0, y1, t) = nice(a, b)
        val Y = drawGrid(tm, y0, y1, t, g)
        val xa = xs.first(); val xb = xs.last()
        val X = { v: Double -> (g.pl + (v - xa) / (xb - xa) * (size.width - g.pl - g.pr)).toFloat() }
        for (k in 0..4) { val v = xa + (xb - xa) * k / 4; txt(tm, fmtN(v), X(v), size.height - 8.dp.toPx(), labelStyle, 1) }
        clipRect(right = g.pl + (size.width - g.pl) * prog) {
            val band = Path()
            xs.indices.forEach { i -> if (i == 0) band.moveTo(X(xs[i]), Y(hi[i])) else band.lineTo(X(xs[i]), Y(hi[i])) }
            for (i in xs.indices.reversed()) band.lineTo(X(xs[i]), Y(lo[i]))
            band.close()
            drawPath(band, color.copy(alpha = .16f))
            val line = Path()
            xs.indices.forEach { i -> if (i == 0) line.moveTo(X(xs[i]), Y(mid[i])) else line.lineTo(X(xs[i]), Y(mid[i])) }
            drawPath(line, color, style = Stroke(2.dp.toPx(), join = StrokeJoin.Round))
        }
        txt(tm, f1(mid.last()) + unit, size.width - g.pr - 4.dp.toPx(), Y(mid.last()) - 12.dp.toPx(), valueStyle, 2)
    }
}

/** Gráfico cuantil-cuantil frente a la normal (datos estandarizados). */
@Composable
fun QQPlot(th: DoubleArray, sm: DoubleArray) {
    if (th.size < 5) { Muted("Pocas manos."); return }
    val tm = rememberTextMeasurer()
    val prog = rememberProg(th, 900)
    Canvas(Modifier.fillMaxWidth().height(240.dp)) {
        val g = geo()
        val (lo, hi, t) = nice(min(th.min(), sm.min()), max(th.max(), sm.max()))
        val Y = drawGrid(tm, lo, hi, t, g)
        val X = { v: Double -> (g.pl + (v - lo) / (hi - lo) * (size.width - g.pl - g.pr)).toFloat() }
        t.forEach { txt(tm, fmtTick(it), X(it), size.height - 8.dp.toPx(), labelStyle, 1) }
        drawLine(PC.Ac2.copy(alpha = .7f), Offset(X(lo), Y(lo)), Offset(X(hi), Y(hi)), 1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f)))
        val npt = (th.size * prog).toInt()
        for (i in 0 until npt) drawCircle(PC.Gd.copy(alpha = .7f), 2.6.dp.toPx(), Offset(X(th[i]), Y(sm[i])))
        txt(tm, "cuantiles normales →", size.width - g.pr, size.height - 24.dp.toPx(), labelStyle, 2)
    }
}

/** Abanico de percentiles 5-25-50-75-95 de trayectorias simuladas. */
@Composable
fun FanChart(xs: List<Double>, q: List<DoubleArray>) {
    if (q.size < 5 || xs.size < 3) return
    val tm = rememberTextMeasurer()
    val prog = rememberProg(q, 1000)
    Canvas(Modifier.fillMaxWidth().height(230.dp)) {
        val g = geo()
        val (lo, hi, t) = nice(min(0.0, q[0].min()), max(0.0, q[4].max()))
        val Y = drawGrid(tm, lo, hi, t, g)
        val xa = xs.first(); val xb = xs.last()
        val X = { v: Double -> (g.pl + (v - xa) / (xb - xa) * (size.width - g.pl - g.pr)).toFloat() }
        for (k in 0..4) { val v = xa + (xb - xa) * k / 4; txt(tm, fmtN(v), X(v), size.height - 8.dp.toPx(), labelStyle, 1) }
        fun band(a: DoubleArray, b: DoubleArray, c: Color) {
            val p = Path()
            xs.indices.forEach { i -> if (i == 0) p.moveTo(X(xs[i]), Y(b[i])) else p.lineTo(X(xs[i]), Y(b[i])) }
            for (i in xs.indices.reversed()) p.lineTo(X(xs[i]), Y(a[i]))
            p.close(); drawPath(p, c)
        }
        clipRect(right = g.pl + (size.width - g.pl) * prog) {
            band(q[0], q[4], PC.Ac2.copy(alpha = .13f))
            band(q[1], q[3], PC.Ac2.copy(alpha = .25f))
            val med = Path()
            xs.indices.forEach { i -> if (i == 0) med.moveTo(X(xs[i]), Y(q[2][i])) else med.lineTo(X(xs[i]), Y(q[2][i])) }
            drawPath(med, PC.Tx, style = Stroke(2.dp.toPx(), join = StrokeJoin.Round))
        }
    }
}

class CalPt(val x: Double, val y: Double, val lo: Double, val hi: Double, val n: Int)

/** Diagrama de fiabilidad: equity predicha frente a frecuencia observada con IC de Wilson. */
@Composable
fun CalibrationPlot(p: List<CalPt>) {
    if (p.isEmpty()) { Muted("Se necesitan más all-ins con EV."); return }
    val tm = rememberTextMeasurer()
    val prog = rememberProg(p, 900)
    Canvas(Modifier.fillMaxWidth().height(240.dp)) {
        val g = geo()
        val Y = drawGrid(tm, 0.0, 1.0, listOf(0.0, .25, .5, .75, 1.0), g)
        val X = { v: Double -> (g.pl + v * (size.width - g.pl - g.pr)).toFloat() }
        listOf(0.0, .25, .5, .75, 1.0).forEach { txt(tm, (it * 100).toInt().toString() + "%", X(it), size.height - 8.dp.toPx(), labelStyle, 1) }
        drawLine(PC.Mu, Offset(X(0.0), Y(0.0)), Offset(X(1.0), Y(1.0)), 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f)))
        for (c in p) {
            val col = if (c.x in c.lo..c.hi) PC.Gd else PC.Wn
            drawLine(col.copy(alpha = .8f), Offset(X(c.x), Y(c.lo)), Offset(X(c.x), Y(c.hi)), 2.dp.toPx())
            drawCircle(col, (3.5f + min(5.0, sqrt(c.n.toDouble()) / 3)).toFloat().dp.toPx() * prog, Offset(X(c.x), Y(c.y)))
        }
        txt(tm, "equity predicha →", size.width - g.pr, size.height - 24.dp.toPx(), labelStyle, 2)
    }
}

/** Autocorrelación con bandas de ±1.96/√n. */
@Composable
fun AcfChart(v: DoubleArray, band: Double) {
    if (v.isEmpty()) { Muted("Se necesitan más torneos."); return }
    val tm = rememberTextMeasurer()
    val prog = rememberProg(v, 800)
    Canvas(Modifier.fillMaxWidth().height(180.dp)) {
        val g = geo()
        val (lo, hi, t) = nice(min(-band * 1.4, v.min()), max(band * 1.4, v.max()))
        val Y = drawGrid(tm, lo, hi, t, g)
        val w = (size.width - g.pl - g.pr) / v.size
        val y0 = Y(0.0)
        for (i in v.indices) {
            val bx = g.pl + i * w + w * .25f; val bw = w * .5f
            val yy = Y(v[i]); val h = (y0 - yy) * prog
            val out = abs(v[i]) > band
            drawRoundRect(if (out) PC.Wn else PC.Ac2, Offset(bx, if (h >= 0) y0 - h else y0), Size(bw, max(abs(h), 1f)), CornerRadius(3.dp.toPx()))
            txt(tm, (i + 1).toString(), bx + bw / 2, size.height - 8.dp.toPx(), labelStyle, 1)
        }
        val dash = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
        drawLine(PC.Gd, Offset(g.pl, Y(band)), Offset(size.width - g.pr, Y(band)), 1.dp.toPx(), pathEffect = dash)
        drawLine(PC.Gd, Offset(g.pl, Y(-band)), Offset(size.width - g.pr, Y(-band)), 1.dp.toPx(), pathEffect = dash)
    }
}

class ForestRow(val label: String, val est: Double, val lo: Double?, val hi: Double?, val bLo: Double?, val bHi: Double?)

/** Diagrama de bosque: estimación con intervalo y banda de referencia por fila. */
@Composable
fun ForestPlot(rows: List<ForestRow>, axisLo: Double, axisHi: Double, fmt: (Double) -> String = { f1(it) }) {
    if (rows.isEmpty()) { Muted("Sin datos."); return }
    val tm = rememberTextMeasurer()
    val prog = rememberProg(rows.size, 800)
    val rowH = 26
    Canvas(Modifier.fillMaxWidth().height((rowH * rows.size + 26).dp)) {
        val lw = 118.dp.toPx(); val pr = 10.dp.toPx(); val rh = rowH.dp.toPx()
        val X = { v: Double -> (lw + (v.coerceIn(axisLo, axisHi) - axisLo) / (axisHi - axisLo) * (size.width - lw - pr)).toFloat() }
        val (_, _, t) = nice(axisLo, axisHi)
        for (tk in t) {
            if (tk < axisLo || tk > axisHi) continue
            drawLine(PC.Ln, Offset(X(tk), 0f), Offset(X(tk), rh * rows.size), 1f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 6f)))
            txt(tm, fmt(tk), X(tk), rh * rows.size + 12.dp.toPx(), labelStyle, 1)
        }
        rows.forEachIndexed { i, r ->
            val cy = rh * i + rh / 2
            if (i % 2 == 0) drawRect(Color.White.copy(alpha = .025f), Offset(0f, rh * i), Size(size.width, rh))
            if (r.bLo != null && r.bHi != null) drawRoundRect(PC.Gd.copy(alpha = .15f), Offset(X(r.bLo), cy - rh / 2 + 3.dp.toPx()), Size(X(r.bHi) - X(r.bLo), rh - 6.dp.toPx()), CornerRadius(3.dp.toPx()))
            txt(tm, r.label, 0f, cy, labelStyle, 0)
            val inBand = r.bLo != null && r.bHi != null && r.est >= r.bLo && r.est <= r.bHi
            val c = if (inBand) PC.Gd else PC.Wn
            if (r.lo != null && r.hi != null) {
                val xl = X(r.lo); val xh = X(r.hi)
                val xm = X(r.est)
                drawLine(c, Offset(xm - (xm - xl) * prog, cy), Offset(xm + (xh - xm) * prog, cy), 2.dp.toPx())
                drawLine(c, Offset(xl, cy - 4.dp.toPx()), Offset(xl, cy + 4.dp.toPx()), 1.5.dp.toPx())
                drawLine(c, Offset(xh, cy - 4.dp.toPx()), Offset(xh, cy + 4.dp.toPx()), 1.5.dp.toPx())
            }
            drawCircle(c, 4.5.dp.toPx(), Offset(X(r.est), cy))
        }
    }
}

fun ceilDiv(a: Int, b: Int) = ceil(a.toDouble() / b).toInt()
