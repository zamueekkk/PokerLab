package com.pokerlab

/** Resultados derivados de un conjunto de manos, calculados una sola vez y compartidos entre pestañas. */
class Derived(val hs: List<Hand>, val ver: Int) {
    val s: Agg by lazy { S(hs) }
    val ctx: Ctx by lazy { ctx(hs, s) }
    val level: Lvl by lazy { level(hs, s, ctx) }
    val tours: List<Tour> by lazy { tours(hs) }
    val ev: EvSum by lazy { evSum(hs) }
    val lab: LabData by lazy { computeLab(hs) }
}

private val dcache = ArrayList<Derived>()

fun derived(hs: List<Hand>, ver: Int): Derived = synchronized(dcache) {
    dcache.firstOrNull { it.hs === hs && it.ver == ver } ?: Derived(hs, ver).also {
        dcache.add(0, it)
        while (dcache.size > 8) dcache.removeAt(dcache.size - 1)
    }
}
