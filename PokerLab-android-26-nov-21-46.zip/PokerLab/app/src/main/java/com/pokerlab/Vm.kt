package com.pokerlab

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max
import kotlin.math.min

const val DAY = 86_400_000L
const val INF = Long.MAX_VALUE

class Rng(val m: String = "all", val f: String = "", val t: String = "")
class SegState(val g: String = "auto", val s: String = "bb")
class HFilter(val q: String = "", val pos: String = "all", val r: String = "all")
class Review(val cards: List<String>, val action: String, val type: String?)

val TABS = linkedMapOf(
    "res" to "Resumen", "seg" to "Seguimiento", "niv" to "Nivel", "per" to "Perfil", "lab" to "Laboratorio", "pre" to "Preflop",
    "post" to "Postflop", "ev" to "All-ins & EV", "solver" to "Solver CFR", "fug" to "Fugas", "rev" to "Revisión",
    "tor" to "Torneos", "ran" to "Preflop · historial", "pos" to "Posiciones", "pat" to "Patrones",
    "man" to "Manos clave", "hnd" to "Explorador", "riv" to "Rivales", "gra" to "Gráficas", "av" to "Avanzado", "cla" to "Claro"
)
val GROUPS = mapOf("res" to "General", "pre" to "Juego", "ev" to "Diagnóstico", "tor" to "Datos")

private val ZONE: ZoneId get() = ZoneId.systemDefault()
fun msOf(d: LocalDate): Long = d.atStartOfDay(ZONE).toInstant().toEpochMilli()

fun pdef(m: String, H: List<Hand>): LongArray {
    val n = H.size
    val e = if (n > 0) H[n - 1].ts else System.currentTimeMillis()
    val d = Instant.ofEpochMilli(e).atZone(ZONE).toLocalDate()
    val mid = if (n > 0) H[n shr 1].ts else e
    val m1 = d.withDayOfMonth(1)
    return when (m) {
        "7" -> longArrayOf(e - 7 * DAY, e)
        "30" -> longArrayOf(e - 30 * DAY, e)
        "90" -> longArrayOf(e - 90 * DAY, e)
        "mes" -> longArrayOf(msOf(m1), e)
        "pmes" -> longArrayOf(msOf(m1.minusMonths(1)), msOf(m1) - 1)
        "p7" -> longArrayOf(e - 14 * DAY, e - 7 * DAY - 1)
        "p30" -> longArrayOf(e - 60 * DAY, e - 30 * DAY - 1)
        "p90" -> longArrayOf(e - 180 * DAY, e - 90 * DAY - 1)
        "h1" -> longArrayOf(0, mid)
        "h2" -> longArrayOf(mid + 1, e)
        else -> longArrayOf(0, INF)
    }
}

fun prng(o: Rng, H: List<Hand>): LongArray = when (o.m) {
    "all" -> longArrayOf(0, INF)
    "c" -> longArrayOf(
        if (o.f.isNotEmpty()) msOf(LocalDate.parse(o.f)) else 0,
        if (o.t.isNotEmpty()) msOf(LocalDate.parse(o.t).plusDays(1)) - 1 else INF
    )
    else -> pdef(o.m, H)
}

fun bdOf(raw: String): List<String> {
    val b = ArrayList<String>()
    val re = Regex("""^\*\*\* (FLOP|TURN|RIVER) \*\*\*.*?\[([^\]]*)\]\s*$""")
    for (l in raw.split("\n")) {
        val x = re.find(l) ?: continue
        if (x.groupValues[1] == "FLOP") b.clear()
        b.addAll(x.groupValues[2].trim().split(Regex("\\s+")))
    }
    return b
}

fun csvOf(L: List<Hand>): String {
    fun q(v: Any?) = "\"" + (v?.toString() ?: "").replace("\"", "\"\"") + "\""
    val sb = StringBuilder("\uFEFFid,fecha,torneo,torneo_id,ciegas,pos,cartas,tablero,stack_bb,neto_bb,allin\n")
    for (h in L) {
        sb.append(
            listOf(
                h.id, Instant.ofEpochMilli(h.ts).toString(), h.tn, h.tid, h.bb, h.pos, (h.cards ?: emptyList()).joinToString(" "),
                bdOf(h.raw).joinToString(" "), String.format("%.1f", h.stack / h.bb), String.format("%.2f", h.nb), h.anyAI
            ).joinToString(",") { q(it) }
        ).append("\n")
    }
    return sb.toString()
}

class MainVm(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("pl", 0)
    private val dir = File(app.filesDir, "hands").also { it.mkdirs() }

    var H by mutableStateOf<List<Hand>>(emptyList())
    var loading by mutableStateOf(true)
    var importing by mutableStateOf(false)
    var uname by mutableStateOf(prefs.getString("name", "") ?: "")
    var askName by mutableStateOf(!prefs.getBoolean("nameDone", false))

    var tab by mutableStateOf((prefs.getString("tab", "res") ?: "res").let { if (TABS.containsKey(it)) it else "res" })
    var tt by mutableStateOf("res")
    var sel by mutableStateOf(prefs.getString("sel", "all") ?: "all")
    var dr by mutableStateOf(Rng(prefs.getString("dr_m", "all") ?: "all", prefs.getString("dr_f", "") ?: "", prefs.getString("dr_t", "") ?: ""))
    var gp by mutableStateOf(prefs.getString("gp", "all") ?: "all")
    var gm by mutableStateOf(prefs.getString("gm", "v") ?: "v")
    var tour by mutableStateOf<String?>(null)
    var replayId by mutableStateOf<String?>(null)
    var cpa by mutableStateOf(Rng("h2"))
    var cpb by mutableStateOf(Rng("h1"))
    var seg by mutableStateOf(SegState(prefs.getString("sg", "auto") ?: "auto", prefs.getString("ss", "bb") ?: "bb"))
    var hf by mutableStateOf(HFilter())

    var evVer by mutableIntStateOf(0)
    var evTotal by mutableIntStateOf(0)
    var evDone by mutableIntStateOf(0)
    var evBusy by mutableStateOf(false)

    // solver
    var sBoard by mutableStateOf("Qs,Jh,2h")
    var sPot by mutableStateOf("20")
    var sStack by mutableStateOf("100")
    var sIp by mutableStateOf("AA,KK,QQ,JJ,TT,99,AKs,AQs,AJs,KQs,QJs,JTs,T9s,98s,87s,76s,65s")
    var sOop by mutableStateOf("QQ,JJ,TT,99,88,77,66,55,AKo,AQs,AJs,ATs,KQs,KJs,QJs,JTs,T9s,98s,87s,76s,65s")
    var sIters by mutableStateOf("300")
    var sBusy by mutableStateOf(false)
    var sProg by mutableIntStateOf(0)
    var sError by mutableStateOf("")
    var sNotice by mutableStateOf("")
    var sResult by mutableStateOf<SolveResult?>(null)
    var sReview by mutableStateOf<Review?>(null)
    @Volatile private var cancelFlag = false

    private val cacheF = File(app.filesDir, "hands.bin")
    private val evF = File(app.filesDir, "ev.bin")
    private val evLock = Any()

    init {
        loadStored()
        viewModelScope.launch {
            snapshotFlow { listOf(tab, sel, dr.m, dr.f, dr.t, gp, gm, seg.g, seg.s) }.collect { v ->
                prefs.edit().putString("tab", v[0]).putString("sel", v[1]).putString("dr_m", v[2]).putString("dr_f", v[3]).putString("dr_t", v[4])
                    .putString("gp", v[5]).putString("gm", v[6]).putString("sg", v[7]).putString("ss", v[8]).apply()
            }
        }
    }

    fun setName(n: String) {
        uname = n.trim().take(24)
        askName = false
        prefs.edit().putString("name", uname).putBoolean("nameDone", true).apply()
    }

    fun skipName() { askName = false; prefs.edit().putBoolean("nameDone", true).apply() }

    private fun srcSig(): Long {
        val fs = dir.listFiles()?.sortedBy { it.name } ?: emptyList()
        return fs.joinToString("|") { it.name + ":" + it.length() }.hashCode().toLong()
    }

    /** Arranque rápido: caché binaria del perfil; si no existe o está obsoleta, se reanaliza una sola vez. */
    private fun loadStored() {
        viewModelScope.launch(Dispatchers.Default) {
            val loaded: List<Hand> = Store.loadHands(cacheF, srcSig()) ?: run {
                val l = ArrayList<Hand>(); val seen = HashSet<String>()
                dir.listFiles()?.sortedBy { it.name }?.forEach { f ->
                    for (h in parseHands(f.readText())) if (seen.add(h.id)) l.add(h)
                }
                l.sortWith(CMP)
                if (l.isNotEmpty()) Store.saveHands(cacheF, l, srcSig())
                l
            }
            Store.loadEv(evF, loaded)
            withContext(Dispatchers.Main) {
                H = loaded
                if (sel != "all" && sel != "fr" && sel != "pd" && loaded.none { it.tid == sel }) sel = "all"
                loading = false
                evRun()
            }
        }
    }

    fun importUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        importing = true
        viewModelScope.launch(Dispatchers.Default) {
            val cr = getApplication<Application>().contentResolver
            val all = ArrayList<Hand>(H); val seen = HashSet<String>(); all.forEach { seen.add(it.id) }
            var added = 0
            for ((i, u) in uris.withIndex()) {
                val txt = try { cr.openInputStream(u)?.bufferedReader()?.use { it.readText() } } catch (e: Exception) { null } ?: continue
                val parsed = parseHands(txt)
                if (parsed.isEmpty()) continue
                File(dir, "imp_${System.currentTimeMillis()}_$i.txt").writeText(txt)
                for (h in parsed) if (seen.add(h.id)) { all.add(h); added++ }
            }
            all.sortWith(CMP)
            if (added > 0) Store.saveHands(cacheF, all, srcSig())
            withContext(Dispatchers.Main) { H = all; importing = false; loading = false; evRun() }
        }
    }

    fun clearAll() {
        dir.listFiles()?.forEach { it.delete() }
        cacheF.delete(); evF.delete()
        H = emptyList(); tour = null; sel = "all"; dr = Rng()
    }

    /** Calcula en paralelo solo los EV que faltan y los guarda para el próximo arranque. */
    fun evRun() {
        if (evBusy) return
        val hs = H
        val todo = hs.filter { it.evd != null && !it.eqDone }
        evTotal = todo.size; evDone = 0
        if (todo.isEmpty()) return
        evBusy = true
        viewModelScope.launch(Dispatchers.Default) {
            val workers = max(1, min(4, Runtime.getRuntime().availableProcessors() - 1))
            val counter = AtomicInteger(0)
            coroutineScope {
                (0 until workers).map { w ->
                    async {
                        var i = w
                        while (i < todo.size) {
                            evh(todo[i])
                            val d = counter.incrementAndGet()
                            evDone = d
                            if (w == 0 && d % 300 == 0) synchronized(evLock) { Store.saveEv(evF, hs) }
                            i += workers
                        }
                    }
                }.awaitAll()
            }
            synchronized(evLock) { Store.saveEv(evF, hs) }
            withContext(Dispatchers.Main) { evVer++; evBusy = false }
        }
    }

    private fun ftHands(): List<Hand> = H.filter {
        sel == "all" || (sel == "fr" && isFreeroll(it)) || (sel == "pd" && !isFreeroll(it)) || sel == it.tid
    }

    fun filtered(): List<Hand> {
        val r = if (tab == "seg") longArrayOf(0, INF) else prng(dr, H)
        return ftHands().filter { it.ts >= r[0] && it.ts <= r[1] }
    }

    fun openReplay(id: String) { replayId = id }

    fun sendToSolver(h: Hand, d: RpData, i: Int) {
        val s = d.steps[i]
        val live = s.P.values.filter { !it.f }
        sBoard = s.bd.joinToString(",")
        sPot = trimNum(s.pot / h.bb)
        sStack = trimNum(live.minOf { it.st } / h.bb)
        val next = d.steps.getOrNull(i + 1)
        val cards = h.cards
        sReview = if (next != null && next.a == "Hero" && cards != null && cards.size == 2) {
            val t = next.t
            val type = when {
                Regex("pasa \\(check\\)", RegexOption.IGNORE_CASE).containsMatchIn(t) -> "CHECK"
                Regex("iguala", RegexOption.IGNORE_CASE).containsMatchIn(t) -> "CALL"
                Regex("se retira", RegexOption.IGNORE_CASE).containsMatchIn(t) -> "FOLD"
                Regex("apuesta|sube a|ALL-IN", RegexOption.IGNORE_CASE).containsMatchIn(t) -> "AGGRESSIVE"
                else -> null
            }
            Review(cards.toList(), t, type)
        } else null
        sResult = null; sError = ""
        sNotice = "Spot precargado desde la mano #${h.id}. La estrategia inicial corresponde al jugador OOP; " +
            (if (sReview != null) "se comparará la frecuencia de la acción de Hero para sus cartas conocidas." else "no se compara una acción de Hero en este punto.") +
            " Comprueba y ajusta los rangos IP/OOP: no se deducen del historial."
        replayId = null; tour = null; tab = "solver"
    }

    private fun trimNum(x: Double): String {
        val s = String.format(java.util.Locale.US, "%.2f", x)
        return s.trimEnd('0').trimEnd('.')
    }

    fun solve() {
        if (sBusy) return
        sError = ""; sNotice = ""; sResult = null; sBusy = true; sProg = 0; cancelFlag = false
        val board = sBoard; val pot = sPot.toDoubleOrNull() ?: 0.0; val stack = sStack.toDoubleOrNull() ?: 0.0
        val ip = sIp; val oop = sOop; val it = sIters.toIntOrNull() ?: 300; val hero = sReview?.cards
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val r = solveSpot(board, pot, stack, ip, oop, it, hero, { p -> sProg = p }, { cancelFlag })
                withContext(Dispatchers.Main) { sResult = r }
            } catch (e: SolverCancelled) {
                withContext(Dispatchers.Main) { sError = "Cálculo cancelado." }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { sError = e.message ?: "Error en el solver." }
            } finally {
                withContext(Dispatchers.Main) { sBusy = false }
            }
        }
    }

    fun cancelSolve() { cancelFlag = true }
}
