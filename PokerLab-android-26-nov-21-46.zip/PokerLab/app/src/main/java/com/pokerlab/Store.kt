package com.pokerlab

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/**
 * Caché binaria del perfil: evita volver a leer y analizar los .txt en cada arranque.
 * - hands.bin  : manos ya analizadas (con GZIP). Se invalida si cambian los archivos fuente o la versión.
 * - ev.bin     : resultados de equity/EV ya calculados, por id de mano.
 */
object Store {
    private const val MAGIC = 0x504C4232
    private const val VER = 3

    private fun DataOutputStream.str(s: String) { val b = s.toByteArray(Charsets.UTF_8); writeInt(b.size); write(b) }
    private fun DataInputStream.str(): String { val n = readInt(); val b = ByteArray(n); readFully(b); return String(b, Charsets.UTF_8) }
    private fun DataOutputStream.nstr(s: String?) { writeBoolean(s != null); if (s != null) str(s) }
    private fun DataInputStream.nstr(): String? = if (readBoolean()) str() else null
    private fun DataOutputStream.nbool(b: Boolean?) { writeByte(if (b == null) 2 else if (b) 1 else 0) }
    private fun DataInputStream.nbool(): Boolean? { val v = readByte().toInt(); return if (v == 2) null else v == 1 }
    private fun DataOutputStream.strs(l: List<String>) { writeInt(l.size); for (x in l) str(x) }
    private fun DataInputStream.strs(): List<String> { val n = readInt(); val o = ArrayList<String>(n); repeat(n) { o.add(str()) }; return o }

    fun saveHands(f: File, hands: List<Hand>, sig: Long) {
        val tmp = File(f.parentFile, f.name + ".tmp")
        DataOutputStream(BufferedOutputStream(GZIPOutputStream(FileOutputStream(tmp), 1 shl 16), 1 shl 16)).use { o ->
            o.writeInt(MAGIC); o.writeInt(VER); o.writeLong(sig); o.writeInt(hands.size)
            for (h in hands) {
                o.str(h.id); o.writeDouble(h.bb); o.writeDouble(h.sb); o.writeDouble(h.an); o.writeLong(h.ts)
                o.str(h.tn); o.str(h.tid); o.str(h.raw); o.str(h.pos); o.writeInt(h.n); o.writeDouble(h.stack)
                val cs = h.cards
                o.writeBoolean(cs != null); if (cs != null) o.strs(cs)
                o.writeInt(h.c.size); for ((k, v) in h.c) { o.str(k); o.writeDouble(v) }
                o.writeInt(h.vpip); o.writeInt(h.pfr); o.writeInt(h.saw); o.writeInt(h.sd); o.writeInt(h.wsd)
                o.writeDouble(h.col); o.writeDouble(h.inv); o.writeDouble(h.net); o.writeDouble(h.nb); o.writeDouble(h.M)
                o.writeInt(h.rfiO); o.writeInt(h.rfi); o.writeInt(h.cvs); o.writeInt(h.pt); o.writeInt(h.agg)
                o.nbool(h.ip); o.writeInt(h.nOpp); o.writeBoolean(h.cbHit)
                val sp = h.spr; o.writeBoolean(sp != null); if (sp != null) o.writeDouble(sp)
                o.str(h.fs); o.writeDouble(h.potTotal); o.writeInt(h.pl); o.writeChar(h.pa.code); o.writeInt(h.pr); o.nstr(h.hc)
                o.writeInt(h.anyAI); o.writeInt(h.ai); o.str(h.aiSt); o.writeChar(h.aiK.code); o.writeInt(h.aiCalled)
                o.writeInt(h.hour); o.writeInt(h.dow); o.writeLong(h.day)
                val d = h.evd
                o.writeBoolean(d != null)
                if (d != null) {
                    o.strs(d.act)
                    o.writeInt(d.cards.size); for ((k, v) in d.cards) { o.str(k); o.strs(v) }
                    o.writeInt(d.inv.size); for ((k, v) in d.inv) { o.str(k); o.writeDouble(v) }
                    o.strs(d.board); o.str(d.st)
                }
            }
        }
        if (f.exists()) f.delete()
        tmp.renameTo(f)
    }

    fun loadHands(f: File, sig: Long): List<Hand>? {
        if (!f.exists()) return null
        return try {
            DataInputStream(BufferedInputStream(GZIPInputStream(FileInputStream(f), 1 shl 16), 1 shl 16)).use { i ->
                if (i.readInt() != MAGIC || i.readInt() != VER || i.readLong() != sig) return null
                val n = i.readInt()
                val out = ArrayList<Hand>(n)
                repeat(n) {
                    val id = i.str(); val bb = i.readDouble(); val sb = i.readDouble(); val an = i.readDouble(); val ts = i.readLong()
                    val tn = i.str(); val tid = i.str(); val raw = i.str(); val pos = i.str(); val pn = i.readInt(); val stack = i.readDouble()
                    val h = Hand(id, bb, sb, an, ts, tn, tid, raw, pos, pn, stack)
                    if (i.readBoolean()) h.cards = i.strs()
                    repeat(i.readInt()) { val k = i.str(); h.c[k] = i.readDouble() }
                    h.vpip = i.readInt(); h.pfr = i.readInt(); h.saw = i.readInt(); h.sd = i.readInt(); h.wsd = i.readInt()
                    h.col = i.readDouble(); h.inv = i.readDouble(); h.net = i.readDouble(); h.nb = i.readDouble(); h.M = i.readDouble()
                    h.rfiO = i.readInt(); h.rfi = i.readInt(); h.cvs = i.readInt(); h.pt = i.readInt(); h.agg = i.readInt()
                    h.ip = i.nbool(); h.nOpp = i.readInt(); h.cbHit = i.readBoolean()
                    h.spr = if (i.readBoolean()) i.readDouble() else null
                    h.fs = i.str(); h.potTotal = i.readDouble(); h.pl = i.readInt(); h.pa = i.readChar(); h.pr = i.readInt(); h.hc = i.nstr()
                    h.anyAI = i.readInt(); h.ai = i.readInt(); h.aiSt = i.str(); h.aiK = i.readChar(); h.aiCalled = i.readInt()
                    h.hour = i.readInt(); h.dow = i.readInt(); h.day = i.readLong()
                    if (i.readBoolean()) {
                        val act = i.strs()
                        val cards = LinkedHashMap<String, List<String>>()
                        repeat(i.readInt()) { val k = i.str(); cards[k] = i.strs() }
                        val inv = LinkedHashMap<String, Double>()
                        repeat(i.readInt()) { val k = i.str(); inv[k] = i.readDouble() }
                        val board = i.strs(); val st = i.str()
                        h.evd = EvData(act, cards, inv, board, st)
                    }
                    out.add(h)
                }
                out
            }
        } catch (e: Exception) {
            null
        }
    }

    fun saveEv(f: File, hands: List<Hand>) {
        try {
            val tmp = File(f.parentFile, f.name + ".tmp")
            val done = hands.filter { it.evd != null && it.eqDone }
            DataOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { o ->
                o.writeInt(MAGIC); o.writeInt(VER); o.writeInt(done.size)
                for (h in done) {
                    o.str(h.id)
                    val e = h.eq
                    o.writeBoolean(e != null)
                    if (e != null) {
                        o.writeDouble(e.e); o.writeDouble(e.ev); o.writeDouble(e.lk)
                        o.writeInt(e.pl.size); for (p in e.pl) o.strs(p)
                        o.strs(e.b); o.str(e.st); o.writeInt(e.n); o.writeBoolean(e.exact)
                    }
                }
            }
            if (f.exists()) f.delete()
            tmp.renameTo(f)
        } catch (e: Exception) {
            // la caché de EV es opcional
        }
    }

    fun loadEv(f: File, hands: List<Hand>) {
        if (!f.exists()) return
        try {
            val byId = HashMap<String, Hand>(hands.size * 2)
            for (h in hands) byId[h.id] = h
            DataInputStream(BufferedInputStream(FileInputStream(f))).use { i ->
                if (i.readInt() != MAGIC || i.readInt() != VER) return
                repeat(i.readInt()) {
                    val id = i.str()
                    var eq: EqRes? = null
                    if (i.readBoolean()) {
                        val e = i.readDouble(); val ev = i.readDouble(); val lk = i.readDouble()
                        val pl = ArrayList<List<String>>(); repeat(i.readInt()) { pl.add(i.strs()) }
                        val b = i.strs(); val st = i.str(); val n = i.readInt(); val ex = i.readBoolean()
                        eq = EqRes(e, ev, lk, pl, b, st, n, ex)
                    }
                    val h = byId[id]
                    if (h != null && h.evd != null) { h.eq = eq; h.eqDone = true }
                }
            }
        } catch (e: Exception) {
            // se recalculará
        }
    }
}
