package com.pokerlab

import kotlin.math.max
import kotlin.math.min

fun CI(x: String): Int = "23456789TJQKA".indexOf(x[0]) * 4 + "cdhs".indexOf(x[1])

private fun straightTop(m: Int): Int {
    val q = (m shl 1) or ((m shr 12) and 1)
    for (h in 13 downTo 4) if (((q shr (h - 4)) and 31) == 31) return h - 1
    return -1
}

/** Empaqueta en base 13 las k cartas más altas presentes (excluyendo e1 y e2). */
private fun kick(rc: IntArray, e1: Int, e2: Int, k: Int): Int {
    var acc = 0; var n = 0; var r = 12
    while (r >= 0 && n < k) {
        if (rc[r] > 0 && r != e1 && r != e2) { acc = acc * 13 + r; n++ }
        r--
    }
    return acc
}

/** Evalúa 7 cartas (índices 0..51 = rango*4+palo). Mayor = mejor. Sin listas ni ordenaciones. */
fun ev7(c: IntArray): Int {
    val rc = IntArray(13); val sc = IntArray(4); val sr = IntArray(4)
    for (x in c) {
        val r = x shr 2; val s = x and 3
        rc[r]++; sc[s]++; sr[s] = sr[s] or (1 shl r)
    }
    var f = -1
    for (i in 0 until 4) if (sc[i] >= 5) { f = i; break }
    if (f >= 0) {
        val st = straightTop(sr[f])
        if (st >= 0) return 80_000_000 + st
    }
    var quad = -1; var t1 = -1; var t2 = -1; var p1 = -1; var p2 = -1
    for (r in 12 downTo 0) {
        when (rc[r]) {
            4 -> if (quad < 0) quad = r
            3 -> if (t1 < 0) t1 = r else if (t2 < 0) t2 = r
            2 -> if (p1 < 0) p1 = r else if (p2 < 0) p2 = r
        }
    }
    if (quad >= 0) return 70_000_000 + quad * 13 + kick(rc, quad, -1, 1)
    if (t1 >= 0 && (t2 >= 0 || p1 >= 0)) return 60_000_000 + t1 * 13 + max(t2, p1)
    if (f >= 0) {
        var acc = 0; var n = 0; var r = 12
        while (r >= 0 && n < 5) { if (((sr[f] shr r) and 1) == 1) { acc = acc * 13 + r; n++ }; r-- }
        return 50_000_000 + acc
    }
    var m = 0
    for (r in 0 until 13) if (rc[r] > 0) m = m or (1 shl r)
    val st = straightTop(m)
    if (st >= 0) return 40_000_000 + st
    if (t1 >= 0) return 30_000_000 + t1 * 169 + kick(rc, t1, -1, 2)
    if (p1 >= 0 && p2 >= 0) return 20_000_000 + (p1 * 13 + p2) * 13 + kick(rc, p1, p2, 1)
    if (p1 >= 0) return 10_000_000 + p1 * 2197 + kick(rc, p1, -1, 3)
    return kick(rc, -1, -1, 5)
}

class EqCalc(val share: Double, val eq: Double, val exact: Boolean)

fun evMulti(
    act: List<String>, cards: Map<String, List<String>>, inv: Map<String, Double>,
    bd: IntArray, N: Int, seed: Int
): EqCalc? {
    var sd = seed
    fun rnd(): Double {
        sd += 0x6D2B79F5
        var t = (sd xor (sd ushr 15)) * (1 or sd)
        t = (t + (t xor (t ushr 7)) * (61 or t)) xor t
        return ((t xor (t ushr 14)).toLong() and 0xFFFFFFFFL).toDouble() / 4294967296.0
    }
    val m = act.size
    val hi = act.indexOf("Hero")
    if (hi < 0) return null
    val hole = ArrayList<IntArray>()
    for (p in act) {
        val cs = cards[p] ?: return null
        hole.add(cs.map { CI(it) }.toIntArray())
    }
    val used = HashSet<Int>()
    for (x in bd) used.add(x)
    for (h in hole) for (x in h) used.add(x)
    if (used.size != bd.size + m * 2) return null
    val dk = (0 until 52).filter { !used.contains(it) }.toIntArray()

    // capas de bote (side pots)
    val all = inv.keys.toList()
    val lv = act.map { inv[it] ?: 0.0 }.filter { it > 0 }.distinct().sorted()
    val layAmt = ArrayList<Double>(); val layEl = ArrayList<IntArray>()
    var prev = 0.0
    for (L in lv) {
        var amt = 0.0
        for (p in all) { val ip = inv[p] ?: 0.0; amt += max(0.0, min(ip, L) - min(ip, prev)) }
        layAmt.add(amt)
        layEl.add(act.indices.filter { (inv[act[it]] ?: 0.0) >= L }.toIntArray())
        prev = L
    }
    var ex = 0.0
    for (p in all) if (!act.contains(p)) ex += max(0.0, (inv[p] ?: 0.0) - prev)
    if (layAmt.isEmpty()) return null
    layAmt[layAmt.size - 1] = layAmt[layAmt.size - 1] + ex

    val need = 5 - bd.size
    val bufs = Array(m) { IntArray(7) }
    for (p in 0 until m) {
        bufs[p][0] = hole[p][0]; bufs[p][1] = hole[p][1]
        for (i in bd.indices) bufs[p][2 + i] = bd[i]
    }
    val base = 2 + bd.size
    val vals = IntArray(m)
    var share = 0.0
    var cnt = 0
    fun run() {
        for (p in 0 until m) vals[p] = ev7(bufs[p])
        for (li in layAmt.indices) {
            var best = -1; var wc = 0; var heroIn = false
            for (p in layEl[li]) {
                val v = vals[p]
                if (v > best) { best = v; wc = 1; heroIn = (p == hi) }
                else if (v == best) { wc++; if (p == hi) heroIn = true }
            }
            if (heroIn) share += layAmt[li] / wc
        }
        cnt++
    }
    fun setSlot(k: Int, card: Int) { for (p in 0 until m) bufs[p][base + k] = card }
    when (need) {
        0 -> run()
        1 -> for (a in dk) { setSlot(0, a); run() }
        2 -> for (i in dk.indices) for (j in i + 1 until dk.size) { setSlot(0, dk[i]); setSlot(1, dk[j]); run() }
        else -> for (t in 0 until N) {
            for (i in 0 until need) {
                val j = i + Math.floor(rnd() * (dk.size - i)).toInt()
                val tmp = dk[i]; dk[i] = dk[j]; dk[j] = tmp
                setSlot(i, dk[i])
            }
            run()
        }
    }
    val T = layAmt.sum()
    return EqCalc(share / cnt, share / cnt / T, need <= 2)
}

fun evh(h: Hand): EqRes? {
    if (h.eqDone) return h.eq
    var res: EqRes? = null
    val d = h.evd
    if (d != null && d.act.all { d.cards[it] != null }) {
        val nb = when (d.st) { "pre" -> 0; "flop" -> 3; "turn" -> 4; else -> 5 }
        val bd = d.board.take(nb)
        if (bd.size >= nb) {
            val seed = (h.id.toLongOrNull() ?: 1L) % 4294967291L
            val r = evMulti(d.act, d.cards, d.inv, bd.map { CI(it) }.toIntArray(), if (d.act.size == 2) 12000 else 8000, seed.toInt())
            if (r != null) {
                val ev = (r.share - (d.inv["Hero"] ?: 0.0)) / h.bb
                res = EqRes(r.eq, ev, h.nb - ev, d.act.filter { it != "Hero" }.map { d.cards[it]!! }, bd, d.st, d.act.size, r.exact)
            }
        }
    }
    h.eq = res
    h.eqDone = true
    return res
}

class EvSum(val n: Int, val real: Double, val ev: Double, val pend: Int, val unk: Int, val w: Int, val x: Double) {
    val luck: Double get() = real - ev
}

fun evSum(hs: List<Hand>): EvSum {
    var n = 0; var real = 0.0; var ev = 0.0; var pend = 0; var unk = 0; var w = 0; var x = 0.0
    for (h in hs) {
        if (h.evd == null) continue
        if (!h.eqDone) { pend++; continue }
        val e = h.eq
        if (e == null) { unk++; continue }
        n++; real += h.nb; ev += e.ev
        if (h.nb > 0) w++
        x += e.e
    }
    return EvSum(n, real, ev, pend, unk, w, x)
}
