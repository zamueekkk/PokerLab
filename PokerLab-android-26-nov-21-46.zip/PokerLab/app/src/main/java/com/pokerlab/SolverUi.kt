package com.pokerlab

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.log10
import kotlin.math.max

val C_FOLD = Color(0xFF4C8DFF)
val C_ALLIN = Color(0xFFB3123A)

fun actColor(a: String, stack: Double): Color {
    val u = a.uppercase()
    return when {
        u.startsWith("FOLD") -> C_FOLD
        u.startsWith("CHECK") || u.startsWith("CALL") -> PC.Gd
        else -> {
            val amt = a.substringAfter(' ').toDoubleOrNull() ?: 0.0
            if (amt >= stack * 0.999) C_ALLIN else PC.Wn
        }
    }
}

fun prettyAct(a: String, stack: Double): String {
    val u = a.uppercase()
    val amt = a.substringAfter(' ', "").toDoubleOrNull()
    return when {
        u.startsWith("FOLD") -> "Fold"
        u.startsWith("CHECK") -> "Check"
        u.startsWith("CALL") -> "Call"
        amt != null && amt >= stack * 0.999 -> "All-in " + trimD(amt) + " bb"
        amt != null -> (if (u.startsWith("RAISE")) "Subida " else "Apuesta ") + f1(amt) + " bb"
        else -> a
    }
}

@Composable
private fun StackBar(vals: DoubleArray, colors: List<Color>, height: Int = 26, showText: Boolean = true) {
    Row(Modifier.fillMaxWidth().height(height.dp).clip(RoundedCornerShape(6.dp)).background(PC.P2)) {
        vals.forEachIndexed { k, f ->
            if (f > 0.05) Box(Modifier.weight(f.toFloat()).fillMaxHeight().background(colors[k]), contentAlignment = Alignment.Center) {
                if (showText && f > 9) Text(f1(f) + "%", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun TabSolver(e: Env) {
    val vm = e.vm
    val res = vm.sResult
    val kb = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    Sec("Spot · heads-up postflop") {
        Muted("CFR+ vectorial en tu teléfono sobre una calle. Árbol: check / apuesta 50% del bote / all-in; ante apuesta: fold / call / all-in. Fichas en bb.")
        Spacer(Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(vm.sBoard, { vm.sBoard = it; vm.sReview = null }, label = { Text("Mesa (3–5 cartas: Qs,Jh,2h)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Expand("Selector visual de mesa") { BoardPicker(vm.sBoard) { vm.sBoard = it; vm.sReview = null } }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(vm.sPot, { vm.sPot = it; vm.sReview = null }, label = { Text("Bote bb") }, singleLine = true, keyboardOptions = kb, modifier = Modifier.weight(1f))
                OutlinedTextField(vm.sStack, { vm.sStack = it; vm.sReview = null }, label = { Text("Stack bb") }, singleLine = true, keyboardOptions = kb, modifier = Modifier.weight(1f))
                OutlinedTextField(vm.sIters, { vm.sIters = it }, label = { Text("Iter.") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (vm.sBusy) GhostButton("Cancelar", { vm.cancelSolve() })
            else PrimaryButton("Resolver spot", { vm.solve() })
            Muted("Rangos más abajo ↓")
        }
        if (vm.sBusy) {
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { (vm.sProg / max(1f, (vm.sIters.toFloatOrNull() ?: 300f))).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = PC.Ac, trackColor = PC.P2)
        }
        Spacer(Modifier.height(8.dp))
        if (vm.sError.isNotEmpty()) Text(vm.sError, color = PC.Bd, fontSize = 13.sp)
        else if (vm.sBusy) Muted("Calculando… depende del tamaño de los rangos y de las iteraciones.")
        else if (vm.sNotice.isNotEmpty()) Note(vm.sNotice)
        else Muted("Define rangos representativos antes de resolver; los de ejemplo son solo un punto de partida.")
    }
    if (res != null) SolverResultView(vm, res)
    Sec("Rango en posición (IP)") { RangeEditor("IP", vm.sIp) { vm.sIp = it } }
    Sec("Rango fuera de posición (OOP)") { RangeEditor("OOP", vm.sOop) { vm.sOop = it } }
}

@Composable
fun SolverResultView(vm: MainVm, res: SolveResult) {
    var path by remember(res) { mutableStateOf<List<Int>>(emptyList()) }
    var mode by remember(res) { mutableStateOf("s") }
    var sel by remember(res) { mutableStateOf<String?>(null) }
    val chain = ArrayList<SNode>()
    chain.add(res.root)
    for (i in path) { val n = chain.last().children.getOrNull(i) ?: break; chain.add(n) }
    val node = chain.last()
    val colors = node.actions.map { actColor(it, res.stack) }
    val rv = vm.sReview
    val hs = res.heroStrategy
    val heroCls = rv?.cards?.let { if (it.size == 2) handClsName(CI(it[0]), CI(it[1])) else null }
    val eqm = if (node.player == "OOP") res.eqOopCls else res.eqIpCls

    Kpis(
        listOf(
            kp("Equity OOP", f1(100 * res.eqOop) + "%", "rango vs rango"), kp("Equity IP", f1(100 * (1 - res.eqOop)) + "%", "rango vs rango"),
            kp("Combos OOP / IP", "${res.nOop} / ${res.nIp}", "mesa " + res.board.joinToString(" ")),
            kp("Bote / stack", trimD(res.pot) + " / " + trimD(res.stack), "${res.iterations} iteraciones CFR+")
        )
    )
    if (res.conv.size >= 3) {
        Sec("Convergencia del CFR+") {
            val ys = res.conv.map { log10(max(1e-9, it.second)) }
            LineChart(ys, false)
            Caption("log₁₀ del cambio medio absoluto de la estrategia promedio del nodo raíz entre comprobaciones (cada 10 iteraciones). Pendiente negativa = converge.")
            Kpis(listOf(kp("Δ última comprobación", String.format(java.util.Locale.US, "%.2e", res.conv.last().second), "por mano y acción"), kp("Iteraciones", res.iterations.toString(), "CFR+ con promedio lineal")))
            Formula("CFR+: regretᵗ⁺ = máx(0, regretᵗ + Δ);  σ̄ = Σ t·reach·σᵗ / Σ t·reach\nEn juegos de 2 jugadores de suma cero σ̄ converge a un equilibrio de Nash. Δ es un indicador de convergencia, no la explotabilidad exacta.")
        }
    }
    if (rv != null) {
        if (hs != null) {
            var p = 0.0
            res.actions.forEachIndexed { i, a ->
                val match = if (rv.type == "AGGRESSIVE") Regex("^(BET|RAISE)\\b", RegexOption.IGNORE_CASE).containsMatchIn(a) else a.uppercase() == rv.type
                if (match) p += hs[i]
            }
            Note("Revisión de Hero (${rv.cards.joinToString(" ")})\nAcción histórica: ${rv.action}. Frecuencia de esa familia de acción en la estrategia CFR+ del nodo inicial: ${f1(p)}%.\nEs una comparación de frecuencias contra el rango configurado, no un EV ni prueba de error.")
        } else Note("El solver no tiene estrategia para las cartas de Hero en el rango OOP de este nodo inicial; no se compara la acción histórica.")
    }
    Sec("Árbol de decisión") {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            chain.forEachIndexed { k, n ->
                val lab = if (k == 0) "Inicio · OOP" else prettyAct(chain[k - 1].actions[path[k - 1]], res.stack) + " → " + n.player
                FilterChip(
                    selected = k == chain.size - 1, onClick = { path = path.take(k); sel = null }, label = { Text(lab, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PC.Ac, selectedLabelColor = Color.White)
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Muted("Nodo actual: jugador ${node.player} · ${f1(node.combos)} combos llegan a este punto.")
        Spacer(Modifier.height(6.dp))
        StackBar(node.freq, colors)
        Spacer(Modifier.height(10.dp))
        node.actions.forEachIndexed { k, a ->
            val child = node.children.getOrNull(k)
            Row(
                Modifier.fillMaxWidth().then(if (child != null) Modifier.clickable { path = path + k; sel = null } else Modifier).padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(12.dp).background(colors[k], RoundedCornerShape(3.dp)))
                Spacer(Modifier.width(8.dp))
                Text(prettyAct(a, res.stack), color = PC.Tx, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(f1(node.freq[k]) + "%", color = PC.Tx, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold)
                Text(if (child != null) "   ver ▸" else "   fin", color = if (child != null) PC.Ac else PC.Mu, fontSize = 12.sp)
            }
        }
        Muted("Toca una acción para descender por el árbol; la matriz muestra el rango que llega y su estrategia en ese nodo.")
    }
    Sec("Matriz de rango · jugador ${node.player}") {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            listOf("s" to "Estrategia", "r" to "Rango que llega", "e" to "Equity").forEach { (k, l) ->
                FilterChip(
                    selected = mode == k, onClick = { mode = k }, label = { Text(l) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PC.Ac, selectedLabelColor = Color.White)
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        RangeGrid(
            cell = { z ->
                val ci = node.cls[z]
                if (ci == null) RCell(bg = PC.P2.copy(alpha = .6f), label = z, txt = PC.Mu.copy(alpha = .35f))
                else when (mode) {
                    "s" -> RCell(bg = PC.P2, segs = ci.strat.mapIndexed { k, v -> colors[k] to (v / 100.0).toFloat() }, alpha = (.35 + .65 * ci.frac).toFloat(), label = z, txt = Color.White)
                    "r" -> RCell(bg = PC.P2, fill = ci.frac.toFloat(), fillColor = PC.Ac, label = z, sub = if (ci.frac < .995) (ci.frac * 100).toInt().toString() + "%" else "", txt = if (ci.frac > .5) Color.White else PC.Mu)
                    else -> {
                        val q = eqm[z] ?: 0.5
                        val f = ((q - .2) / .6).toFloat().coerceIn(0f, 1f)
                        RCell(bg = lerp(PC.Bd, PC.Gd, f).copy(alpha = .75f), label = z, sub = (q * 100).toInt().toString(), txt = Color.White)
                    }
                }
            },
            selected = sel, mark = if (node === res.root) heroCls else null, onTap = { sel = if (sel == it) null else it }
        )
        Spacer(Modifier.height(8.dp))
        when (mode) {
            "s" -> Legend(node.actions.mapIndexed { k, a -> prettyAct(a, res.stack) to colors[k] })
            "r" -> GradientLegend("0% llega", "100% llega", PC.Ac)
            else -> GradientLegend("equity baja", "equity alta (vs rango rival inicial)", PC.Gd)
        }
        if (node === res.root && heroCls != null) Muted("Borde amarillo = clase de Hero ($heroCls).")
        val z = sel
        val ci = if (z != null) node.cls[z] else null
        if (z != null && ci != null) {
            Spacer(Modifier.height(10.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(PC.P2).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("$z · llega el ${(ci.frac * 100).toInt()}% de sus combos · equity ${f1(100 * (eqm[z] ?: 0.0))}%", color = PC.Tx, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                StackBar(ci.strat, colors, 20, false)
                node.actions.forEachIndexed { k, a ->
                    Row { Text(prettyAct(a, res.stack), color = colors[k], fontSize = 13.sp, modifier = Modifier.weight(1f)); Text(f1(ci.strat[k]) + "%", color = PC.Tx, fontFamily = FontFamily.Monospace, fontSize = 13.sp) }
                }
                Muted("Combos de la clase (estrategia por palos):")
                ci.combos.take(12).forEach { (name, st) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.width(78.dp)) { Cards(listOf(name.substring(0, 2), name.substring(2, 4)), true) }
                        Box(Modifier.weight(1f)) { StackBar(st, colors, 12, false) }
                    }
                }
            }
        }
    }
    Muted("Estrategias promedio de CFR+ con rangos y tamaños discretos. Una sola calle: sin calles posteriores, sin ICM y sin botes multiway; el flop usa una muestra de 160 runouts. Es una herramienta de estudio, no una recomendación universal.")
}
