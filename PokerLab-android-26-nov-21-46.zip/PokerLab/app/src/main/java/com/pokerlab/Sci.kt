package com.pokerlab

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

// ===================== pruebas estadísticas =====================
fun starsOf(p: Double): String = if (p < 0.001) "★★★" else if (p < 0.01) "★★" else if (p < 0.05) "★" else "ns"

/** Ajuste de Benjamini–Hochberg (control de la tasa de falsos descubrimientos). */
fun bhAdjust(p: List<Double>): List<Double> {
    val n = p.size
    if (n == 0) return emptyList()
    val idx = p.indices.sortedBy { p[it] }
    val q = DoubleArray(n)
    var prev = 1.0
    for (r in n - 1 downTo 0) { val i = idx[r]; val v = min(prev, p[i] * n / (r + 1)); q[i] = v; prev = v }
    return q.toList()
}

class Z2(val diff: Double, val se: Double, val z: Double, val p: Double, val h: Double, val hse: Double)

/** Contraste z de dos proporciones (error típico combinado) con h de Cohen. */
fun twoProp(x1: Double, n1: Double, x2: Double, n2: Double): Z2? {
    if (n1 < 1 || n2 < 1) return null
    val p1 = x1 / n1; val p2 = x2 / n2; val pp = (x1 + x2) / (n1 + n2)
    val se0 = sqrt(pp * (1 - pp) * (1 / n1 + 1 / n2))
    val se = sqrt(p1 * (1 - p1) / n1 + p2 * (1 - p2) / n2)
    val z = if (se0 > 0) (p1 - p2) / se0 else 0.0
    val h = 2 * asin(sqrt(p1)) - 2 * asin(sqrt(p2))
    return Z2(p1 - p2, se, z, 2 * (1 - normCdf(abs(z))), h, sqrt(1 / n1 + 1 / n2))
}

class WelchR(val diff: Double, val se: Double, val t: Double, val p: Double)

fun welch(m1: Double, s1: Double, n1: Double, m2: Double, s2: Double, n2: Double): WelchR {
    val se = sqrt(s1 * s1 / n1 + s2 * s2 / n2)
    val t = if (se > 0) (m1 - m2) / se else 0.0
    return WelchR(m1 - m2, se, t, 2 * (1 - normCdf(abs(t))))
}

/** P(F > f) para una F de Fisher con (d1, d2) grados de libertad. */
fun fSf(f: Double, d1: Double, d2: Double): Double = if (f <= 0) 1.0 else betaCdf(d2 / 2, d1 / 2, d2 / (d2 + d1 * f))

class Anova(val f: Double, val p: Double, val eta2: Double, val d1: Int, val d2: Int)

/** ANOVA de un factor sobre el resultado por mano (bb). */
fun anovaOf(groups: List<List<Hand>>): Anova? {
    val g = groups.filter { it.size >= 5 }
    val k = g.size
    if (k < 2) return null
    var nTot = 0.0; var sumTot = 0.0
    val ns = DoubleArray(k); val ms = DoubleArray(k); val ssw = DoubleArray(k)
    for (i in 0 until k) {
        val z = g[i]; ns[i] = z.size.toDouble()
        ms[i] = z.sumOf { it.nb } / ns[i]
        ssw[i] = z.sumOf { (it.nb - ms[i]) * (it.nb - ms[i]) }
        nTot += ns[i]; sumTot += ns[i] * ms[i]
    }
    val gm = sumTot / nTot
    var ssb = 0.0; var sw = 0.0
    for (i in 0 until k) { ssb += ns[i] * (ms[i] - gm) * (ms[i] - gm); sw += ssw[i] }
    val d1 = k - 1; val d2 = (nTot - k).toInt()
    if (d2 < 1 || sw <= 0) return null
    val f = (ssb / d1) / (sw / d2)
    return Anova(f, fSf(f, d1.toDouble(), d2.toDouble()), ssb / (ssb + sw), d1, d2)
}

/** Contraste de tendencia de Cochran–Armitage para proporciones ordenadas. */
fun trendCA(x: DoubleArray, n: DoubleArray, sc: DoubleArray): Pair<Double, Double>? {
    val tot = n.sum(); val p = x.sum() / tot
    if (tot <= 0 || p <= 0 || p >= 1) return null
    var t = 0.0; var m = 0.0; var m2 = 0.0
    for (i in x.indices) { t += sc[i] * (x[i] - n[i] * p); m += n[i] * sc[i]; m2 += n[i] * sc[i] * sc[i] }
    val v = p * (1 - p) * (m2 - m * m / tot)
    if (v <= 0) return null
    val z = t / sqrt(v)
    return Pair(z, 2 * (1 - normCdf(abs(z))))
}

/** Homogeneidad de k proporciones (chi-cuadrado k×2). */
fun chi2Hom(x: DoubleArray, n: DoubleArray): Triple<Double, Double, Int>? {
    val tot = n.sum(); val p = x.sum() / tot
    if (x.size < 2 || p <= 0 || p >= 1) return null
    var chi = 0.0
    for (i in x.indices) {
        val e1 = n[i] * p; val e0 = n[i] * (1 - p)
        if (e1 > 0 && e0 > 0) chi += (x[i] - e1) * (x[i] - e1) / e1 + ((n[i] - x[i]) - e0) * ((n[i] - x[i]) - e0) / e0
    }
    val df = x.size - 1
    return Triple(chi, chi2Sf(chi, df.toDouble()), df)
}

fun rankAvg(x: DoubleArray): DoubleArray {
    val idx = x.indices.sortedBy { x[it] }
    val r = DoubleArray(x.size)
    var i = 0
    while (i < idx.size) {
        var j = i
        while (j + 1 < idx.size && x[idx[j + 1]] == x[idx[i]]) j++
        val avg = (i + j) / 2.0 + 1
        for (k in i..j) r[idx[k]] = avg
        i = j + 1
    }
    return r
}

fun pearson(x: DoubleArray, y: DoubleArray): Double {
    val n = x.size
    if (n < 3) return Double.NaN
    val mx = x.average(); val my = y.average()
    var sxy = 0.0; var sxx = 0.0; var syy = 0.0
    for (i in 0 until n) { sxy += (x[i] - mx) * (y[i] - my); sxx += (x[i] - mx) * (x[i] - mx); syy += (y[i] - my) * (y[i] - my) }
    return if (sxx > 0 && syy > 0) sxy / sqrt(sxx * syy) else Double.NaN
}

/** Correlación de Spearman con p aproximado (t de Student ≈ normal). */
fun spearman(x: DoubleArray, y: DoubleArray): Pair<Double, Double> {
    val rho = pearson(rankAvg(x), rankAvg(y))
    val n = x.size
    if (rho.isNaN() || n < 4) return Pair(rho, 1.0)
    val t = rho * sqrt((n - 2) / max(1e-12, 1 - rho * rho))
    return Pair(rho, 2 * (1 - normCdf(abs(t))))
}

class KM(val t: List<Double>, val s: List<Double>, val lo: List<Double>, val hi: List<Double>, val median: Double?)

/** Estimador de Kaplan–Meier con bandas de Greenwood al 95%. */
fun kaplanMeier(times: DoubleArray, ev: BooleanArray): KM {
    val idx = times.indices.sortedBy { times[it] }
    var atRisk = times.size; var s = 1.0; var gw = 0.0
    val t = arrayListOf(0.0); val sv = arrayListOf(1.0); val lo = arrayListOf(1.0); val hi = arrayListOf(1.0)
    var i = 0; var med: Double? = null
    while (i < idx.size) {
        val tt = times[idx[i]]
        var d = 0; var c = 0; var j = i
        while (j < idx.size && times[idx[j]] == tt) { if (ev[idx[j]]) d++ else c++; j++ }
        if (d > 0) {
            s *= (1.0 - d.toDouble() / atRisk)
            if (atRisk - d > 0) gw += d.toDouble() / (atRisk.toDouble() * (atRisk - d))
            val se = s * sqrt(gw)
            t.add(tt); sv.add(sv.last()); lo.add(lo.last()); hi.add(hi.last())
            t.add(tt); sv.add(s); lo.add(max(0.0, s - 1.96 * se)); hi.add(min(1.0, s + 1.96 * se))
            if (med == null && s <= 0.5) med = tt
        }
        atRisk -= (d + c)
        i = j
    }
    return KM(t, sv, lo, hi, med)
}

fun giniOf(v: List<Double>): Double {
    val x = v.sorted()
    val n = x.size
    val tot = x.sum()
    if (n == 0 || tot <= 0) return 0.0
    var acc = 0.0
    for (i in 0 until n) acc += (i + 1) * x[i]
    return 2 * acc / (n * tot) - (n + 1.0) / n
}

fun calPts(ai: List<Hand>): List<CalPt> {
    val cal = ArrayList<CalPt>()
    for (b in 0 until 10) {
        val z = ai.filter { val e = it.eq!!.e; e >= b / 10.0 && (e < (b + 1) / 10.0 || (b == 9 && e <= 1.0)) }
        if (z.size >= 4) {
            val w = z.count { it.nb > 0 }
            val ci = wl(w.toDouble(), z.size.toDouble())
            cal.add(CalPt(z.sumOf { it.eq!!.e } / z.size, w.toDouble() / z.size, ci.first / 100, ci.second / 100, z.size))
        }
    }
    return cal
}

/** Cota de nivel a partir de los IC de cada estadística (propagación de la incertidumbre del puntaje). */
fun levelInterval(L: Lvl): Pair<Double, Double> {
    var rawLo = 0.0; var rawHi = 0.0; var sw = 0.0
    for (c in L.cw.keys) {
        val cv = L.C[c]!!
        val w = L.cw[c]!!
        if (c == "Res") {
            val a = max(0.0, min(100.0, 40 + L.x.adjM - 1.5 * L.x.ci))
            val b = max(0.0, min(100.0, 40 + L.x.adjM + .5 * L.x.ci))
            rawLo += a * w; rawHi += b * w; sw += w
            continue
        }
        if (cv.v == null) continue
        var nl = 0.0; var nh = 0.0
        for (r in L.R) {
            if (r.e.cat != c || r.sc == null || r.e.w <= 0) continue
            val sc0: Double = r.sc
            var sLo: Double = sc0; var sHi: Double = sc0
            if (r.l != null && r.h != null) {
                val a = scr(r.l, r.e.lo, r.e.hi, r.e.t) ?: sc0
                val b = scr(r.h, r.e.lo, r.e.hi, r.e.t) ?: sc0
                val inside = r.l <= r.e.hi && r.h >= r.e.lo
                sLo = min(sc0, min(a, b)); sHi = if (inside) 100.0 else max(sc0, max(a, b))
            }
            nl += sLo * r.e.w * r.r; nh += sHi * r.e.w * r.r
        }
        rawLo += nl / cv.W * w; rawHi += nh / cv.W * w; sw += w
    }
    if (sw <= 0) return Pair(L.adj, L.adj)
    rawLo /= sw; rawHi /= sw
    val prior = 38.0
    return Pair(min(prior + (rawLo - prior) * L.sh, L.cap), min(prior + (rawHi - prior) * L.sh, L.cap))
}

// ===================== componentes de laboratorio =====================
@Composable
fun Caption(t: String) {
    Text("FIG ▸ " + t, color = PC.Mu, fontSize = 10.5.sp, fontFamily = FontFamily.Monospace, lineHeight = 14.sp, modifier = Modifier.padding(top = 4.dp))
}

@Composable
fun LabDivider(title: String) {
    Row(Modifier.fillMaxWidth().padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        TabIcon("flask", PC.Ac2, 18.dp)
        Spacer(Modifier.width(8.dp))
        Text(title.uppercase(), color = PC.Ac2, fontSize = 11.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace)
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f).height(1.dp).background(PC.Edge1))
    }
}

@Composable
fun LabStrip(hs: List<Hand>, ver: Int) {
    if (hs.isEmpty()) return
    val ev = derived(hs, ver).ev
    val tours = remember(hs) { hs.map { it.tid }.toSet().size }
    val d0 = LocalDate.ofEpochDay(hs.first().day); val d1 = LocalDate.ofEpochDay(hs.last().day)
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(6.dp).height(6.dp).background(PC.Gd, androidx.compose.foundation.shape.CircleShape))
        Spacer(Modifier.width(8.dp))
        Text(
            "N=" + fmtN(hs.size) + " · TORNEOS=" + tours + " · α=0.05 · IC=WILSON/BOOT · EV=" + ev.n + "/" + (ev.n + ev.pend + ev.unk) + " · " + d0 + "→" + d1,
            color = PC.Mu, fontSize = 10.sp, fontFamily = FontFamily.Monospace, softWrap = false, maxLines = 1
        )
    }
}

fun sigText(p: Double): String = starsOf(p) + " p=" + fmtP(p)

/** Pareto: barras descendentes y porcentaje acumulado. */
@Composable
fun ParetoChart(labels: List<String>, v: List<Double>) {
    if (v.isEmpty()) return
    val tm = rememberTextMeasurer()
    val prog = rememberProg(v, 800)
    val tot = v.sum().let { if (it == 0.0) 1.0 else it }
    Canvas(Modifier.fillMaxWidth().height(230.dp)) {
        val g = geo()
        val (lo, hi, t) = nice(0.0, v.max())
        val Y = drawGrid(tm, lo, hi, t, g)
        val n = v.size
        val w = (size.width - g.pl - g.pr) / n
        val y0 = Y(0.0)
        val base = size.height - g.pb; val span = base - g.pt
        var cum = 0.0
        val line = Path()
        for (i in 0 until n) {
            val bx = g.pl + i * w + w * .18f; val bw = w * .64f
            val h = max((y0 - Y(v[i])) * prog, 1f)
            drawRoundRect(Brush.verticalGradient(listOf(PC.Ac2, PC.Ac2.copy(alpha = .4f)), startY = y0 - h, endY = y0), Offset(bx, y0 - h), Size(bw, h), CornerRadius(4.dp.toPx()))
            cum += v[i]
            val cy = base - (cum / tot * span).toFloat()
            if (i == 0) line.moveTo(bx + bw / 2, cy) else line.lineTo(bx + bw / 2, cy)
            drawCircle(PC.Wn, 3.dp.toPx(), Offset(bx + bw / 2, cy))
            txt(tm, labels[i].take(9), bx + bw / 2, size.height - 8.dp.toPx(), labelStyle, 1)
        }
        drawPath(line, PC.Wn, style = Stroke(1.6.dp.toPx(), join = StrokeJoin.Round))
        for (q in listOf(0.0, .5, 1.0)) txt(tm, (q * 100).toInt().toString() + "%", size.width - g.pr + 8.dp.toPx(), base - (q * span).toFloat(), labelStyle.copy(color = PC.Wn), 2)
    }
}

class VPt(val x: Double, val y: Double, val label: String, val sig: Boolean)

/** Gráfico de volcán: tamaño del efecto frente a −log10(p). */
@Composable
fun VolcanoPlot(p: List<VPt>, xUnit: String = "") {
    if (p.isEmpty()) { Muted("Sin contrastes."); return }
    val tm = rememberTextMeasurer()
    val prog = rememberProg(p.size, 900)
    Canvas(Modifier.fillMaxWidth().height(260.dp)) {
        val g = geo()
        val xm = max(1.0, p.maxOf { abs(it.x) } * 1.15)
        val (_, y1, t) = nice(0.0, max(3.5, p.maxOf { it.y }))
        val Y = drawGrid(tm, 0.0, y1, t, g)
        val X = { v: Double -> (g.pl + (v + xm) / (2 * xm) * (size.width - g.pl - g.pr)).toFloat() }
        for (v in listOf(-xm, 0.0, xm)) txt(tm, fmtTick(Math.round(v * 10) / 10.0) + xUnit, X(v), size.height - 8.dp.toPx(), labelStyle, 1)
        drawLine(PC.Mu.copy(alpha = .6f), Offset(X(0.0), g.pt), Offset(X(0.0), size.height - g.pb), 1f)
        drawLine(PC.Wn, Offset(g.pl, Y(-ln(0.05) / ln(10.0))), Offset(size.width - g.pr, Y(-ln(0.05) / ln(10.0))), 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f)))
        for (q in p) drawCircle((if (!q.sig) PC.Mu else if (q.x >= 0) PC.Gd else PC.Bd).copy(alpha = .85f), 5.dp.toPx() * prog, Offset(X(q.x), Y(q.y)))
        p.sortedByDescending { it.y }.take(4).forEach { q -> txt(tm, q.label.take(16), X(q.x) + 8.dp.toPx(), Y(q.y) - 6.dp.toPx(), labelStyle, if (q.x > xm * .4) 2 else 0) }
        txt(tm, "−log₁₀ p ↑", g.pl + 4.dp.toPx(), g.pt + 2.dp.toPx(), labelStyle, 0)
    }
}

/** Mapa de calor de correlaciones. */
@Composable
fun CorrHeat(labels: List<String>, r: Array<DoubleArray>) {
    val tm = rememberTextMeasurer()
    val prog = rememberProg(labels, 800)
    Canvas(Modifier.fillMaxWidth().aspectRatio(1f)) {
        val k = labels.size
        val lw = 52.dp.toPx(); val top = 18.dp.toPx()
        val cw = (size.width - lw) / k; val ch = (size.height - top) / k
        for (j in 0 until k) txt(tm, labels[j].take(6), lw + j * cw + cw / 2, 8.dp.toPx(), labelStyle, 1)
        for (i in 0 until k) {
            txt(tm, labels[i].take(8), 0f, top + i * ch + ch / 2, labelStyle, 0)
            for (j in 0 until k) {
                val v = r[i][j]
                val c = if (v.isNaN()) PC.P2 else lerp(PC.P2, if (v >= 0) PC.Gd else PC.Bd, (min(1.0, abs(v)) * .9).toFloat() * prog)
                drawRoundRect(c, Offset(lw + j * cw + 1.dp.toPx(), top + i * ch + 1.dp.toPx()), Size(cw - 2.dp.toPx(), ch - 2.dp.toPx()), CornerRadius(3.dp.toPx()))
                txt(tm, if (v.isNaN()) "–" else f2(v), lw + j * cw + cw / 2, top + i * ch + ch / 2, valueStyle.copy(fontSize = 8.5.sp), 1)
            }
        }
    }
}

// ===================== tablas reutilizables =====================
@Composable
fun PrecisionTable(s: Agg, ids: List<String>) {
    val rows = ids.mapNotNull { id ->
        val e = SM[id] ?: return@mapNotNull null
        if (e.f != null || e.u != "%") return@mapNotNull null
        val x = gc(s, e.n); val n = gc(s, e.d)
        if (n < 1) return@mapNotNull null
        val p = x / n
        val se = sqrt(p * (1 - p) / n)
        val w = wl(x, n)
        val need = kotlin.math.ceil(3.8416 * p * (1 - p) / (0.02 * 0.02)).toLong()
        listOf<Any>(e.name, fmtN(n), f1(100 * p) + "%", f2(100 * se), f1(w.first) + "–" + f1(w.second), "±" + f1(196 * se), fmtN(need), f2(n / (n + 30)))
    }
    Table(listOf("Estadística", "n", "p̂", "EE (pt)", "IC95% Wilson", "Margen", "n p/ ±2 pt", "Fiab."), rows, listOf(150, 60, 64, 64, 104, 66, 80, 56))
}
