package com.pokerlab

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

@Composable
fun rememberCsvExporter(): (List<Hand>) -> Unit {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<List<Hand>?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        val L = pending
        if (uri != null && L != null) ctx.contentResolver.openOutputStream(uri)?.use { it.write(csvOf(L).toByteArray()) }
    }
    return { L -> pending = L; launcher.launch("poker-lab-manos.csv") }
}

// ===================== SEGUIMIENTO =====================
private val PLB = linkedMapOf(
    "all" to "Todo el historial", "7" to "Últimos 7 días", "30" to "Últimos 30 días", "90" to "Últimos 90 días", "mes" to "Este mes", "pmes" to "Mes anterior",
    "p7" to "7 días anteriores", "p30" to "30 días anteriores", "p90" to "90 días anteriores", "h1" to "Primera mitad", "h2" to "Segunda mitad", "c" to "Personalizado"
)

private fun fd(t: Long): String = java.text.DateFormat.getDateInstance(java.text.DateFormat.MEDIUM).format(java.util.Date(t))
private fun rg(o: Rng, H: List<Hand>): String {
    val r = prng(o, H)
    return fd(if (r[0] > 0) r[0] else H.first().ts) + " – " + fd(if (r[1] != INF) r[1] else H.last().ts)
}

private fun bkey(h: Hand, g: String): Long = when (g) {
    "m" -> LocalDate.ofEpochDay(h.day).withDayOfMonth(1).toEpochDay()
    "w" -> h.day - h.dow
    else -> h.day
}

private fun blab(k: Long, g: String): String {
    val d = LocalDate.ofEpochDay(k)
    return d.format(DateTimeFormatter.ofPattern(if (g == "m") "MMM yy" else "d MMM", Locale("es")))
}

@Composable
private fun PeriodSel(title: String, o: Rng, onChange: (Rng) -> Unit) {
    Column {
        Drop("$title: ", PLB.map { it.key to it.value }, o.m) { onChange(Rng(it, o.f, o.t)) }
        if (o.m == "c") Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DateField("Desde", o.f) { onChange(Rng(o.m, it, o.t)) }
            DateField("Hasta", o.t) { onChange(Rng(o.m, o.f, it)) }
        }
    }
}

private class Cmp(val e: StatDef, val a: SRes, val b: SRes, val ok: Boolean, val d: Double?, val im: Double?)

@Composable
fun TabSeg(e: Env) {
    val vm = e.vm; val hs = e.hs
    fun inR(r: LongArray) = hs.filter { it.ts >= r[0] && it.ts <= r[1] }
    val hA = inR(prng(vm.cpa, vm.H)); val hB = inR(prng(vm.cpb, vm.H))
    Sec("Comparar períodos") {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            PeriodSel("Período A (actual)", vm.cpa) { vm.cpa = it }
            PeriodSel("Período B (referencia)", vm.cpb) { vm.cpb = it }
        }
        if (hs.isNotEmpty()) Muted("A: ${rg(vm.cpa, vm.H)} · ${fmtN(hA.size)} manos\nB: ${rg(vm.cpb, vm.H)} · ${fmtN(hB.size)} manos")
    }
    if (hA.size < 30 || hB.size < 30) {
        Note("Cada período necesita al menos 30 manos para compararse. Ajusta las fechas o usa «Primera mitad» contra «Segunda mitad».")
    } else {
        val sA = S(hA); val sB = S(hB); val xA = ctx(hA, sA); val xB = ctx(hB, sB)
        val LA = level(hA, sA); val LB = level(hB, sB); val bA = B(sA); val bB = B(sB)
        val R_ = ST.filter { it.w > 0 }.map { st ->
            val a = SR(st, sA, xA); val b = SR(st, sB, xB); val ok = a.ok && b.ok
            Cmp(st, a, b, ok, if (ok) a.v!! - b.v!! else null, if (ok) a.sc!! - b.sc!! else null)
        }
        fun V(r: Cmp) = if (!r.ok) "Muestra corta" else if (r.im!! >= 8) "Mejora" else if (r.im <= -8) "Retroceso" else "Estable"
        val nM = R_.count { V(it) == "Mejora" }; val nW = R_.count { V(it) == "Retroceso" }; val nS = R_.count { V(it) == "Estable" }
        val up = R_.filter { it.ok && it.im!! > 0 }.sortedByDescending { it.im }.take(6)
        val dw = R_.filter { it.ok && it.im!! < 0 }.sortedBy { it.im }.take(6)
        fun row(r: Cmp) = listOf<Any>(r.e.name, fv(r.b) + " → " + fv(r.a), Tone((if (r.im!! > 0) "+" else "") + r.im.toInt(), toneOf(r.im)))
        fun dn(a: Double, b: Double, d: Int) = (if (a - b >= 0) "+" else "") + String.format(Locale.US, "%." + d + "f", a - b)
        Sec("Resumen del cambio") {
            Kpis(
                listOf(
                    kp("Manos A / B", fmtN(hA.size) + " / " + fmtN(hB.size)), kp("bb/100 (A)", f1(bA.m), "B: ${f1(bB.m)} · cambio ${dn(bA.m, bB.m, 1)}", toneOf(bA.m)),
                    kp("bb/100 ajust. EV (A)", f1(xA.adjM), "B: " + f1(xB.adjM), toneOf(xA.adjM)), kp("Nivel (A)", LA.adj.toInt().toString(), "${LA.ti.name} · B: ${LB.adj.toInt()} (${dn(LA.adj, LB.adj, 1)})"),
                    kp("Mejoran", nM.toString(), "estadísticas"), kp("Retroceden", nW.toString(), "estadísticas"), kp("Estables", nS.toString(), "estadísticas")
                )
            )
        }
        Sec("Perfil por categorías: A contra B") {
            Radar(CK.map { LBL[it]!! }, listOf(Triple(CK.map { LB.C[it]!!.v ?: 0.0 }, Color(0xFF7A6A72), "Período B"), Triple(CK.map { LA.C[it]!!.v ?: 0.0 }, PC.Ac, "Período A")))
        }
        Sec("Cambio por categoría (A menos B)") { BarChart(CK.map { LBL[it]!! }, CK.map { (LA.C[it]!!.v ?: 0.0) - (LB.C[it]!!.v ?: 0.0) }) }
        Sec("Lo que más mejoró") { Table(listOf("Mejoró", "B → A", "Puntaje"), up.map { row(it) }, listOf(190, 130, 70)) }
        Sec("Lo que más retrocedió") { Table(listOf("Retrocedió", "B → A", "Puntaje"), dw.map { row(it) }, listOf(190, 130, 70)) }
        Sec("Todas las estadísticas") {
            Table(
                listOf("Estadística", "B", "A", "Cambio", "Ideal", "Tendencia"),
                R_.map { r ->
                    val dv: Any = if (r.d == null) "–" else Tone((if (r.d >= 0) "+" else "") + (if (r.e.u == "x") f2(r.d) else f1(r.d)) + (if (r.e.u == "%" || r.e.u == "pt") " pts" else if (r.e.u == "x") "" else " " + r.e.u), toneOf(r.im!!))
                    listOf<Any>(r.e.name, fv(r.b), fv(r.a), dv, fmtB(r.e.lo) + "–" + fmtB(r.e.hi) + unitOf(r.e), PillC(V(r)))
                }, listOf(190, 90, 90, 90, 100, 110)
            )
            Muted("Tendencia según el puntaje de cada estadística (cercanía al rango ideal): Mejora si sube 8 puntos o más, Retroceso si baja 8 o más. Con muestras cortas no se evalúa.")
        }
    }
    if (hs.isEmpty()) return
    val span = (hs.last().ts - hs.first().ts).toDouble() / DAY
    val g = if (vm.seg.g == "auto") (if (span <= 21) "d" else if (span <= 120) "w" else "m") else vm.seg.g
    val bs = remember(hs, g) {
        val mp = java.util.TreeMap<Long, ArrayList<Hand>>()
        for (h in hs) mp.getOrPut(bkey(h, g)) { ArrayList() }.add(h)
        mp.entries.toList().takeLast(16).map { (t, z) -> val s = S(z); Triple(blab(t, g), z, Pair(s, ctx(z, s))) }
    }
    val se = SM[vm.seg.s]
    fun sv(b: Triple<String, List<Hand>, Pair<Agg, Ctx>>): Double {
        if (vm.seg.s == "bb") return B(b.third.first).m
        val r = SR(se!!, b.third.first, b.third.second)
        return if (r.ok) r.v!! else 0.0
    }
    fun sg(id: String, b: Triple<String, List<Hand>, Pair<Agg, Ctx>>): String { val r = SR(SM[id]!!, b.third.first, b.third.second); return if (r.ok) fv(r) else "–" }
    Sec("Evolución por período") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            Drop("Agrupar: ", listOf("auto" to "Automático", "d" to "Día", "w" to "Semana", "m" to "Mes"), vm.seg.g) { vm.seg = SegState(it, vm.seg.s) }
            Drop("Métrica: ", listOf("bb" to "bb/100") + ST.filter { it.w > 0 }.map { it.id to it.name }, vm.seg.s) { vm.seg = SegState(vm.seg.g, it) }
        }
        Spacer(Modifier.height(8.dp))
        BarChart(bs.map { it.first }, bs.map { sv(it) }, vm.seg.s != "bb")
        Muted((if (se != null) "Ideal: ${fmtB(se.lo)}–${fmtB(se.hi)}${unitOf(se)}. " else "") + "Cada barra es un${if (g == "m") " mes" else if (g == "w") "a semana" else " día"}; los períodos con muestra corta salen en 0.")
    }
    Sec("Seguimiento de decisiones") {
        Table(
            listOf("Período", "Manos", "VPIP", "PFR", "3-bet", "C-bet", "Fold a C-bet", "WTSD", "Alertas", "bb/100"),
            bs.map { b -> listOf<Any>(b.first, b.third.first.n, sg("vpip", b), sg("pfr", b), sg("t3", b), sg("cb", b), sg("fcb", b), sg("wtsd", b), pc(b.third.second.bad.toDouble(), b.third.first.n.toDouble()), nbc(B(b.third.first).m)) },
            listOf(90, 60, 70, 70, 70, 70, 90, 70, 70, 80)
        )
    }
}

// ===================== EXPLORADOR =====================
@Composable
fun TabHnd(e: Env) {
    val vm = e.vm; val hs = e.hs; val f = vm.hf
    val export = rememberCsvExporter()
    val L = remember(hs, f) {
        val q = f.q.trim().lowercase()
        hs.filter { h ->
            (f.pos == "all" || h.pos == f.pos) &&
                (f.r == "all" || (if (f.r == "w") h.nb > 0 else if (f.r == "l") h.nb < 0 else if (f.r == "ai") h.anyAI == 1 else h.sd == 1)) &&
                (q.isEmpty() || (h.id + " " + h.tn + " " + (h.cards ?: emptyList()).joinToString("") + " " + (h.cards?.let { hk(it) } ?: "") + " " + (h.hc ?: "")).lowercase().contains(q))
        }
    }
    Sec("Filtro y búsqueda de manos") {
        OutlinedTextField(
            value = f.q, onValueChange = { vm.hf = HFilter(it, f.pos, f.r) }, label = { Text("Buscar: AKs, AhKd, ID, torneo…") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            Drop("Posición: ", listOf("all" to "Todas") + PO.map { it to it }, f.pos) { vm.hf = HFilter(f.q, it, f.r) }
            Drop("Resultado: ", listOf("all" to "Todas", "w" to "Ganadas", "l" to "Perdidas", "ai" to "All-in", "sd" to "Showdown"), f.r) { vm.hf = HFilter(f.q, f.pos, it) }
            OutlinedButton(onClick = { export(L) }) { Text("⬇ CSV del filtro") }
        }
        Muted("${fmtN(L.size)} de ${fmtN(hs.size)} manos${if (L.size > 150) " (se muestran las 150 más recientes)" else ""}. Toca una mano para repetirla en la mesa.")
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { L.takeLast(150).reversed().forEach { HandMini(it, Modifier.fillMaxWidth()) } }
}

// ===================== RIVALES =====================
private class RvA { var n = 0; var v = 0; var pf = 0; var t3 = 0; var t3o = 0; var ag = 0; var ca = 0; var nv = 0.0 }

@Composable
fun TabRiv(e: Env) {
    val hs = e.hs
    val data by produceState<List<Pair<String, RvA>>?>(null, hs) {
        value = null
        value = withContext(Dispatchers.Default) {
            val M = HashMap<String, RvA>()
            fun A(p: String) = M.getOrPut(p) { RvA() }
            val reSeat = Regex("""^Seat \d+: (\S+) \(""")
            val reAct = Regex("""^(\S+): (folds|checks|calls|bets|raises|ALLIN)""")
            val reSt = Regex("""^\*\*\* (FLOP|TURN|RIVER)""")
            for (h in hs) {
                var st = false; var rc = 0
                val v = HashSet<String>(); val pf = HashSet<String>(); val ins = HashSet<String>()
                for (l in h.raw.split("\n")) {
                    if (reSt.containsMatchIn(l)) { st = true; continue }
                    if (l.startsWith("*** SUMMARY")) break
                    val ms = reSeat.find(l)
                    if (ms != null) { if (ms.groupValues[1] != "Hero") ins.add(ms.groupValues[1]); continue }
                    val m = reAct.find(l) ?: continue
                    if (m.groupValues[1] == "Hero") continue
                    val p = m.groupValues[1]; val k = m.groupValues[2]; val ag = k == "bets" || k == "raises" || k == "ALLIN"
                    if (!st) {
                        if (rc == 1) { A(p).t3o++; if (ag) A(p).t3++ }
                        if (ag) rc++
                        if (k != "folds" && k != "checks") { v.add(p); if (ag) pf.add(p) }
                    } else { val a = A(p); if (ag) a.ag++ else if (k == "calls") a.ca++ }
                }
                for (p in ins) { val a = A(p); a.n++; if (v.contains(p)) { a.v++; a.nv += h.nb }; if (pf.contains(p)) a.pf++ }
            }
            M.entries.filter { it.value.n >= 8 }.sortedByDescending { it.value.n }.take(40).map { it.key to it.value }
        }
    }
    val R_ = data
    if (R_ == null) { Muted("Calculando rivales…"); return }
    if (R_.isEmpty()) { Sec("Rivales") { Muted("Se necesitan al menos 8 manos con el mismo rival.") }; return }
    fun P_(a: Int, b: Int) = if (b > 0) a.toDouble() / b * 100 else 0.0
    fun lab(a: RvA): String {
        val v = P_(a.v, a.n); val g = if (a.ca > 0) a.ag.toDouble() / a.ca else if (a.ag > 0) 9.0 else 0.0
        return (if (v < 16) "Tight" else if (v < 26) "Regular" else if (v < 40) "Suelto" else "Muy suelto") + (if (g >= 2.5) " · agresivo" else if (g < 1) " · pasivo" else "")
    }
    val t12 = R_.take(12)
    val by = R_.sortedByDescending { it.second.nv }
    val ex = by.take(6) + by.takeLast(6).filter { z -> !by.take(6).contains(z) }
    Sec("VPIP y PFR de tus rivales más frecuentes") { BarChart2(t12.map { it.first.take(6) }, t12.map { P_(it.second.v, it.second.n) }, t12.map { P_(it.second.pf, it.second.n) }) }
    Sec("Tu resultado cuando ellos entran al bote (bb)") { BarChart(ex.map { it.first.take(6) }, ex.map { it.second.nv }) }
    Sec("Detalle de rivales (mínimo 8 manos juntos)") {
        Table(
            listOf("Rival", "Manos", "VPIP", "PFR", "3-bet", "AF", "Tu neto (bb)", "Perfil"),
            R_.map { (p, a) -> listOf<Any>(p, a.n, f1(P_(a.v, a.n)) + "%", f1(P_(a.pf, a.n)) + "%", if (a.t3o > 0) f1(P_(a.t3, a.t3o)) + "%" else "–", if (a.ca > 0) f1(a.ag.toDouble() / a.ca) else "–", nbc(a.nv), lab(a)) },
            listOf(110, 60, 70, 70, 70, 60, 90, 170)
        )
        Muted("Estadísticas calculadas con las manos filtradas. Con pocas manos por rival son orientativas; AF = apuestas y subidas / calls postflop.")
    }
}

// ===================== TORNEO (detalle) =====================
@Composable
fun TourHeader(g: Tour) {
    val s = g.s
    Text(g.name, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = PC.Tx)
    Muted("ID ${g.id} · ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(g.t0))} · ${f1(g.dur)} min · ciegas finales ${trimD(g.hs.last().bb)}")
    Kpis(
        listOf(
            kp("Manos", s.n.toString()), kp("Stack ini→fin", "${Math.round(g.s0)}→${Math.round(g.end)}"), kp("Pico (bb)", f1(g.peak)), kp("Neto bb", f1(s.nb), "", toneOf(s.nb)),
            kp("Estado", if (g.bust) "Eliminado" else "Sin elim."), kp("VPIP / PFR", q(s, "vpip_x", "vpip_o", 0) + " / " + q(s, "pfr_x", "pfr_o", 0))
        )
    )
}

@Composable
fun TourOverview(g: Tour) {
    var c = 0.0
    val P = PO.map { p -> S(g.hs.filter { it.pos == p }).nb }
    val w = min(20, g.hs.size / 3)
    val lv = LinkedHashMap<Double, DoubleArray>()
    for (h in g.hs) { val o = lv.getOrPut(h.bb) { DoubleArray(4) }; o[0]++; o[1] += h.stack / h.bb; o[2] += h.nb; o[3] += h.vpip }
    Sec("${g.name.take(30)} · stack (bb)") { LineChart(g.hs.map { it.stack / it.bb }) }
    Sec("Resultado acumulado (bb)") { LineChart(g.hs.map { c += it.nb; c }, true) }
    Sec("VPIP / PFR móvil ($w manos)") { if (w >= 5) MultiLine(listOf(roll(g.hs, { it.vpip }, w), roll(g.hs, { it.pfr }, w)), listOf(PC.Ac, PC.Gr2), listOf("VPIP", "PFR")) }
    Sec("Neto por posición (bb)") { BarChart(PO, P) }
    HandSec("Mejores manos del torneo", byNb(g.hs, 3, true))
    HandSec("Peores manos del torneo", byNb(g.hs, 3, false))
    Sec("Niveles de ciegas") {
        Table(listOf("BB", "Manos", "Stack medio (bb)", "VPIP", "Neto bb"), lv.entries.map { (bb, o) -> listOf<Any>(trimD(bb), o[0].toInt(), f1(o[1] / o[0]), pc(o[3], o[0]), nbc(o[2])) }, listOf(70, 70, 120, 70, 80))
    }
}

@Composable
fun TourScreen(vm: MainVm, id: String) {
    val hs = remember(vm.H, id) { vm.H.filter { it.tid == id }.sortedWith(CMP) }
    if (hs.isEmpty()) { Muted("Torneo no encontrado."); return }
    val g = remember(hs) { tours(hs)[0] }
    TextButton(onClick = { vm.tour = null }) { Text("← Todos los torneos") }
    TourHeader(g)
    val TT = TABS.filterKeys { it != "tor" && it != "seg" }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
        TT.forEach { (k, v) ->
            FilterChip(
                selected = vm.tt == k, onClick = { vm.tt = k }, label = { Text(v) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PC.Ac, selectedLabelColor = Color.White)
            )
        }
    }
    if (vm.tt == "res") TourOverview(g) else TabBody(vm.tt, Env(vm, hs, g.s))
}
