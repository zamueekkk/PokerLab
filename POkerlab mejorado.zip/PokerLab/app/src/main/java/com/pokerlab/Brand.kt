package com.pokerlab

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.padding
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// ===================== fondo y superficies =====================
fun Modifier.appBackground(): Modifier = this.drawBehind {
    drawRect(Brush.verticalGradient(listOf(Color(0xFF100A0D), PC.Bg)))
    drawRect(Brush.radialGradient(listOf(PC.Ac.copy(alpha = .17f), Color.Transparent), center = Offset(size.width * .12f, 0f), radius = size.width * 1.05f))
}

fun Modifier.glass(r: Dp = 16.dp): Modifier {
    val sh = RoundedCornerShape(r)
    return this.clip(sh).background(Brush.verticalGradient(listOf(PC.Sf1, PC.Sf2)), sh)
        .border(1.dp, Brush.verticalGradient(listOf(PC.Edge1, PC.Edge2)), sh)
}

// ===================== logo =====================
private fun spadePath(s: Float, ox: Float = 0f, oy: Float = 0f): Path = Path().apply {
    fun x(v: Float) = ox + v * s
    fun y(v: Float) = oy + v * s
    moveTo(x(54f), y(20f))
    cubicTo(x(54f), y(20f), x(20f), y(43f), x(20f), y(64f))
    cubicTo(x(20f), y(76f), x(29f), y(84f), x(40f), y(84f))
    cubicTo(x(46f), y(84f), x(50.5f), y(81.5f), x(53f), y(77.5f))
    lineTo(x(50f), y(94f)); lineTo(x(58f), y(94f)); lineTo(x(55f), y(77.5f))
    cubicTo(x(57.5f), y(81.5f), x(62f), y(84f), x(68f), y(84f))
    cubicTo(x(79f), y(84f), x(88f), y(76f), x(88f), y(64f))
    cubicTo(x(88f), y(43f), x(54f), y(20f), x(54f), y(20f))
    close()
}

@Composable
fun LogoMark(size: Dp = 40.dp) {
    Canvas(Modifier.size(size).clip(RoundedCornerShape(size * 0.26f))) {
        val s = this.size.width / 108f
        drawRect(Brush.radialGradient(listOf(Color(0xFF6B1730), Color(0xFF26101B), Color(0xFF0A0608)), center = Offset(38f * s, 26f * s), radius = 105f * s))
        for (k in 1..8) {
            val p = k * 12f * s
            drawLine(Color.White.copy(alpha = .07f), Offset(p, 0f), Offset(p, this.size.height), .5f * s + .3f)
            drawLine(Color.White.copy(alpha = .07f), Offset(0f, p), Offset(this.size.width, p), .5f * s + .3f)
        }
        withTransform({ scale(.78f, .78f, Offset(54f * s, 57f * s)) }) {
            drawCircle(Brush.radialGradient(listOf(Color(0x55FF3D63), Color.Transparent), center = Offset(54f * s, 56f * s), radius = 40f * s), 40f * s, Offset(54f * s, 56f * s))
            drawPath(spadePath(s), Brush.verticalGradient(listOf(Color(0xFFFF6B86), Color(0xFFE11D48), Color(0xFF9E0F32)), startY = 20f * s, endY = 94f * s))
            val line = Path().apply {
                moveTo(35f * s, 73f * s); lineTo(45f * s, 64f * s); lineTo(53f * s, 69f * s); lineTo(65f * s, 56f * s); lineTo(74f * s, 60f * s)
            }
            drawPath(line, Color.White, style = Stroke(2.6f * s, cap = StrokeCap.Round, join = StrokeJoin.Round))
            for ((px, py) in listOf(45f to 64f, 53f to 69f, 65f to 56f)) drawCircle(Color.White, 2.3f * s, Offset(px * s, py * s))
            drawCircle(Color.White, 3f * s, Offset(74f * s, 60f * s))
        }
    }
}

// ===================== iconos propios =====================
val TAB_ICON = mapOf(
    "res" to "dash", "seg" to "line", "niv" to "gauge", "per" to "radar", "pre" to "spade", "post" to "diamond",
    "ev" to "sigma", "solver" to "tree", "fug" to "drop", "rev" to "check", "tor" to "trophy", "ran" to "grid",
    "pos" to "table", "pat" to "bars", "man" to "star", "hnd" to "search", "riv" to "users", "gra" to "bars",
    "av" to "sliders", "cla" to "eye"
)

@Composable
fun TabIcon(kind: String, color: Color, size: Dp = 22.dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.width / 24f
        val st = Stroke(1.8f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun p(x: Float, y: Float) = Offset(x * s, y * s)
        fun poly(vararg pts: Float, close: Boolean = false) {
            val path = Path()
            for (i in 0 until pts.size / 2) { if (i == 0) path.moveTo(pts[0] * s, pts[1] * s) else path.lineTo(pts[2 * i] * s, pts[2 * i + 1] * s) }
            if (close) path.close()
            drawPath(path, color, style = st)
        }
        when (kind) {
            "dash" -> for ((x, y) in listOf(3f to 3f, 13f to 3f, 3f to 13f, 13f to 13f)) drawRoundRect(color, p(x, y), Size(8f * s, 8f * s), CornerRadius(2.2f * s), style = st)
            "spade" -> {
                val s2 = this.size.width / 86f
                drawPath(spadePath(s2, this.size.width / 2 - 54f * s2, this.size.height / 2 - 57f * s2), color)
            }
            "diamond" -> {
                val path = Path().apply { moveTo(12f * s, 2.5f * s); lineTo(20f * s, 12f * s); lineTo(12f * s, 21.5f * s); lineTo(4f * s, 12f * s); close() }
                drawPath(path, color.copy(alpha = .28f)); drawPath(path, color, style = st)
            }
            "grid" -> for (i in 0..2) for (j in 0..2) drawRoundRect(color.copy(alpha = .35f + .2f * (i + j)), p(3f + i * 6.5f, 3f + j * 6.5f), Size(4.6f * s, 4.6f * s), CornerRadius(1.2f * s))
            "tree" -> {
                drawLine(color, p(12f, 8f), p(6f, 15.6f), st.width, StrokeCap.Round); drawLine(color, p(12f, 8f), p(18f, 15.6f), st.width, StrokeCap.Round)
                drawCircle(color, 2.6f * s, p(12f, 5.5f)); drawCircle(color, 2.6f * s, p(6f, 18f)); drawCircle(color, 2.6f * s, p(18f, 18f))
            }
            "line" -> { poly(3f, 17f, 9f, 11f, 13f, 14.5f, 21f, 6f); drawCircle(color, 2f * s, p(21f, 6f)) }
            "gauge" -> {
                drawArc(color, 180f, 180f, false, p(3f, 7f), Size(18f * s, 18f * s), style = st)
                drawLine(color, p(12f, 16f), p(16.5f, 10.5f), st.width, StrokeCap.Round)
            }
            "radar" -> {
                val path = Path()
                for (k in 0..4) {
                    val a = (-90 + 72 * k) * PI / 180
                    val x = 12f + 9f * cos(a).toFloat(); val y = 12.8f + 9f * sin(a).toFloat()
                    if (k == 0) path.moveTo(x * s, y * s) else path.lineTo(x * s, y * s)
                }
                path.close(); drawPath(path, color.copy(alpha = .25f)); drawPath(path, color, style = st)
            }
            "bars" -> {
                drawRoundRect(color, p(4f, 12f), Size(4f * s, 8f * s), CornerRadius(1.2f * s)); drawRoundRect(color, p(10f, 5f), Size(4f * s, 15f * s), CornerRadius(1.2f * s))
                drawRoundRect(color, p(16f, 9f), Size(4f * s, 11f * s), CornerRadius(1.2f * s))
            }
            "sigma" -> poly(18f, 5f, 7f, 5f, 13f, 12f, 7f, 19f, 18f, 19f)
            "trophy" -> {
                poly(7f, 4f, 17f, 4f, 17f, 9f, 12f, 14f, 7f, 9f, close = true)
                drawLine(color, p(12f, 14f), p(12f, 19f), st.width, StrokeCap.Round); drawLine(color, p(8f, 20f), p(16f, 20f), st.width, StrokeCap.Round)
            }
            "table" -> {
                drawOval(color, p(2.5f, 6.5f), Size(19f * s, 11f * s), style = st)
                for ((x, y) in listOf(12f to 3.5f, 12f to 20.5f, 4f to 4.5f, 20f to 4.5f)) drawCircle(color, 1.4f * s, p(x, y))
            }
            "users" -> {
                drawCircle(color, 3f * s, p(9f, 8.5f), style = st); drawCircle(color, 2.4f * s, p(17.5f, 9.5f), style = st)
                drawArc(color, 180f, 180f, false, p(3f, 14f), Size(12f * s, 10f * s), style = st)
            }
            "search" -> { drawCircle(color, 6.5f * s, p(10.5f, 10.5f), style = st); drawLine(color, p(15.5f, 15.5f), p(21f, 21f), st.width, StrokeCap.Round) }
            "star" -> {
                val path = Path()
                for (k in 0 until 10) {
                    val r = if (k % 2 == 0) 9f else 4f
                    val a = (-90 + 36 * k) * PI / 180
                    val x = 12f + r * cos(a).toFloat(); val y = 12.8f + r * sin(a).toFloat()
                    if (k == 0) path.moveTo(x * s, y * s) else path.lineTo(x * s, y * s)
                }
                path.close(); drawPath(path, color.copy(alpha = .3f)); drawPath(path, color, style = st)
            }
            "check" -> poly(4f, 12.5f, 9.5f, 18f, 20f, 6.5f)
            "drop" -> {
                val path = Path().apply {
                    moveTo(12f * s, 3f * s); cubicTo(12f * s, 3f * s, 5f * s, 11f * s, 5f * s, 15f * s); cubicTo(5f * s, 19f * s, 8f * s, 21.5f * s, 12f * s, 21.5f * s)
                    cubicTo(16f * s, 21.5f * s, 19f * s, 19f * s, 19f * s, 15f * s); cubicTo(19f * s, 11f * s, 12f * s, 3f * s, 12f * s, 3f * s); close()
                }
                drawPath(path, color.copy(alpha = .25f)); drawPath(path, color, style = st)
            }
            "menu" -> { for (y in listOf(7f, 12f, 17f)) drawLine(color, p(4f, y), p(20f, y), st.width, StrokeCap.Round) }
            "plus" -> { drawLine(color, p(12f, 5f), p(12f, 19f), st.width, StrokeCap.Round); drawLine(color, p(5f, 12f), p(19f, 12f), st.width, StrokeCap.Round) }
            "more" -> for (y in listOf(5f, 12f, 19f)) drawCircle(color, 1.9f * s, p(12f, y))
            "sliders" -> {
                for ((y, x) in listOf(7f to 9f, 12f to 15f, 17f to 8f)) { drawLine(color, p(4f, y), p(20f, y), st.width, StrokeCap.Round); drawCircle(PC.P, 2.8f * s, p(x, y)); drawCircle(color, 2.8f * s, p(x, y), style = st) }
            }
            "eye" -> { drawOval(color, p(2.5f, 7f), Size(19f * s, 10f * s), style = st); drawCircle(color, 2.6f * s, p(12f, 12f)) }
            else -> drawCircle(color, 8f * s, p(12f, 12f), style = st)
        }
    }
}

@Composable
fun IconBtn(kind: String, onClick: () -> Unit, tint: Color = PC.Tx) {
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = .06f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { TabIcon(kind, tint, 20.dp) }
}

// ===================== botones y chips =====================
@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier.clip(RoundedCornerShape(14.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFFFF3D63), Color(0xFFB3123A))))
            .clickable(onClick = onClick).padding(horizontal = 22.dp, vertical = 13.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp) }
}

@Composable
fun GhostButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = .05f))
            .border(1.dp, PC.Edge1, RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = PC.Tx, fontWeight = FontWeight.Medium, fontSize = 14.sp) }
}

/** Sustituye a FilterChip de Material con un estilo de píldora propio. */
object FilterChipDefaults {
    fun filterChipColors(selectedContainerColor: Color = Color.Unspecified, selectedLabelColor: Color = Color.Unspecified): Any = Unit
}

@Composable
fun FilterChip(selected: Boolean, onClick: () -> Unit, label: @Composable () -> Unit, colors: Any? = null) {
    val bg by animateColorAsState(if (selected) PC.Ac else Color.White.copy(alpha = .05f), label = "chip")
    val sh = RoundedCornerShape(99.dp)
    Box(
        Modifier.clip(sh).background(bg).border(1.dp, if (selected) PC.Ac2.copy(alpha = .6f) else PC.Edge1, sh)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 7.dp)
    ) {
        CompositionLocalProvider(
            LocalContentColor provides (if (selected) Color.White else PC.Mu),
            LocalTextStyle provides TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Medium)
        ) { label() }
    }
}
