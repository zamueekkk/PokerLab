package com.pokerlab

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

val labelStyle = TextStyle(fontSize = 9.5.sp, color = PC.Mu, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
val valueStyle = TextStyle(fontSize = 10.sp, color = PC.Tx, fontWeight = FontWeight.SemiBold, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)

fun nice(a0: Double, b0: Double): Triple<Double, Double, List<Double>> {
    var a = a0; var b = b0
    if (a == b) { a -= 1; b += 1 }
    val r = (b - a) / 4
    val e = 10.0.pow(floor(log10(r)))
    val m = listOf(1.0, 2.0, 2.5, 5.0, 10.0).first { r <= it * e } * e
    val lo = floor(a / m + 1e-9) * m
    val hi = ceil(b / m - 1e-9) * m
    val t = ArrayList<Double>()
    var v = lo
    var guard = 0
    while (v <= hi + m / 1e3 && guard++ < 40) { t.add((v / m).roundToInt() * m); v += m }
    return Triple(lo, hi, t)
}

fun fmtTick(v: Double): String =
    if (v == floor(v) && abs(v) < 1e9) v.toLong().toString() else String.format(java.util.Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')

fun ds(y: List<Double>): List<Double> {
    if (y.size <= 700) return y
    return List(700) { i -> y[floor(i * (y.size - 1) / 699.0).toInt()] }
}

@Composable
fun rememberProg(key: Any? = Unit, ms: Int = 900): Float {
    val a = remember(key) { Animatable(0f) }
    LaunchedEffect(key) { a.animateTo(1f, tween(ms, easing = FastOutSlowInEasing)) }
    return a.value
}

/** align: 0 izquierda, 1 centro, 2 derecha */
fun DrawScope.txt(tm: TextMeasurer, s: String, x: Float, y: Float, style: TextStyle = labelStyle, align: Int = 0) {
    val r = tm.measure(s, style)
    val ox = when (align) { 1 -> x - r.size.width / 2f; 2 -> x - r.size.width; else -> x }
    drawText(r, topLeft = Offset(ox, y - r.size.height / 2f))
}

private class Geo(val pl: Float, val pr: Float, val pt: Float, val pb: Float)

private fun DrawScope.geo() = Geo(40.dp.toPx(), 10.dp.toPx(), 14.dp.toPx(), 22.dp.toPx())

private fun DrawScope.drawGrid(tm: TextMeasurer, lo: Double, hi: Double, ticks: List<Double>, g: Geo): (Double) -> Float {
    val h = size.height; val w = size.width
    val y: (Double) -> Float = { v -> (h - g.pb - ((v - lo) / (hi - lo) * (h - g.pb - g.pt))).toFloat() }
    for (v in ticks) {
        val yy = y(v)
        drawLine(if (v == 0.0) PC.Mu.copy(alpha = .6f) else PC.Ln.copy(alpha = .9f), Offset(g.pl, yy), Offset(w - g.pr, yy), 1f, pathEffect = if (v == 0.0) null else androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(5f, 7f)))
        txt(tm, fmtTick(v), g.pl - 6.dp.toPx(), yy, labelStyle, 2)
    }
    return y
}

@Composable
fun Legend(items: List<Pair<String, Color>>) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        items.forEach { (n, c) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).background(c, RoundedCornerShape(3.dp)))
                Spacer(Modifier.width(5.dp))
                Text(n, color = PC.Mu, fontSize = 12.sp)
            }
        }
    }
}

// ===================== línea con área =====================
@Composable
fun LineChart(y0: List<Double>, zero: Boolean = false, color: Color = PC.Ac, height: Dp = 190.dp) {
    if (y0.size < 2) { Muted("Pocas manos."); return }
    val y = remember(y0) { ds(y0) }
    val tm = rememberTextMeasurer()
    val prog = rememberProg(y0, 1100)
    Canvas(Modifier.fillMaxWidth().height(height)) {
        val g = geo()
        var a = y.min(); var b = y.max()
        if (zero) { a = min(a, 0.0); b = max(b, 0.0) }
        val (lo, hi, t) = nice(a, b)
        val Y = drawGrid(tm, lo, hi, t, g)
        val n = y.size
        val X = { i: Int -> g.pl + i.toFloat() / (n - 1) * (size.width - g.pl - g.pr) }
        val base = Y(max(lo, min(0.0, hi)))
        val line = Path(); val area = Path()
        line.moveTo(X(0), Y(y[0]))
        area.moveTo(X(0), base); area.lineTo(X(0), Y(y[0]))
        for (i in 1 until n) { line.lineTo(X(i), Y(y[i])); area.lineTo(X(i), Y(y[i])) }
        area.lineTo(X(n - 1), base); area.close()
        clipRect(right = g.pl + (size.width - g.pl) * prog) {
            drawPath(area, Brush.verticalGradient(listOf(color.copy(alpha = .4f), Color.Transparent), startY = 0f, endY = size.height))
            drawPath(line, color.copy(alpha = .2f), style = Stroke(7.dp.toPx(), join = StrokeJoin.Round, cap = StrokeCap.Round))
            drawPath(line, color, style = Stroke(2.2.dp.toPx(), join = StrokeJoin.Round, cap = StrokeCap.Round))
        }
        if (prog > .98f) {
            val L = y[n - 1]
            drawCircle(color.copy(alpha = .3f), 9.dp.toPx(), Offset(X(n - 1), Y(L)))
            drawCircle(color, 4.dp.toPx(), Offset(X(n - 1), Y(L)))
            drawCircle(PC.P, 2.dp.toPx(), Offset(X(n - 1), Y(L)))
            txt(tm, f1(L), size.width - g.pr - 6.dp.toPx(), Y(L) - 12.dp.toPx(), valueStyle, 2)
        }
    }
}

@Composable
fun MultiLine(series: List<List<Double>>, colors: List<Color>, legends: List<String>, height: Dp = 200.dp) {
    if (series.isEmpty() || series[0].size < 2) { Muted("Pocas manos."); return }
    val ss = remember(series) { series.map { ds(it) } }
    val tm = rememberTextMeasurer()
    val prog = rememberProg(series, 1100)
    Canvas(Modifier.fillMaxWidth().height(height)) {
        val g = geo()
        val all = ss.flatten()
        val (lo, hi, t) = nice(all.min(), all.max())
        val Y = drawGrid(tm, lo, hi, t, g)
        val m = ss[0].size
        clipRect(right = g.pl + (size.width - g.pl) * prog) {
            ss.forEachIndexed { k, yy ->
                val p = Path()
                yy.forEachIndexed { i, v ->
                    val x = g.pl + i.toFloat() / (m - 1) * (size.width - g.pl - g.pr)
                    if (i == 0) p.moveTo(x, Y(v)) else p.lineTo(x, Y(v))
                }
                drawPath(p, colors[k], style = Stroke(2.dp.toPx(), join = StrokeJoin.Round))
            }
        }
    }
    Spacer(Modifier.height(6.dp))
    Legend(legends.mapIndexed { i, l -> l to colors[i] })
}

// ===================== barras =====================
@Composable
fun BarChart(labels: List<String>, v: List<Double>, fixed: Boolean = false, height: Dp = 200.dp) {
    if (v.isEmpty()) return
    val tm = rememberTextMeasurer()
    val prog = rememberProg(v, 800)
    Canvas(Modifier.fillMaxWidth().height(height)) {
        val g = geo()
        val (lo, hi, t) = nice(min(0.0, v.min()), max(0.0, v.max()))
        val Y = drawGrid(tm, lo, hi, t, g)
        val n = labels.size
        val w = (size.width - g.pl - g.pr) / n
        val y0 = Y(0.0)
        for (i in 0 until n) {
            val x = v[i]; val yy = Y(x)
            val bx = g.pl + i * w + w * .16f; val bw = w * .68f
            val h = max(abs(yy - y0) * prog, 1f)
            val top = if (x >= 0) y0 - h else y0
            val c = if (fixed) PC.Ac2 else if (x >= 0) PC.Gd else PC.Bd
            val br = if (x >= 0) Brush.verticalGradient(listOf(c, c.copy(alpha = .45f)), startY = top, endY = top + h) else Brush.verticalGradient(listOf(c.copy(alpha = .45f), c), startY = top, endY = top + h)
            drawRoundRect(br, Offset(bx, top), Size(bw, h), CornerRadius(4.dp.toPx()))
            if (n <= 14 && prog > .9f) txt(tm, f1(x), bx + bw / 2, if (x >= 0) top - 8.dp.toPx() else top + h + 9.dp.toPx(), valueStyle, 1)
            if (n <= 12 || i % ceil(n / 12.0).toInt() == 0) txt(tm, labels[i], bx + bw / 2, size.height - 8.dp.toPx(), labelStyle, 1)
        }
    }
}

@Composable
fun BarChart2(labels: List<String>, a: List<Double>, b: List<Double>, na: String = "VPIP %", nb: String = "PFR %") {
    if (labels.isEmpty()) return
    val tm = rememberTextMeasurer()
    val prog = rememberProg(a, 800)
    Canvas(Modifier.fillMaxWidth().height(200.dp)) {
        val g = geo()
        val (lo, hi, t) = nice(0.0, max(1.0, max(a.max(), b.max())))
        val Y = drawGrid(tm, lo, hi, t, g)
        val n = labels.size
        val w = (size.width - g.pl - g.pr) / n
        val y0 = Y(0.0)
        for (i in 0 until n) {
            val bx = g.pl + i * w + w * .1f; val bw = w * .38f
            listOf(a to PC.Ac, b to PC.Gr2).forEachIndexed { k, (s, c) ->
                val yy = Y(s[i]); val h = max((y0 - yy) * prog, 1f)
                val x = bx + k * (bw + 3.dp.toPx())
                drawRoundRect(Brush.verticalGradient(listOf(c, c.copy(alpha = .45f)), startY = y0 - h, endY = y0), Offset(x, y0 - h), Size(bw, h), CornerRadius(4.dp.toPx()))
                if (n <= 12 && prog > .9f) txt(tm, s[i].roundToInt().toString(), x + bw / 2, yy - 8.dp.toPx(), valueStyle, 1)
            }
            txt(tm, labels[i], g.pl + i * w + w / 2, size.height - 8.dp.toPx(), labelStyle, 1)
        }
    }
    Spacer(Modifier.height(6.dp))
    Legend(listOf(na to PC.Ac, nb to PC.Gr2))
}

@Composable
fun StackedBars(labels: List<String>, series: List<Triple<String, List<Double>, Color>>) {
    val tm = rememberTextMeasurer()
    val prog = rememberProg(labels, 800)
    Canvas(Modifier.fillMaxWidth().height(210.dp)) {
        val g = geo()
        val Y = drawGrid(tm, 0.0, 100.0, listOf(0.0, 25.0, 50.0, 75.0, 100.0), g)
        val n = labels.size
        val w = (size.width - g.pl - g.pr) / n
        val H0 = size.height - g.pb - g.pt
        for (i in 0 until n) {
            var acc = 0f
            val bx = g.pl + i * w + w * .18f; val bw = w * .64f
            series.forEach { (_, v, c) ->
                val h = (v[i] / 100 * H0).toFloat() * prog
                val y = Y(0.0) - acc - h
                acc += h
                drawRect(c, Offset(bx, y), Size(bw, max(h, 0f)))
                if (h > 16.dp.toPx()) txt(tm, v[i].roundToInt().toString(), bx + bw / 2, y + h / 2, TextStyle(fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.SemiBold), 1)
            }
            txt(tm, labels[i], bx + bw / 2, size.height - 8.dp.toPx(), labelStyle, 1)
        }
    }
    Spacer(Modifier.height(6.dp))
    Legend(series.map { it.first to it.third })
}

// ===================== donut =====================
@Composable
fun Donut(items: List<Triple<String, Double, Color>>, top: String, bottom: String) {
    val tot = items.sumOf { it.second }.let { if (it == 0.0) 1.0 else it }
    val tm = rememberTextMeasurer()
    val prog = rememberProg(items, 1000)
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Canvas(Modifier.size(150.dp)) {
            val sw = 20.dp.toPx()
            val d = size.minDimension - sw
            val tl = Offset(sw / 2, sw / 2)
            drawArc(PC.P2, 0f, 360f, false, tl, Size(d, d), style = Stroke(sw))
            var start = -90f
            items.forEach { (_, v, c) ->
                val sweep = (v / tot * 360f).toFloat() * prog
                val gapA = if (items.count { it.second > 0 } > 1) 2.5f else 0f
                if (sweep > gapA) drawArc(c, start + gapA / 2, sweep - gapA, false, tl, Size(d, d), style = Stroke(sw))
                start += (v / tot * 360f).toFloat()
            }
            txt(tm, top, size.width / 2, size.height / 2 - 8.dp.toPx(), TextStyle(fontSize = 20.sp, color = PC.Tx, fontWeight = FontWeight.Bold), 1)
            txt(tm, bottom, size.width / 2, size.height / 2 + 12.dp.toPx(), labelStyle, 1)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items.forEach { (l, v, c) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).background(c, RoundedCornerShape(3.dp)))
                    Spacer(Modifier.width(6.dp))
                    Text(l, color = PC.Tx, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text(f1(100 * v / tot) + "%", color = PC.Mu, fontSize = 12.sp)
                }
            }
        }
    }
}

// ===================== radar =====================
@Composable
fun Radar(labels: List<String>, series: List<Triple<List<Double>, Color, String>>) {
    val tm = rememberTextMeasurer()
    val prog = rememberProg(series, 1000)
    Canvas(Modifier.fillMaxWidth().height(250.dp)) {
        val n = labels.size
        val cx = size.width / 2; val cy = size.height / 2 + 4.dp.toPx()
        val R = min(size.width / 2 - 44.dp.toPx(), size.height / 2 - 26.dp.toPx())
        fun P(i: Int, v: Double, rr: Float = R): Offset {
            val a = -PI / 2 + i * 2 * PI / n
            return Offset((cx + cos(a) * rr * v / 100).toFloat(), (cy + sin(a) * rr * v / 100).toFloat())
        }
        for (r in listOf(25.0, 50.0, 75.0, 100.0)) {
            val p = Path()
            for (i in 0 until n) { val o = P(i, r); if (i == 0) p.moveTo(o.x, o.y) else p.lineTo(o.x, o.y) }
            p.close()
            drawPath(p, PC.Ln, style = Stroke(1f))
        }
        labels.forEachIndexed { i, t ->
            val o = P(i, 100.0)
            drawLine(PC.Ln, Offset(cx, cy), o, 1f)
            val tp = P(i, 100.0, R + 20.dp.toPx())
            txt(tm, t, tp.x, tp.y, labelStyle, 1)
        }
        series.forEach { (v, c, _) ->
            val p = Path()
            v.forEachIndexed { i, x -> val o = P(i, max(x, 3.0) * prog); if (i == 0) p.moveTo(o.x, o.y) else p.lineTo(o.x, o.y) }
            p.close()
            drawPath(p, c.copy(alpha = .22f))
            drawPath(p, c, style = Stroke(2.dp.toPx(), join = StrokeJoin.Round))
            v.forEachIndexed { i, x -> drawCircle(c, 3.5.dp.toPx(), P(i, max(x, 3.0) * prog)) }
        }
    }
    if (series.size > 1 || series[0].third.isNotEmpty()) Legend(series.map { it.third to it.second })
}

// ===================== dispersión =====================
@Composable
fun Scatter(p: List<Triple<Double, Double, String>>, xl: String) {
    if (p.isEmpty()) return
    val tm = rememberTextMeasurer()
    val prog = rememberProg(p, 800)
    Canvas(Modifier.fillMaxWidth().height(220.dp)) {
        val g = geo()
        val (x0, x1, xt) = nice(0.0, p.maxOf { it.first })
        val (y0, y1, yt) = nice(min(0.0, p.minOf { it.second }), max(0.0, p.maxOf { it.second }))
        val Y = drawGrid(tm, y0, y1, yt, g)
        val X = { v: Double -> (g.pl + (v - x0) / (x1 - x0) * (size.width - g.pl - g.pr)).toFloat() }
        xt.forEach { txt(tm, fmtTick(it), X(it), size.height - 8.dp.toPx(), labelStyle, 1) }
        p.forEach { (x, y, _) ->
            val c = if (y >= 0) PC.Gd else PC.Bd
            drawCircle(c.copy(alpha = .75f), 6.dp.toPx() * prog, Offset(X(x), Y(y)))
        }
        txt(tm, "$xl →", size.width - g.pr, size.height - 26.dp.toPx(), labelStyle, 2)
    }
}

// ===================== sparkline =====================
@Composable
fun Spark(y0: List<Double>) {
    if (y0.size < 3) return
    val y = remember(y0) { ds(y0) }
    Canvas(Modifier.fillMaxWidth().height(24.dp)) {
        val a = y.min(); val r = (y.max() - a).let { if (it == 0.0) 1.0 else it }
        val n = y.size
        val p = Path()
        y.forEachIndexed { i, v ->
            val x = i.toFloat() / (n - 1) * size.width
            val yy = (size.height - 2.dp.toPx() - ((v - a) / r * (size.height - 4.dp.toPx()))).toFloat()
            if (i == 0) p.moveTo(x, yy) else p.lineTo(x, yy)
        }
        drawPath(p, PC.Ac, style = Stroke(1.6.dp.toPx(), join = StrokeJoin.Round))
    }
}

// ===================== gauge =====================
@Composable
fun GaugeArc(value: Double, big: String, sub: String) {
    val prog = rememberProg(value, 1400)
    val tm = rememberTextMeasurer()
    Canvas(Modifier.fillMaxWidth().height(170.dp)) {
        val sw = 14.dp.toPx()
        val d = min(size.width - 2 * sw - 40.dp.toPx(), (size.height - sw - 30.dp.toPx()) * 2)
        val tl = Offset((size.width - d) / 2, sw / 2 + 22.dp.toPx())
        drawArc(PC.Ln, 180f, 180f, false, tl, Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
        val sweepV = (180f * (value / 100).toFloat().coerceIn(0f, 1f)) * prog
        drawArc(PC.Ac.copy(alpha = .25f), 180f, sweepV, false, tl, Size(d, d), style = Stroke(sw + 10.dp.toPx(), cap = StrokeCap.Round))
        drawArc(Brush.sweepGradient(listOf(PC.AcDeep, PC.Ac2, PC.Ac2), center = Offset(tl.x + d / 2, tl.y + d / 2)), 180f, sweepV, false, tl, Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
        for (k in 0..20) {
            val a = (PI + PI * k / 20.0)
            val r1 = d / 2 + sw / 2 + 5.dp.toPx(); val r2 = r1 + (if (k % 5 == 0) 7.dp.toPx() else 3.dp.toPx())
            val cxx = tl.x + d / 2; val cyy = tl.y + d / 2
            drawLine(PC.Mu.copy(alpha = .5f), Offset((cxx + cos(a) * r1).toFloat(), (cyy + sin(a) * r1).toFloat()), Offset((cxx + cos(a) * r2).toFloat(), (cyy + sin(a) * r2).toFloat()), 1.dp.toPx())
        }
        txt(tm, big, size.width / 2, tl.y + d / 2 - 14.dp.toPx(), TextStyle(fontSize = 38.sp, color = PC.Tx, fontWeight = FontWeight.SemiBold), 1)
        txt(tm, sub, size.width / 2, tl.y + d / 2 + 14.dp.toPx(), labelStyle, 1)
    }
}

// ===================== mapa de la mesa =====================
@Composable
fun TableMap(r: List<Pair<String, Agg>>) {
    val tm = rememberTextMeasurer()
    val prog = rememberProg(r.size, 900)
    val order = listOf("BTN", "SB", "BB", "UTG", "MP", "HJ", "CO")
    val ms = r.map { B(it.second).m }
    val mxa = max(10.0, ms.maxOf { abs(it) })
    Canvas(Modifier.fillMaxWidth().height(250.dp)) {
        val cx = size.width / 2; val cy = size.height / 2
        val rx = size.width / 2 - 40.dp.toPx(); val ry = size.height / 2 - 36.dp.toPx()
        drawOval(Brush.radialGradient(listOf(PC.Felt1, PC.Felt2), center = Offset(cx, cy), radius = rx), Offset(cx - rx, cy - ry), Size(rx * 2, ry * 2))
        drawOval(PC.Rail, Offset(cx - rx, cy - ry), Size(rx * 2, ry * 2), style = Stroke(8.dp.toPx()))
        txt(tm, "♠", cx, cy, TextStyle(fontSize = 44.sp, color = PC.Ac.copy(alpha = .22f)), 1)
        order.forEachIndexed { i, p ->
            val a = PI / 2 + i * 2 * PI / 7
            val x = (cx + rx * cos(a)).toFloat(); val y = (cy + ry * sin(a)).toFloat()
            val e = r.first { it.first == p }.second
            val m = B(e).m
            val c = if (m >= 0) PC.Gd else PC.Bd
            val o = if (e.n > 0) (.25f + .75f * min(1.0, abs(m) / mxa).toFloat()) else .1f
            drawCircle(c.copy(alpha = o), 27.dp.toPx() * prog, Offset(x, y))
            drawCircle(c, 27.dp.toPx() * prog, Offset(x, y), style = Stroke(2.dp.toPx()))
            txt(tm, p, x, y - 6.dp.toPx(), valueStyle, 1)
            txt(tm, if (e.n > 0) f1(m) else "–", x, y + 8.dp.toPx(), valueStyle.copy(fontSize = 9.sp), 1)
            if (p == "BTN") {
                drawCircle(Color.White, 8.dp.toPx(), Offset(x + 30.dp.toPx(), y - 14.dp.toPx()))
                txt(tm, "D", x + 30.dp.toPx(), y - 14.dp.toPx(), TextStyle(fontSize = 10.sp, color = PC.P, fontWeight = FontWeight.Bold), 1)
            }
        }
    }
}

// ===================== calendario y día/hora =====================
@Composable
fun CalendarHeat(hs: List<Hand>) {
    if (hs.isEmpty()) return
    val D = remember(hs) {
        val m = HashMap<Long, DoubleArray>()
        for (h in hs) { val o = m.getOrPut(h.day) { DoubleArray(2) }; o[0] += h.nb; o[1] += 1.0 }
        m
    }
    val end = hs.last().day
    val first = end - 181
    val start = first - ((first + 3) % 7 + 7) % 7 // lunes: epochDay 0 fue jueves
    val days = ((end - start) + 1).toInt()
    val mx = D.values.maxOfOrNull { abs(it[0]) }?.let { if (it == 0.0) 1.0 else it } ?: 1.0
    val cols = (days + 6) / 7
    Box(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
        Canvas(Modifier.width((cols * 17).dp).height((7 * 17).dp)) {
            val cell = 14.dp.toPx(); val gap = 3.dp.toPx()
            for (i in 0 until days) {
                val d = start + i
                val col = i / 7; val row = i % 7
                val o = D[d]
                val c = if (o != null) lerp(PC.P2, if (o[0] >= 0) PC.Gd else PC.Bd, (.18f + .8f * min(1.0, abs(o[0]) / mx).toFloat())) else PC.P2
                drawRoundRect(c, Offset(col * (cell + gap), row * (cell + gap)), Size(cell, cell), CornerRadius(3.dp.toPx()))
            }
        }
    }
}

@Composable
fun DayHourHeat(hs: List<Hand>) {
    val M = remember(hs) {
        val m = Array(7) { Array(24) { DoubleArray(2) } }
        for (h in hs) { val o = m[h.dow][h.hour]; o[0] += 1.0; o[1] += h.nb }
        m
    }
    val tm = rememberTextMeasurer()
    val DN = listOf("Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom")
    var mx = 1.0
    for (r in M) for (o in r) if (o[0] >= 15) mx = max(mx, abs(o[1] / o[0] * 100))
    Canvas(Modifier.fillMaxWidth().height(170.dp)) {
        val lw = 32.dp.toPx(); val top = 14.dp.toPx()
        val cell = (size.width - lw) / 24f
        for (i in 0 until 24) if (i % 3 == 0) txt(tm, i.toString(), lw + i * cell + cell / 2, 6.dp.toPx(), labelStyle, 1)
        for (r in 0 until 7) {
            txt(tm, DN[r], 0f, top + r * (cell + 2.dp.toPx()) + cell / 2, labelStyle, 0)
            for (i in 0 until 24) {
                val o = M[r][i]
                val v = if (o[0] >= 15) o[1] / o[0] * 100 else null
                val c = if (v == null) (if (o[0] > 0) PC.Ln else PC.P2)
                else lerp(PC.P2, if (v >= 0) PC.Gd else PC.Bd, (.2f + .75f * min(1.0, abs(v) / mx).toFloat()))
                drawRoundRect(c, Offset(lw + i * cell + 1.dp.toPx(), top + r * (cell + 2.dp.toPx())), Size(cell - 2.dp.toPx(), cell), CornerRadius(3.dp.toPx()))
            }
        }
    }
}
