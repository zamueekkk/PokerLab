package com.pokerlab

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

@Composable
fun Expand(title: String, content: @Composable () -> Unit) {
    var o by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(PC.P2).padding(12.dp)) {
        Text((if (o) "▾ " else "▸ ") + title, color = PC.Tx, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().clickable { o = !o })
        if (o) { Spacer(Modifier.height(8.dp)); content() }
    }
}

@Composable
fun HandExpand(h: Hand) {
    Expand(h.cards?.joinToString(" ") { (if (it[0] == 'T') "10" else it[0].toString()) + (SUIT[it[1]] ?: "") } + " · ${h.pos} · ${f1(h.nb)} bb · ${h.tn.take(24)}" + (if (h.ai == 1) " · ALL-IN" else "")) {
        HandDetail(h)
        Expand("Historial completo") { Text(h.raw, color = PC.Mu, fontSize = 10.sp, lineHeight = 13.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, modifier = Modifier.horizontalScroll(rememberScrollState())) }
    }
}

// ===================== FUGAS =====================
private class FG(val p: String, val l: String) { var n = 0; var t = 0.0; var q = 0.0 }

@Composable
fun TabFug(e: Env) {
    val hs = e.hs; val s = e.s
    fun dl(h: Hand): String { val d = h.stack / h.bb; return if (d < 10) "<10 bb" else if (d < 20) "10–20 bb" else if (d < 40) "20–40 bb" else "40+ bb" }
    fun zn(h: Hand) = if (h.M >= 20) "Verde" else if (h.M >= 10) "Amarilla" else if (h.M >= 6) "Naranja" else if (h.M >= 1) "Roja" else "Muerta"
    val PART: List<Pair<String, (Hand) -> String?>> = listOf(
        "Posición" to { h -> h.pos },
        "Tipo de bote" to { h -> if (h.saw == 1) listOf("Limpeado", "SRP", "3-bet pot", "4-bet+ pot")[min(h.pt, 3)] else null },
        "Rol" to { h -> if (h.saw == 1) (if (h.agg == 1) "Agresor preflop" else "Defensor/caller") else null },
        "Posición postflop" to { h -> if (h.ip == null) null else if (h.ip == true) "En posición" else "Fuera de posición" },
        "Rivales en flop" to { h -> if (h.saw == 1) (if (h.nOpp >= 3) "3+ rivales" else h.nOpp.toString() + (if (h.nOpp > 1) " rivales" else " rival")) else null },
        "Profundidad" to { h -> dl(h) },
        "Zona M" to { h -> zn(h) },
        "Jugadores en mesa" to { h -> "${h.n} jugadores" },
        "Showdown" to { h -> if (h.saw == 1) (if (h.sd == 1) "Con showdown" else "Sin showdown") else null },
        "All-in" to { h -> if (h.ai == 1) "All-in de Hero" else null },
        "Franja horaria" to { h -> listOf("00–06", "06–12", "12–18", "18–24")[min(3, h.hour / 6)] },
        "Con alerta heurística" to { h -> if (flags(h).isNotEmpty()) "Con alerta" else null }
    )
    val M = remember(hs) {
        val m = LinkedHashMap<String, FG>()
        for ((pn, fn) in PART) for (h in hs) {
            val l = fn(h) ?: continue
            val o = m.getOrPut("$pn|$l") { FG(pn, l) }
            o.n++; o.t += h.nb; o.q += h.nb * h.nb
        }
        m
    }
    class Lg(val g: FG, val m: Double, val ci: Double)
    val Lgs = M.values.filter { it.n >= 40 }.map { o ->
        val m = o.t / o.n; val v = max(0.0, (o.q - o.n * m * m) / (o.n - 1))
        Lg(o, m * 100, 196 * sqrt(v / o.n))
    }
    val W = Lgs.sortedBy { it.g.t }.take(12); val Bt = Lgs.sortedByDescending { it.g.t }.take(8)
    fun sg(o: Lg): Any = if (o.m + o.ci < 0) Tone("Fuga probable", -1) else if (o.m < 0) "Posible fuga" else if (o.m - o.ci > 0) Tone("Fortaleza probable", 1) else "Positivo"
    fun rw(o: Lg) = listOf<Any>(o.g.p, o.g.l, o.g.n, nbc(o.g.t), nbc(o.m), f1(o.ci), sg(o))
    val hd = listOf("Dimensión", "Grupo", "Manos", "Neto bb", "bb/100", "±IC", "Señal")
    val wd = listOf(130, 130, 60, 70, 70, 60, 130)
    val FS = listOf("pre", "flop", "turn", "river", "end").map { z ->
        val t = hs.filter { it.fs == z }; val u = S(t)
        listOf<Any>(if (z == "end") "Sin fold" else "Fold $z", t.size, pc(t.size.toDouble(), hs.size.toDouble()), nbc(u.nb), nbc(if (t.isNotEmpty()) u.nb / t.size else 0.0))
    }
    val bs = listOf("SB", "BB").map { p ->
        val t = hs.filter { it.pos == p && it.fs == "pre" }; val u = S(t)
        listOf<Any>("$p foldeando preflop", t.size, nbc(u.nb), nbc(if (t.isNotEmpty()) u.nb / t.size else 0.0))
    }
    val bleed = hs.filter { it.fs == "pre" && (it.pos == "SB" || it.pos == "BB") }.sumOf { it.nb }
    Note("Esta página agrupa tus manos por muchas dimensiones y marca dónde pierdes (o ganas) más. Los grupos se solapan y no son causales: úsalos para decidir qué manos revisar.")
    Sec("Mayores fugas (bb totales)") { Table(hd, W.map { rw(it) }, wd) }
    Sec("Mayores fortalezas") { Table(hd, Bt.map { rw(it) }, wd) }
    Sec("Dónde se cierra la mano") { Table(listOf("Cierre", "Manos", "% de manos", "Neto bb", "bb/mano"), FS, listOf(110, 70, 90, 80, 80)) }
    Sec("Costo estructural de las ciegas") {
        Table(listOf("Caso", "Manos", "Neto bb", "bb/mano"), bs, listOf(180, 70, 80, 80))
        Muted("Las ciegas y antes que regalas foldeando suman ${f1(bleed)} bb (${f1(100 * bleed / max(s.n, 1))} bb/100 sobre todas tus manos). Es inevitable: lo que importa es que lo recuperes con steal y defensa (ver Preflop).")
    }
    Sec("Alertas heurísticas") { Muted("${hs.count { flags(it).isNotEmpty() }} manos con alerta (ver pestaña Revisión).") }
}

// ===================== TORNEOS =====================
@Composable
fun TabTor(e: Env) {
    val hs = e.hs
    val T = remember(hs) { tours(hs) }
    val df = remember { java.text.DateFormat.getDateInstance(java.text.DateFormat.SHORT) }
    Sec("Manos jugadas contra resultado por torneo") { Scatter(T.map { Triple(it.hs.size.toDouble(), it.s.nb, it.name.take(30)) }, "manos jugadas") }
    Sec("Todos los torneos (toca uno para abrirlo)") {
        Table(
            listOf("Torneo", "Fecha", "Manos", "Min", "Stack ini→fin", "Pico bb", "VPIP", "PFR", "Neto bb", "Estado"),
            T.map { t ->
                listOf<Any>(t.name.take(34), df.format(java.util.Date(t.t0)), t.hs.size, t.dur.toInt(), "${Math.round(t.s0)}→${Math.round(t.end)}", f1(t.peak),
                    q(t.s, "vpip_x", "vpip_o", 0), q(t.s, "pfr_x", "pfr_o", 0), nbc(t.s.nb), if (t.bust) "Eliminado" else "Sin eliminación")
            },
            listOf(200, 80, 60, 50, 110, 70, 60, 60, 80, 120), onRow = { e.vm.tour = T[it].id }
        )
    }
}

// ===================== PREFLOP · HISTORIAL (rango) =====================
private class GCell(var n: Int = 0, var v: Int = 0, var r: Int = 0, var t: Double = 0.0, var ro: Int = 0, var rf: Int = 0, var sd: Int = 0, var w: Int = 0)

private fun gcells(hs: List<Hand>, pos: String?): Map<String, GCell> {
    val m = HashMap<String, GCell>()
    for (h in hs) {
        val c = h.cards ?: continue
        if (pos != null && h.pos != pos) continue
        val o = m.getOrPut(hk(c)) { GCell() }
        o.n++; o.v += h.vpip; o.r += h.pfr; o.t += h.nb; o.ro += h.rfiO; o.rf += h.rfi; o.sd += h.sd; o.w += h.wsd
    }
    return m
}

private fun rcell(o: GCell?, z: String, gm: String, mx: Int, mn: Double, labels: Boolean = true): RCell {
    if (o == null) return RCell(bg = PC.Ln.copy(alpha = .4f), label = if (labels) z else "", txt = PC.Mu.copy(alpha = .5f))
    val v: Double; val al: Double; var col = PC.Ac; val lab: String
    when (gm) {
        "v", "r" -> { v = (if (gm == "v") o.v else o.r).toDouble() / o.n; al = v; lab = (v * 100).toInt().toString() + "%" }
        "f" -> { v = if (o.ro > 0) o.rf.toDouble() / o.ro else 0.0; al = v; lab = if (o.ro > 0) (v * 100).toInt().toString() + "%" else "–" }
        "n" -> { v = o.n.toDouble(); al = o.n.toDouble() / max(mx, 1); lab = o.n.toString() }
        else -> { v = o.t / o.n; al = if (mn > 0) abs(v) / mn else 0.0; lab = f1(v); col = if (v >= 0) Color(0xFF16A34A) else Color(0xFFDC2626) }
    }
    return RCell(
        bg = col.copy(alpha = ((8 + 85 * min(al, 1.0)) / 100).toFloat()), label = if (labels) z else "", sub = if (labels) lab else "",
        txt = if (al > .5) Color.White else PC.Tx, hot = al > .6
    )
}

@Composable
fun TabRan(e: Env) {
    val vm = e.vm; val hs = e.hs
    val gp = vm.gp; val gm = vm.gm
    val M = remember(hs, gp) { gcells(hs, if (gp == "all") null else gp) }
    val MP = remember(hs) { PO.associateWith { gcells(hs, it) } }
    var selZ by remember { mutableStateOf<String?>(null) }
    var mx = 0; var mn = 0.0
    for (o in M.values) { mx = max(mx, o.n); mn = max(mn, abs(o.t / o.n)) }
    Note("Mapa preflop basado en tu historial: con qué manos entraste, subiste o ganaste desde cada posición. No es una tabla GTO ni una recomendación del solver; es más fiable cuanto mayor sea la muestra por clase.")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
        Drop("Posición: ", listOf("all" to "Todas") + PO.map { it to it }, gp) { vm.gp = it }
        Drop("Métrica: ", listOf("v" to "% jugada (VPIP)", "r" to "% subida (PFR)", "f" to "% open (RFI)", "n" to "Veces repartida", "t" to "Neto bb por mano"), gm) { vm.gm = it }
    }
    Sec("Matriz de manos · " + (if (gp == "all") "todas las posiciones" else gp)) {
        RangeGrid(cell = { z -> rcell(M[z], z, gm, mx, mn) }, selected = selZ, onTap = { selZ = if (selZ == it) null else it })
        Spacer(Modifier.height(8.dp))
        when (gm) {
            "t" -> Legend(listOf("Pierde bb" to Color(0xFFDC2626), "Gana bb" to Color(0xFF16A34A)))
            "n" -> GradientLegend("pocas veces", "muchas veces", PC.Ac)
            else -> GradientLegend("0%", "100%", PC.Ac)
        }
        Muted("Pares en la diagonal · suited arriba · offsuit abajo. Borde rojo = celdas con valor alto.")
        Spacer(Modifier.height(8.dp))
        val z = selZ; val o = if (z != null) M[z] else null
        if (z != null && o != null) {
            val t = M.values.sumOf { it.n }
            val ex = (if (z.length == 2) 6 else if (z[2] == 's') 4 else 12) / 13.26
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(PC.P2).padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(z, fontWeight = FontWeight.Bold, color = PC.Tx, fontSize = 16.sp)
                Muted("${o.n} manos = ${f2(100.0 * o.n / t)}% (esperado ${f2(ex)}%)", 13)
                Muted("VPIP ${pc(o.v.toDouble(), o.n.toDouble())} · PFR ${pc(o.r.toDouble(), o.n.toDouble())} · RFI ${pc(o.rf.toDouble(), o.ro.toDouble())} (${o.ro} ops.)", 13)
                Muted("Showdown ${pc(o.sd.toDouble(), o.n.toDouble())} · gana SD ${pc(o.w.toDouble(), o.sd.toDouble())}", 13)
                Muted("Neto ${f1(o.t)} bb · ${f2(o.t / o.n)} bb/mano", 13)
            }
        } else Muted("Toca una celda para ver su detalle técnico.")
    }
    Sec("Comparar posiciones (misma métrica)") {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            PO.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { p ->
                        val mp = MP[p]!!
                        var pmx = 0; var pmn = 0.0
                        for (o in mp.values) { pmx = max(pmx, o.n); pmn = max(pmn, abs(o.t / o.n)) }
                        Column(Modifier.weight(1f)) {
                            Text(p + " · " + mp.values.sumOf { it.n } + " manos", color = PC.Tx, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(4.dp))
                            MiniGrid(cell = { z -> rcell(mp[z], z, gm, pmx, pmn, false) })
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
    Sec("Tabla de rango (12 clases más repartidas)") {
        val A = M.entries.sortedByDescending { it.value.n }.take(12)
        Table(
            listOf("Mano", "N", "VPIP", "PFR", "RFI", "SD", "Gana SD", "Neto bb"),
            A.map { (z, o) -> listOf<Any>(z, o.n, pc(o.v.toDouble(), o.n.toDouble()), pc(o.r.toDouble(), o.n.toDouble()), pc(o.rf.toDouble(), o.ro.toDouble()), pc(o.sd.toDouble(), o.n.toDouble()), pc(o.w.toDouble(), o.sd.toDouble()), nbc(o.t)) },
            onRow = { selZ = A[it].key }
        )
    }
}

// ===================== POSICIONES =====================
@Composable
fun TabPos(e: Env) {
    val hs = e.hs
    val R_ = PO.map { p -> p to S(hs.filter { it.pos == p }) }
    Sec("Mesa: resultado por posición") { TableMap(R_) ; Muted("Verde = ganas, rojo = pierdes (bb/100); la intensidad marca la magnitud.") }
    Sec("bb/100 por posición") { BarChart(PO, R_.map { B(it.second).m }) }
    Sec("Estadísticas por posición") {
        Table(
            listOf("Pos", "Manos", "VPIP", "PFR", "RFI", "Limp", "Steal", "3-bet", "Fold a open", "C-bet", "WTSD", "W\$SD", "bb/100", "±IC95"),
            R_.map { (p, s) ->
                val b = B(s)
                listOf<Any>(p, s.n, q(s, "vpip_x", "vpip_o"), q(s, "pfr_x", "pfr_o"), q(s, "rfi_x", "rfi_o"), q(s, "lim_x", "lim_o"), q(s, "stl_x", "stl_o"), q(s, "t3_x", "t3_o"), q(s, "ffo_x", "ffo_o"), q(s, "cb_x", "cb_o"), q(s, "sd", "saw"), q(s, "wsd", "sd"), nbc(b.m), f1(b.ci))
            }, PO.let { listOf(60, 70, 70, 70, 70, 70, 70, 70, 90, 70, 70, 70, 70, 70) }
        )
    }
    HandSec("Mejor mano de cada posición", PO.mapNotNull { p -> byNb(hs.filter { it.pos == p }, 1, true).firstOrNull() })
    HandSec("Peor mano de cada posición", PO.mapNotNull { p -> byNb(hs.filter { it.pos == p }, 1, false).firstOrNull() })
}

// ===================== PATRONES =====================
@Composable
fun TabPat(e: Env) {
    val hs = e.hs; val s = e.s
    val x = remember(hs, e.vm.evVer) { ctx(hs, s) }
    val b = B(s); val R_ = rows(s, x); val I = ArrayList<String>()
    val out = R_.filter { r ->
        r.ok && r.e.w > 0 && (if (r.l != null && r.h != null) (r.h < r.e.lo || r.l > r.e.hi) else (r.v!! < r.e.lo || r.v > r.e.hi))
    }.sortedByDescending { it.e.w * (100 - it.sc!!) }
    for (r in out.take(12)) I.add("${r.e.name}: ${fv(r)} (ideal ${fmtB(r.e.lo)}–${fmtB(r.e.hi)}${unitOf(r.e)}, muestra ${r.z.toInt()}). " + (if (r.v!! < r.e.lo) r.e.tl else r.e.th))
    val d = dep(hs).filter { it.s.n >= 100 }
    val ps = PO.map { p -> p to S(hs.filter { it.pos == p }) }.filter { it.second.n >= 150 }
    if (d.isNotEmpty()) { val w = d.minByOrNull { B(it.s).m }!!; I.add("Tu peor profundidad: ${w.l} (${f1(B(w.s).m)} bb/100 en ${w.s.n} manos).") }
    if (ps.isNotEmpty()) { val w = ps.minByOrNull { B(it.second).m }!!; I.add("Tu peor posición: ${w.first} (${f1(B(w.second).m)} bb/100).") }
    I.add(if (b.m - b.ci > 0) "Resultado ${f1(b.m)} bb/100 con IC95% por encima de 0: ganancia estadísticamente probable." else if (b.m + b.ci < 0) "Resultado ${f1(b.m)} bb/100 con IC95% por debajo de 0: pérdida estadísticamente probable." else "El IC95% (±${f1(b.ci)}) incluye 0: la muestra no basta para concluir si ganas o pierdes.")
    class MH(val q: String) { var n = 0; var t = 0.0 }
    val M = HashMap<String, MH>()
    for (h in hs) { val c = h.cards ?: continue; val z = hk(c); val o = M.getOrPut(z) { MH(z) }; o.n++; o.t += h.nb }
    val A = M.values.filter { it.n >= 15 }.sortedBy { it.t }
    fun row(o: MH) = listOf<Any>(o.q, o.n, nbc(o.t))
    Sec("Patrones detectados") { I.forEach { Muted("• $it", 13) } }
    Sec("Por profundidad de stack") {
        Table(listOf("Stack", "Manos", "VPIP", "PFR", "bb/100"), dep(hs).map { z -> listOf<Any>(z.l, z.s.n, q(z.s, "vpip_x", "vpip_o"), q(z.s, "pfr_x", "pfr_o"), f1(B(z.s).m)) })
    }
    Sec("Manos que más pierden (bb total)") { Table(listOf("Mano", "N", "bb"), A.take(8).map { row(it) }, listOf(90, 60, 80)) }
    Sec("Manos que más ganan") { Table(listOf("Mano", "N", "bb"), A.takeLast(8).reversed().map { row(it) }, listOf(90, 60, 80)) }
}

// ===================== MANOS CLAVE =====================
@Composable
fun TabMan(e: Env) {
    val A = remember(e.hs) { e.hs.sortedBy { it.nb } }
    Sec("Mayores pérdidas") { Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { A.take(20).forEach { HandExpand(it) } } }
    Sec("Mayores ganancias") { Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { A.takeLast(20).reversed().forEach { HandExpand(it) } } }
}

// ===================== REVISIÓN =====================
@Composable
fun TabRev(e: Env) {
    val hs = e.hs
    class RV(val t: String, val w: Int) { var n = 0; var c = 0.0; val l = ArrayList<Hand>() }
    val L = remember(hs) {
        val m = LinkedHashMap<String, RV>()
        for (h in hs) for ((t, w) in flags(h)) { val o = m.getOrPut(t) { RV(t, w) }; o.n++; o.c += h.nb; o.l.add(h) }
        m.values.sortedWith(compareByDescending<RV> { it.w }.thenByDescending { it.n })
    }
    val bad = hs.count { flags(it).isNotEmpty() }
    Kpis(listOf(kp("Manos con alerta", pc(bad.toDouble(), hs.size.toDouble()), "$bad de ${hs.size}"), kp("Alertas graves", L.filter { it.w == 3 }.sumOf { it.n }.toString(), "severidad alta")))
    Muted("Alertas heurísticas (fuerza Chen + posición + M). Son pistas para revisar, no veredictos GTO.")
    if (L.isEmpty()) Muted("Sin alertas.")
    L.forEach { o ->
        Expand("${o.t} · ${o.n} manos · neto ${f1(o.c)} bb") {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { o.l.sortedBy { it.nb }.take(12).forEach { HandBlock(it, "M " + f1(it.M)) } }
        }
    }
}

// ===================== GRÁFICAS =====================
@Composable
fun TabGra(e: Env) {
    val hs = e.hs; val s = e.s
    val cs = ArrayList<Double>(); val ca = ArrayList<Double>(); val cdd = ArrayList<Double>()
    var c = 0.0; var a = 0.0; var d = 0.0
    for (h in hs) { c += h.nb; if (h.sd == 1) a += h.nb else d += h.nb; cs.add(c); ca.add(a); cdd.add(d) }
    val fs = listOf("pre", "flop", "turn", "river", "end")
    val fc = fs.map { z -> 100.0 * hs.count { it.fs == z } / max(hs.size, 1) }
    val E = listOf(-1e9, -20.0, -10.0, -5.0, -2.0, -.01, .01, 2.0, 5.0, 10.0, 20.0, 1e9)
    val hv = E.dropLast(1).mapIndexed { i, ee -> hs.count { it.nb >= ee && it.nb < E[i + 1] }.toDouble() }
    val T = tours(hs).sortedBy { it.s.nb }
    val X_ = if (T.size > 12) T.take(6) + T.takeLast(6) else T
    var cP = 0.0; var cS = 0.0; var cO = 0.0
    for (h in hs) { val cc = h.cards ?: continue; val z = hk(cc); if (z.length == 2) cP += h.nb else if (z[2] == 's') cS += h.nb else cO += h.nb }
    val w = min(150, hs.size / 3)
    Sec("Calendario de resultados") {
        if (hs.isNotEmpty()) CalendarHeat(hs)
        Muted("Cada cuadro es un día (últimos 6 meses); la intensidad marca el tamaño del resultado. Verde = ganancia, rojo = pérdida.")
    }
    Sec("Cuándo rindes mejor: día y hora (bb/100)") { DayHourHeat(hs); Muted("Solo se colorean las franjas con 15 manos o más; las grises tienen muestra corta.") }
    Sec("Con showdown vs sin showdown (bb acumulados)") { MultiLine(listOf(cs, ca, cdd), listOf(Color.White, PC.Ac, PC.Gr2), listOf("Total", "Con showdown", "Sin showdown")) }
    Sec("VPIP / PFR móvil ($w manos)") { if (w >= 5) MultiLine(listOf(roll(hs, { it.vpip }, w), roll(hs, { it.pfr }, w)), listOf(PC.Ac, PC.Gr2), listOf("VPIP", "PFR")) }
    Sec("Dónde foldeas (% de manos)") { BarChart(listOf("Pre", "Flop", "Turn", "River", "Sin fold"), fc, true) }
    Sec("Distribución del resultado por mano (bb)") { BarChart(listOf("<-20", "-20/-10", "-10/-5", "-5/-2", "-2/0", "0", "0/2", "2/5", "5/10", "10/20", ">20"), hv, true) }
    Sec("Neto por tipo de mano (bb)") { BarChart(listOf("Pares", "Suited", "Offsuit"), listOf(cP, cS, cO)) }
    Sec("Peores y mejores torneos (neto bb)") {
        BarChart(X_.map { "…" + it.id.takeLast(4) }, X_.map { it.s.nb })
        Muted("Torneos: " + X_.joinToString(" · ") { "…" + it.id.takeLast(4) + " " + it.name.take(22) })
    }
}

// ===================== AVANZADO =====================
@Composable
fun TabAv(e: Env) {
    val hs = e.hs
    class ZB(val l: String, val z: List<Hand>, val s: Agg)
    val Z = listOf(Triple("Verde M>20", 20.0, 1e9), Triple("Amarilla 10–20", 10.0, 20.0), Triple("Naranja 6–10", 6.0, 10.0), Triple("Roja 1–6", 1.0, 6.0), Triple("Muerta <1", 0.0, 1.0))
        .map { (l, a, b) -> val z = hs.filter { it.M >= a && it.M < b }; ZB(l, z, S(z)) }
    val by = HashMap<String, ArrayList<Hand>>()
    for (h in hs) by.getOrPut(h.tid) { ArrayList() }.add(h)
    val stg = listOf(ArrayList<Hand>(), ArrayList<Hand>(), ArrayList<Hand>())
    for (z0 in by.values) { val z = z0.sortedWith(CMP); z.forEachIndexed { i, h -> stg[min(2, 3 * i / z.size)].add(h) } }
    val nj = listOf(2 to 2, 3 to 3, 4 to 5, 6 to 9).map { (a, b) -> (if (a == b) "$a jugadores" else "$a–$b jugadores") to S(hs.filter { it.n in a..b }) }
    Sec("Zonas de M (Harrington: stack / ciegas+antes)") {
        BarChart(Z.map { it.l.split(" ")[0] }, Z.map { B(it.s).m })
        Table(
            listOf("Zona", "Manos", "VPIP", "PFR", "All-ins", "bb/100", "±IC95"),
            Z.map { x -> val n = x.z.count { it.ai == 1 }; listOf<Any>(x.l, x.s.n, q(x.s, "vpip_x", "vpip_o"), q(x.s, "pfr_x", "pfr_o"), "$n (${pc(n.toDouble(), x.s.n.toDouble())})", nbc(B(x.s).m), f1(B(x.s).ci)) },
            listOf(130, 70, 70, 70, 100, 70, 70)
        )
    }
    Sec("Etapa del torneo (tercios de cada torneo)") {
        Table(
            listOf("Etapa", "Manos", "VPIP", "PFR", "Steal", "All-ins", "bb/100"),
            listOf("Inicio", "Medio", "Final").mapIndexed { i, l -> val t = S(stg[i]); listOf<Any>(l, t.n, q(t, "vpip_x", "vpip_o"), q(t, "pfr_x", "pfr_o"), q(t, "stl_x", "stl_o"), stg[i].count { it.ai == 1 }, nbc(B(t).m)) }
        )
    }
    Sec("Por número de jugadores en la mano") {
        Table(listOf("Mesa", "Manos", "VPIP", "PFR", "bb/100"), nj.map { (l, t) -> listOf<Any>(l, t.n, q(t, "vpip_x", "vpip_o"), q(t, "pfr_x", "pfr_o"), nbc(B(t).m)) }, listOf(130, 70, 70, 70, 70))
    }
}

// ===================== CLARO =====================
@Composable
fun TabCl(e: Env) {
    val hs = e.hs; val s = e.s
    val n = max(s.n, 1)
    val V = 100 * gc(s, "vpip_x") / n; val P = 100 * gc(s, "pfr_x") / n
    val AF = SR(SM["af"]!!, s, NOCTX).v ?: 0.0
    fun gk(t: String, v: Double, lo: Int, hi: Int, d: String) = kp(t, f1(v) + "%", "$d · ideal $lo–$hi% " + (if (v < lo) "▼" else if (v > hi) "▲" else "✔"))
    fun pa(a: Char, r: Boolean?) = 100.0 * hs.count { it.pa == a && (r == null || (it.pr > 0) == r) } / n
    fun qq(a: Double, z: Double) = if (z > 0) 100 * a / z else 0.0
    var c = 0.0; var pk = 0.0; var dd = 0.0
    for (h in hs) { c += h.nb; pk = max(pk, c); dd = max(dd, pk - c) }
    val D = HashMap<String, Double>()
    for (h in hs) { val dt = LocalDate.ofEpochDay(h.day); val k = String.format("%02d-%02d", dt.monthValue, dt.dayOfMonth); D[k] = (D[k] ?: 0.0) + h.nb }
    val ds = D.keys.sorted().takeLast(20)
    class CH { var n = 0; var t = 0.0; var w = 0 }
    val C = HashMap<String, CH>()
    for (h in hs) { val k = h.hc ?: continue; val o = C.getOrPut(k) { CH() }; o.n++; o.t += h.nb; o.w += h.wsd }
    val cs = C.entries.sortedByDescending { it.value.n }.take(7)
    val ps = PO.map { p -> S(hs.filter { it.pos == p }) }
    Kpis(
        listOf(
            gk("VPIP", V, 20, 30, "Manos que juegas"), gk("PFR", P, 14, 22, "Subes primero"), kp("Brecha VPIP–PFR", f1(V - P), "puntos · ideal 3–8"),
            gk("3-bet", qq(gc(s, "t3_x"), gc(s, "t3_o")), 5, 9, "Re-subes un open"), gk("C-bet", qq(gc(s, "cb_x"), gc(s, "cb_o")), 50, 70, "Apuestas flop siendo agresor"),
            gk("WTSD", qq(gc(s, "sd"), gc(s, "saw")), 25, 32, "Llegas a showdown"), gk("W\$SD", qq(gc(s, "wsd"), gc(s, "sd")), 48, 55, "Ganas el showdown"),
            kp("Agresión (AF)", f2(AF), "bets+raises ÷ calls · ideal 1.5–3"), kp("Manos ganadas", pc(hs.count { it.nb > 0 }.toDouble(), n.toDouble()), "resultado neto positivo"),
            kp("Mayor caída", f1(dd), "bb desde tu pico acumulado"), kp("Mejor / peor mano", f1(s.arr.maxOrNull()) + " / " + f1(s.arr.minOrNull()), "bb")
        )
    )
    Sec("Qué haces preflop (% de manos)") { BarChart(listOf("Fold", "Check BB", "Limp", "Call", "Open/raise", "3-bet+"), listOf(pa('f', null), pa('x', null), pa('c', false), pa('c', true), pa('r', false), pa('r', true)), true) }
    Sec("VPIP y PFR por posición") { BarChart2(PO, ps.map { 100 * gc(it, "vpip_x") / max(it.n, 1) }, ps.map { 100 * gc(it, "pfr_x") / max(it.n, 1) }) }
    Sec("Resultado por día (bb)") { BarChart(ds, ds.map { D[it]!! }) }
    Sec("Mano que muestras en showdown") {
        BarChart(cs.map { it.key }, cs.map { it.value.t })
        Table(listOf("Mano", "Veces", "% gana", "Neto bb"), cs.map { (a, o) -> listOf<Any>(a, o.n, pc(o.w.toDouble(), o.n.toDouble()), nbc(o.t)) }, listOf(140, 70, 80, 80))
    }
}
