package com.pokerlab

import java.time.LocalDateTime
import java.time.ZoneId
import kotlin.math.max
import kotlin.math.min

const val RK = "AKQJT98765432"
val PO = listOf("UTG", "MP", "HJ", "CO", "BTN", "SB", "BB")
val SK = listOf("flop", "turn", "river")

fun num(s: String): Double = s.replace(",", "").toDouble()

class Act(
    val st: String, val k: Char, val rc: Int, val face: Boolean, val lp: Int, val ap: String?,
    val pot: Double, val tc: Double, val amt: Double, val to: Double, val ai: Boolean,
    val fAI: Boolean, val ip: Boolean?, val pgA: Boolean?
)

class EvData(
    val act: List<String>, val cards: Map<String, List<String>>, val inv: Map<String, Double>,
    val board: List<String>, val st: String
)

class EqRes(
    val e: Double, val ev: Double, val lk: Double, val pl: List<List<String>>,
    val b: List<String>, val st: String, val n: Int, val exact: Boolean
)

class Hand(
    val id: String, val bb: Double, val sb: Double, val an: Double, val ts: Long,
    val tn: String, val tid: String, val raw: String, val pos: String, val n: Int, val stack: Double
) {
    var cards: List<String>? = null
    val c = HashMap<String, Double>()
    var vpip = 0; var pfr = 0; var saw = 0; var sd = 0; var wsd = 0
    var col = 0.0; var inv = 0.0; var net = 0.0; var nb = 0.0; var M = 0.0
    var rfiO = 0; var rfi = 0; var cvs = 0
    var pt = 0; var agg = 0; var ip: Boolean? = null; var nOpp = 0; var cbHit = false
    var spr: Double? = null
    var fs = "end"; var potTotal = 0.0; var pl = 0; var pa = 'x'; var pr = 0; var hc: String? = null
    var anyAI = 0; var ai = 0; var aiSt = "pre"; var aiK = 'b'; var aiCalled = 1
    var evd: EvData? = null
    @Volatile var eqDone = false
    @Volatile var eq: EqRes? = null
    var fl: List<Pair<String, Int>>? = null
    var hour = 0; var dow = 0; var day = 0L
}

val CMP = Comparator<Hand> { a, b ->
    val t = a.ts.compareTo(b.ts)
    if (t != 0) t else {
        val l = a.id.length.compareTo(b.id.length)
        if (l != 0) l else a.id.compareTo(b.id)
    }
}

private class Seat(val n: Int, val p: String, val st: Double)
private class AIe(val p: String, val st: String, val k: Char)

private val RH = Regex("""^CoinPoker Hand #(\d+): NLH \(([\d.,]+)/([\d.,]+)/([\d.,]+)\) (\d+)/(\d+)/(\d+) (\d+):(\d+):(\d+)""")
private val RT = Regex("""^Tournament '(.*)' '(\d+)' (\d+)-max Seat #(\d+) is the button""")
private val RS = Regex("""^Seat (\d+): (\S+) \(([\d.,]+) in chips\)""")
private val RDEAL = Regex("""^Dealt to Hero \[(\w\w) (\w\w)\]""")
private val RST = Regex("""^\*\*\* (FLOP|TURN|RIVER) \*\*\*""")
private val RBR = Regex("""\[([^\]]*)\]\s*$""")
private val RPOST = Regex("""^(\S+): posts (?:the )?(ante|small blind|big blind) ([\d.,]+)""")
val RACT = Regex("""^(\S+): (folds|checks|calls ([\d.,]+)|bets ([\d.,]+)|raises ([\d.,]+) to ([\d.,]+)|ALLIN ([\d.,]+)|RETURN ([\d.,]+))""")
private val RCOL = Regex("""^Hero collected ([\d.,]+) from""", RegexOption.MULTILINE)
private val RSDW = Regex("""^Hero: (shows|mucks)""", RegexOption.MULTILINE)
private val RHC = Regex("""^Hero: shows \[.*?\] \((.*?)\)""", RegexOption.MULTILINE)
private val RSHOW = Regex("""^(\S+): shows \[(\w\w) (\w\w)\]""", RegexOption.MULTILINE)
private val RTOT = Regex("""^Total pot ([\d.,]+)""", RegexOption.MULTILINE)
private val WS = Regex("\\s+")

fun parseHands(txt: String): List<Hand> {
    val out = ArrayList<Hand>()
    for (b in txt.replace("\r", "").split(Regex("\n+(?=CoinPoker Hand #)"))) {
        try {
            val h = ph(b)
            if (h != null) out.add(h)
        } catch (e: Exception) {
            // mano omitida
        }
    }
    return out
}

private fun ph(b: String): Hand? {
    val L = b.split("\n")
    val m = RH.find(L[0]) ?: return null
    val t = RT.find(L.getOrElse(1) { "" }) ?: return null
    val seats = ArrayList<Seat>()
    var i = 2
    while (i < L.size) {
        val s = RS.find(L[i]) ?: break
        seats.add(Seat(s.groupValues[1].toInt(), s.groupValues[2], num(s.groupValues[3])))
        i++
    }
    val hero = seats.find { it.p == "Hero" } ?: return null
    seats.sortBy { it.n }
    val n = seats.size
    val btn = t.groupValues[4].toInt()
    val stk = HashMap<String, Double>()
    seats.forEach { stk[it.p] = it.st }
    var bi = -1
    seats.forEachIndexed { k, s -> if (s.n <= btn) bi = k }
    if (bi < 0) bi = n - 1
    val ord = ArrayList<String>()
    for (k in 1..n) ord.add(seats[(bi + k) % n].p)
    val oi = HashMap<String, Int>()
    ord.forEachIndexed { k, p -> oi[p] = k }
    val pos = HashMap<String, String>()
    if (n == 2) {
        pos[ord[1]] = "BTN"; pos[ord[0]] = "BB"
    } else {
        pos[ord[0]] = "SB"; pos[ord[1]] = "BB"; pos[ord[n - 1]] = "BTN"
        val k = n - 3
        for (j in 0 until k) {
            val e = k - 1 - j
            pos[ord[2 + j]] = if (e == 0) "CO" else if (e == 1) "HJ" else if (j == 0) "UTG" else "MP"
        }
    }
    val bb = num(m.groupValues[3]); val sb = num(m.groupValues[2]); val an = num(m.groupValues[4])
    val ldt = LocalDateTime.of(
        m.groupValues[5].toInt(), m.groupValues[6].toInt(), m.groupValues[7].toInt(),
        m.groupValues[8].toInt(), m.groupValues[9].toInt(), m.groupValues[10].toInt()
    )
    val ts = ldt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    val h = Hand(m.groupValues[1], bb, sb, an, ts, t.groupValues[1], t.groupValues[2], b, pos["Hero"] ?: "BB", n, hero.st)
    h.hour = ldt.hour; h.dow = ldt.dayOfWeek.value - 1; h.day = ldt.toLocalDate().toEpochDay()

    var st = "pre"
    val com = HashMap<String, Double>(); val tot = HashMap<String, Double>()
    val ante = HashMap<String, Double>(); val ret = HashMap<String, Double>()
    var lvl = bb; var rcS = 0; var pfAgg: String? = null; var fb: String? = null
    var flop = 0; var lp = 0; var lvlAI = false; var pfRaises = 0
    var act0: List<String>? = null
    var heroShoved = false; var heroShoveCalled = false
    val folded = HashSet<String>(); val acted = HashSet<String>()
    val ai = ArrayList<AIe>(); val acts = ArrayList<Act>(); val bc = ArrayList<String>()

    fun pot(): Double = ante.values.sum() + tot.values.sum() + com.values.sum()
    fun act(): List<String> = seats.filter { !folded.contains(it.p) }.map { it.p }
    fun invNow(p: String): Double = (ante[p] ?: 0.0) + (tot[p] ?: 0.0) + (com[p] ?: 0.0)
    fun ipNow(): Boolean = act().all { it == "Hero" || (oi[it] ?: 0) < (oi["Hero"] ?: 0) }

    loop@ for (idx in i until L.size) {
        val l = L[idx]
        val xd = RDEAL.find(l)
        if (xd != null) { h.cards = listOf(xd.groupValues[1], xd.groupValues[2]); continue@loop }
        val xs = RST.find(l)
        if (xs != null) {
            for ((p, v) in com) tot[p] = (tot[p] ?: 0.0) + v
            com.clear(); lvl = 0.0
            val sname = xs.groupValues[1]
            if (sname == "FLOP") {
                flop = 1; pfRaises = rcS
                val a0 = act(); act0 = a0
                val pf = pot()
                var mx = 0.0
                for (q in a0) if (q != "Hero") mx = max(mx, (stk[q] ?: 0.0) - invNow(q))
                h.spr = if (pf > 0) min((stk["Hero"] ?: 0.0) - invNow("Hero"), mx) / pf else null
            }
            rcS = 0; lvlAI = false; acted.clear(); st = sname.lowercase()
            val bm = RBR.find(l)
            if (bm != null) {
                val cs = bm.groupValues[1].trim().split(WS)
                if (sname == "FLOP") bc.clear()
                bc.addAll(cs)
            }
            continue@loop
        }
        if (l.startsWith("*** SUMMARY")) break@loop
        val xp = RPOST.find(l)
        if (xp != null) {
            val a = num(xp.groupValues[3])
            if (xp.groupValues[2] == "ante") ante[xp.groupValues[1]] = a else com[xp.groupValues[1]] = a
            continue@loop
        }
        val xa = RACT.find(l) ?: continue@loop
        val g = xa.groupValues
        val p = g[1]
        val c0 = com[p] ?: 0.0
        val tc = max(0.0, lvl - c0)
        val pB = pot()
        var k: Char
        var amt = 0.0
        var expl = false
        if (g[8].isNotEmpty()) { ret[p] = (ret[p] ?: 0.0) + num(g[8]); continue@loop }
        if (g[2] == "folds") k = 'f'
        else if (g[2] == "checks") k = 'x'
        else if (g[3].isNotEmpty()) { k = 'c'; amt = num(g[3]); com[p] = c0 + amt }
        else if (g[4].isNotEmpty()) { k = 'b'; amt = num(g[4]); com[p] = amt }
        else if (g[5].isNotEmpty()) { k = 'r'; com[p] = num(g[6]); amt = (com[p] ?: 0.0) - c0 }
        else {
            amt = num(g[7]); val a = c0 + amt
            k = if (a > lvl) (if (lvl > 0) 'r' else 'b') else 'c'
            com[p] = a; expl = true
        }
        val isAI = expl || (k != 'f' && k != 'x' && invNow(p) >= (stk[p] ?: 0.0) - .5)
        if (isAI) ai.add(AIe(p, st, k))
        if (p == "Hero") {
            val pa = pfAgg
            acts.add(
                Act(
                    st, k, rcS, tc > 0, lp, if (pa != null) pos[pa] else null, pB, tc, amt,
                    com["Hero"] ?: 0.0, isAI, lvlAI && tc > 0, if (st == "pre") null else ipNow(),
                    if (pa != null && pa != "Hero") acted.contains(pa) else null
                )
            )
        }
        if (p == "Hero" && isAI && (k == 'b' || k == 'r')) heroShoved = true
        else if (heroShoved && p != "Hero" && k == 'c') heroShoveCalled = true
        if (st == "pre" && k == 'c') lp++
        if (k == 'f') folded.add(p)
        acted.add(p)
        if (k == 'b' || k == 'r') {
            lvl = max(lvl, com[p] ?: 0.0); rcS++; lvlAI = isAI
            if (st == "pre") pfAgg = p else if (fb == null && st == "flop") fb = p
        }
    }
    for ((p, v) in com) tot[p] = (tot[p] ?: 0.0) + v
    val inv = HashMap<String, Double>()
    for (s in seats) inv[s.p] = (ante[s.p] ?: 0.0) + (tot[s.p] ?: 0.0) - (ret[s.p] ?: 0.0)
    var col = 0.0
    for (x in RCOL.findAll(b)) col += num(x.groupValues[1])
    val heroInv = inv["Hero"] ?: 0.0
    h.col = col; h.inv = heroInv; h.net = col - heroInv; h.nb = h.net / bb
    h.M = h.stack / (sb + bb + an * n)

    val C = h.c
    fun o(k: String, hit: Boolean) {
        C[k + "_o"] = (C[k + "_o"] ?: 0.0) + 1
        if (hit) C[k + "_x"] = (C[k + "_x"] ?: 0.0) + 1
    }
    fun ad(k: String, v: Double = 1.0) { C[k] = (C[k] ?: 0.0) + v }
    fun isR(a: Act) = a.k == 'r' || a.k == 'b'
    fun by(s: String) = acts.filter { it.st == s }

    val pre = by("pre"); val P = h.pos; val f0 = pre.firstOrNull()
    h.vpip = if (pre.any { it.k == 'c' || isR(it) }) 1 else 0
    h.pfr = if (pre.any { isR(it) }) 1 else 0
    o("vpip", h.vpip == 1); o("pfr", h.pfr == 1)
    if (f0 != null) {
        if (P != "BB" && f0.rc == 0) {
            o("lim", f0.k == 'c')
            if (f0.lp == 0) {
                o("rfi", isR(f0)); h.rfiO = 1; h.rfi = if (isR(f0)) 1 else 0
                if (isR(f0) && !f0.ai) {
                    ad("osz_s", f0.to / bb); ad("osz_n"); ad("osz_s_$P", f0.to / bb); ad("osz_n_$P")
                }
                if (P == "CO" || P == "BTN" || P == "SB") o("stl", isR(f0))
                if (h.stack / bb <= 15) o("shv", isR(f0) && f0.ai)
            }
        }
        if (f0.rc == 0 && f0.lp > 0) o("iso", isR(f0))
        if (f0.rc == 1) {
            o("t3", f0.k == 'r'); o("ffo", f0.k == 'f'); o("cfo", f0.k == 'c')
            if (f0.lp > 0) o("sq", f0.k == 'r')
            if (P == "BB" && f0.lp == 0 && (f0.ap == "CO" || f0.ap == "BTN" || f0.ap == "SB")) {
                o("bbf", f0.k == 'f'); o("bb3", f0.k == 'r'); o("bbc", f0.k == 'c')
            }
            if (P == "SB" && f0.lp == 0 && (f0.ap == "CO" || f0.ap == "BTN")) {
                o("sbf", f0.k == 'f'); o("sb3", f0.k == 'r'); o("sbc", f0.k == 'c')
            }
        }
    }
    val op = pre.indexOfFirst { it.rc == 0 && it.k == 'r' }
    if (op >= 0) {
        val a3 = pre.filterIndexed { ix, a -> ix > op && a.rc == 2 }.firstOrNull()
        if (a3 != null) { o("f3", a3.k == 'f'); o("c3", a3.k == 'c'); o("b4", a3.k == 'r') }
    }
    if (f0 != null && f0.rc == 1 && f0.k == 'r') {
        val a4 = pre.filterIndexed { ix, a -> ix > 0 && a.rc == 3 }.firstOrNull()
        if (a4 != null) { o("f4", a4.k == 'f'); o("c4", a4.k == 'c') }
    }
    val fvs = pre.firstOrNull { it.fAI }
    if (fvs != null) { o("cvs", fvs.k == 'c'); h.cvs = 1 }

    // postflop
    h.saw = if (flop == 1 && pre.none { it.k == 'f' }) 1 else 0
    h.pt = pfRaises; h.agg = if (pfAgg == "Hero") 1 else 0; h.ip = null; h.nOpp = 0
    if (h.saw == 1) {
        val fa0 = acts.firstOrNull { it.st != "pre" }
        if (fa0 != null) h.ip = fa0.ip
        h.nOpp = if (act0 != null) act0.size - 1 else 0
    }
    val fl = by("flop"); val tu = by("turn"); val rv = by("river")
    val SA = listOf("flop" to fl, "turn" to tu, "river" to rv)
    var cbHit = false; var b2Hit = false
    val pa0 = pfAgg
    if (h.saw == 1 && fl.isNotEmpty()) {
        val a = fl[0]
        if (pa0 == "Hero" && a.rc == 0) {
            val hit = isR(a)
            o("cb", hit); o(if (a.ip == true) "cbIP" else "cbOP", hit); o(if (h.nOpp == 1) "cbH" else "cbM", hit)
            cbHit = hit
            if (hit && !a.ai) { ad("cbsz_s", a.amt / a.pot); ad("cbsz_n") }
        }
        if (!a.face && pa0 != null && pa0 != "Hero" && a.pgA == false && act0 != null && act0.contains(pa0)) o("dnk", a.k == 'b')
        val fa = fl.firstOrNull { it.face }
        if (pa0 != null && pa0 != "Hero" && fa != null && fa.rc == 1 && fb == pa0) {
            o("fcb", fa.k == 'f'); o("ccb", fa.k == 'c'); o("rcb", fa.k == 'r')
        }
    }
    h.cbHit = cbHit
    if (cbHit && tu.isNotEmpty() && tu[0].rc == 0) { b2Hit = isR(tu[0]); o("b2", b2Hit) }
    if (b2Hit && rv.isNotEmpty() && rv[0].rc == 0) o("b3", isR(rv[0]))
    for ((s, arr) in SA) {
        val fa = arr.firstOrNull { it.face }
        if (fa != null) {
            o("fold_$s", fa.k == 'f'); o("call_$s", fa.k == 'c'); o("raise_$s", fa.k == 'r')
            if (fa.rc == 1 && fa.pot - fa.tc > 0) {
                ad("mdf_s_$s", (fa.pot - fa.tc) / fa.pot); ad("mdf_n_$s"); ad("mf_n_$s")
                if (fa.k == 'f') ad("mf_x_$s")
                ad("req_s_$s", fa.tc / (fa.pot + fa.tc))
                ad("osb_s_$s", fa.tc / (fa.pot - fa.tc)); ad("osb_n_$s")
            }
        }
        val xi = arr.indexOfFirst { it.k == 'x' }
        if (xi >= 0 && xi + 1 < arr.size) o("xr_$s", arr[xi + 1].k == 'r')
        val a0 = arr.firstOrNull()
        if (a0 != null && !a0.face) {
            o("bt_$s", a0.k == 'b'); o("bt_${s}_" + (if (a0.ip == true) "IP" else "OOP"), a0.k == 'b')
        }
        for (a in arr) {
            if (isR(a)) ad("ab_$s") else if (a.k == 'c') ad("ac_$s") else if (a.k == 'f') ad("af_$s") else if (a.k == 'x') ad("ax_$s")
            if (a.k == 'b' && !a.ai && a.pot > 0) { ad("bsz_s_$s", a.amt / a.pot); ad("bsz_n_$s") }
        }
    }
    h.sd = if (h.saw == 1 && RSDW.containsMatchIn(b)) 1 else 0
    h.wsd = if (h.sd == 1 && col > 0) 1 else 0
    ad("saw", h.saw.toDouble()); ad("sd", h.sd.toDouble()); ad("wsd", h.wsd.toDouble())
    ad("wsf", if (h.saw == 1 && col > 0) 1.0 else 0.0)
    ad("wnsd", if (h.saw == 1 && col > 0 && h.sd == 0) 1.0 else 0.0)
    val faAct = acts.firstOrNull { it.k == 'f' }
    h.fs = faAct?.st ?: "end"
    h.potTotal = RTOT.find(b)?.let { num(it.groupValues[1]) } ?: 0.0
    h.pl = f0?.lp ?: 0; h.pa = f0?.k ?: 'x'; h.pr = f0?.rc ?: 0
    h.hc = RHC.find(b)?.groupValues?.get(1)

    // all-ins
    h.anyAI = if (ai.isNotEmpty()) 1 else 0
    h.ai = if (heroInv >= hero.st - .5) 1 else 0
    if (h.ai == 1) {
        val a = acts.firstOrNull { it.ai }
        h.aiSt = a?.st ?: "pre"
        h.aiK = if (a != null) (if (a.k == 'c') 'c' else 's') else 'b'
        h.aiCalled = if (h.aiK == 's') (if (heroShoveCalled) 1 else 0) else 1
    }
    val actv = act()
    val cd0 = HashMap<String, List<String>>()
    h.cards?.let { cd0["Hero"] = it }
    for (x in RSHOW.findAll(b)) cd0[x.groupValues[1]] = listOf(x.groupValues[2], x.groupValues[3])
    val ae = ai.filter { !folded.contains(it.p) }
    if (!folded.contains("Hero") && ae.isNotEmpty() && actv.size >= 2) {
        h.evd = EvData(actv, cd0, inv, bc.toList(), ae.last().st)
    }
    return h
}
