package com.pokerlab

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalTime
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

class Env(val vm: MainVm, val hs: List<Hand>, val s: Agg)

// ===================== utilidades compartidas =====================
fun roll(hs: List<Hand>, k: (Hand) -> Int, w: Int): List<Double> {
    val o = ArrayList<Double>(); var s = 0.0
    hs.forEachIndexed { i, h ->
        s += k(h)
        if (i >= w) s -= k(hs[i - w])
        if (i >= w - 1) o.add(100 * s / w)
    }
    return o
}

fun byNb(L: List<Hand>, n: Int, w: Boolean): List<Hand> {
    val A = L.filter { it.cards != null }.sortedBy { it.nb }
    return if (w) A.takeLast(n).reversed() else A.take(n)
}

fun hk(c: List<String>): String {
    var x = c[0][0]; var y = c[1][0]
    if (RK.indexOf(x) > RK.indexOf(y)) { val t = x; x = y; y = t }
    return if (x == y) "$x$y" else "$x$y" + (if (c[0][1] == c[1][1]) "s" else "o")
}

fun saludo(): String {
    val h = LocalTime.now().hour
    return if (h < 6) "Buenas noches" else if (h < 12) "Buenos días" else if (h < 19) "Buenas tardes" else "Buenas noches"
}

fun mixp(hs: List<Hand>, a: Char): List<Double> = PO.map { p ->
    val z = hs.filter { it.pos == p }
    if (z.isNotEmpty()) 100.0 * z.count { it.pa == a } / z.size else 0.0
}

fun pfc(hs: List<Hand>, a: Char, r: Boolean?): Double = hs.count { it.pa == a && (r == null || (it.pr > 0) == r) }.toDouble()

val CK = listOf("Pre", "Post", "Torneo", "Mate", "Disc", "Res")
val LBL = mapOf("Pre" to "Preflop", "Post" to "Postflop", "Torneo" to "Torneo", "Mate" to "Matemática", "Disc" to "Disciplina", "Res" to "Resultado")

@Composable
fun HandBlock(h: Hand, extra: String = "") {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(PC.P2).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Cards(h.cards)
            Pill(h.pos)
            Text((if (h.nb > 0) "+" else "") + f1(h.nb) + " bb", color = if (h.nb >= 0) PC.Gd else PC.Bd, fontWeight = FontWeight.SemiBold)
            if (extra.isNotEmpty()) Muted(extra)
        }
        Muted(h.tn.take(30))
        Spacer(Modifier.height(4.dp))
        HandDetail(h)
    }
}

@Composable
fun Top5(hs: List<Hand>) {
    val A = remember(hs) { hs.sortedBy { it.nb } }
    Sec("Top 5 mejores manos") { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { A.takeLast(5).reversed().forEach { HandBlock(it) } } }
    Sec("Top 5 peores manos") { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { A.take(5).forEach { HandBlock(it) } } }
}

@Composable
fun Drawdown(c: List<Double>) {
    if (c.size < 2) return
    var m = -1e9; var w = 0; var wm = 0
    val y = c.map { v -> if (v >= m) { m = v; w = 0 } else w++; wm = max(wm, w); v - m }
    val lo = min(0.0, y.min())
    LineChart(y, true)
    Muted("Peor caída: ${f1(lo)} bb · ahora: ${f1(y.last())} bb bajo tu máximo · racha más larga sin nuevo máximo: ${fmtN(wm)} manos.")
}

@Composable
fun LevelBar(L: Lvl) {
    val v = max(0.0, min(100.0, L.adj))
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Column {
            Text(v.toInt().toString(), fontSize = 44.sp, fontWeight = FontWeight.SemiBold, color = PC.Tx)
            Pill(L.ti.name)
        }
        Column(Modifier.weight(1f)) {
            LinearProgressIndicator(progress = { (v / 100).toFloat() }, modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(6.dp)), color = PC.Ac, trackColor = PC.P2)
            Muted(L.ti.desc + (if (L.nx != null) " · Siguiente: " + L.nx.name + " desde " + L.nx.lo else ""))
        }
    }
}

fun aud(hs: List<Hand>): String {
    val m = HashMap<String, ArrayList<Hand>>()
    for (h in hs) m.getOrPut(h.tid) { ArrayList() }.add(h)
    var c = 0; var o = 0
    for (t in m.values) {
        val a = t.sortedWith(CMP)
        for (i in 0 until a.size - 1) { c++; if (Math.abs(a[i].stack + a[i].net - a[i + 1].stack) <= 1) o++ }
    }
    return "$o/$c manos consistentes"
}

// ===================== RESUMEN =====================
@Composable
fun TabRes(e: Env) {
    val hs = e.hs; val s = e.s; val vm = e.vm
    val ev = vm.evVer
    val b = B(s); val E = evSum(hs)
    val cum = remember(hs) { var c = 0.0; hs.map { c += it.nb; c } }
    val d = remember(hs) { dep(hs) }
    val hr = remember(hs) { List(24) { i -> S(hs.filter { it.hour == i }) } }
    val lv = remember(hs, ev) { level(hs, s) }
    val need = if (b.sd > 0) ceil((196 * b.sd / 5).pow(2)).toLong() else 0L
    val adj: Double? = if (E.n > 0) (s.nb - E.luck) / s.n * 100 else null
    val nm = vm.uname.ifBlank { "Jugador" }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF3A0F1B), PC.P))).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(Modifier.size(46.dp).clip(CircleShape).background(PC.Ac), contentAlignment = Alignment.Center) {
            Text(nm.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        Column {
            Text(saludo() + ", " + nm, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = PC.Tx)
            Muted("Tienes ${fmtN(vm.H.size)} manos de ${vm.H.map { it.tid }.toSet().size} torneos cargadas.")
        }
    }
    Kpis(
        listOf(
            kp("Manos", fmtN(s.n)), kp("Torneos", hs.map { it.tid }.toSet().size.toString()),
            kp("VPIP", q(s, "vpip_x", "vpip_o"), spark = roll(hs, { it.vpip }, max(5, hs.size shr 2))),
            kp("PFR", q(s, "pfr_x", "pfr_o"), spark = roll(hs, { it.pfr }, max(5, hs.size shr 2))),
            kp("3-bet", q(s, "t3_x", "t3_o")), kp("Fold a 3-bet", q(s, "f3_x", "f3_o")),
            kp("C-bet flop", q(s, "cb_x", "cb_o")), kp("Fold a C-bet", q(s, "fcb_x", "fcb_o")),
            kp("Agresión post", f2(SR(SM["af"]!!, s, NOCTX).v), "apuestas+subidas / calls"),
            kp("WTSD", q(s, "sd", "saw")), kp("W\$SD", q(s, "wsd", "sd")),
            kp("bb/100", f1(b.m), "IC95% ±" + f1(b.ci), toneOf(b.m)),
            kp("bb/100 ajust. EV", if (adj == null) "–" else f1(adj), if (E.n > 0) "${E.n} all-ins con EV" else if (vm.evBusy) "calculando…" else "sin all-ins con cartas", if (adj == null) 0 else toneOf(adj)),
            kp("Desv. típica/mano", f1(b.sd) + " bb", "varianza"),
            kp("Manos p/ ±5 bb/100", if (need > 0) fmtN(need) else "–", "para IC95% de ±5")
        )
    )
    Sec("Nivel estimado") { LevelBar(lv) }
    Sec("Panel de control: tus stats frente al rango ideal") {
        Bullets(listOf("vpip", "pfr", "rfi", "t3", "f3", "stl", "cb", "fcb", "wtsd", "wsd", "af", "afq").map { SR(SM[it]!!, s, NOCTX) })
    }
    Sec("Dónde terminan tus manos") {
        Donut(
            listOf(
                Triple("Fold preflop", hs.count { it.fs == "pre" }.toDouble(), Color(0xFF4A3A41)),
                Triple("Fold en flop", hs.count { it.fs == "flop" }.toDouble(), Color(0xFF7A6A72)),
                Triple("Fold en turn", hs.count { it.fs == "turn" }.toDouble(), PC.Wn),
                Triple("Fold en river", hs.count { it.fs == "river" }.toDouble(), Color(0xFFFF8FA3)),
                Triple("Sin fold", hs.count { it.fs == "end" }.toDouble(), PC.Ac)
            ), fmtN(hs.size), "manos"
        )
    }
    Sec("Manos ganadas y perdidas") {
        Donut(
            listOf(
                Triple("Ganadas", hs.count { it.nb > 0 }.toDouble(), PC.Gd),
                Triple("Perdidas", hs.count { it.nb < 0 }.toDouble(), PC.Bd),
                Triple("Sin cambio", hs.count { it.nb == 0.0 }.toDouble(), Color(0xFF7A6A72))
            ), pc(hs.count { it.nb > 0 }.toDouble(), hs.size.toDouble(), 0), "ganadas"
        )
    }
    Sec("Resultado acumulado (ciegas grandes)") { LineChart(cum, true) }
    Sec("Caídas desde tu máximo (drawdown)") { Drawdown(cum) }
    Sec("bb/100 por profundidad de stack") {
        BarChart(d.map { it.l }, d.map { B(it.s).m })
        Muted("Manos: " + d.joinToString(" · ") { it.l + " " + it.s.n })
    }
    Sec("bb/100 por hora del día") { BarChart(List(24) { it.toString() }, hr.map { B(it).m }) }
    Top5(hs)
}

// ===================== NIVEL =====================
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun TabNiv(e: Env) {
    val hs = e.hs; val s = e.s
    val ev = e.vm.evVer
    val L = remember(hs, ev) { level(hs, s) }
    val conf = if (s.n >= 15000) "muy alta" else if (s.n >= 5000) "alta" else if (s.n >= 1500) "media" else "baja"
    val cn = LinkedHashMap(CATN).also { it["Res"] = "Resultado (EV, IC)" }
    val lo = L.ti.lo; val hi = L.nx?.lo ?: 100
    val pg = max(0.0, min(100.0, 100 * (L.adj - lo) / (hi - lo)))
    val worst = L.cw.keys.filter { L.C[it]!!.v != null }.sortedBy { L.C[it]!!.v }
    val mdf = SK.mapNotNull { z ->
        val m = gc(s, "mdf_n_$z")
        if (m > 0) "$z: MDF medio ${f1(100 * gc(s, "mdf_s_$z") / m)}% (apuesta media rival ${f1(100 * gc(s, "osb_s_$z") / gc(s, "osb_n_$z"))}% del bote, equity requerida ${f1(100 * gc(s, "req_s_$z") / m)}%)" else null
    }
    Sec("Tu nivel") {
        GaugeArc(L.adj, L.adj.toInt().toString(), L.ti.name + (if (L.nx != null) " · siguiente: ${L.nx.name} a ${L.nx.lo}" else ""))
        LinearProgressIndicator(progress = { (pg / 100).toFloat() }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(6.dp)), color = PC.Ac, trackColor = PC.P2)
        Muted("${pg.toInt()}% del camino al siguiente nivel")
    }
    Kpis(
        listOf(kp("Puntaje observado", f1(L.raw), "sin ajuste por muestra · " + L.tr.name), kp("Confianza", conf, "${s.n} manos · peso de datos ${(100 * L.sh).toInt()}%")) +
            L.cw.keys.map { c -> kp(cn[c] ?: c, if (L.C[c]!!.v == null) "–" else L.C[c]!!.v!!.toInt().toString(), "peso " + Math.round(L.cw[c]!! * 100) + "%") }
    )
    Sec("Escalones") {
        androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            TIERS.forEach { z ->
                val on = z === L.ti; val done = !on && L.adj > z.lo
                Text(
                    z.name + " ≥" + z.lo, fontSize = 12.sp, color = if (on) Color.White else if (done) PC.Tx else PC.Mu,
                    modifier = Modifier.clip(RoundedCornerShape(99.dp)).background(if (on) PC.Ac else Color.Transparent)
                        .border(1.dp, if (on || done) PC.Ac else PC.Ln, RoundedCornerShape(99.dp)).padding(horizontal = 11.dp, vertical = 3.dp)
                )
            }
        }
        Note(L.ti.name + ": " + L.ti.desc + (if (L.nx != null) "\nPara llegar a ${L.nx.name} necesitas +${f1(L.nx.lo - L.adj)} puntos." else ""))
    }
    Sec("Por qué este nivel y no uno más alto") {
        Muted("• El puntaje compara tus estadísticas con rangos de un regular de MTT y es estricto: cada stat vale 100 solo si está dentro del rango y pierde puntos linealmente al salirse.", 13)
        Muted("• Con ${s.n} manos solo el ${(100 * L.sh).toInt()}% del puntaje viene de tus datos; el resto se acerca al promedio (38). A ~15 000 manos pesa ≈93%.", 13)
        if (L.fr > .7) Muted("• El ${(100 * L.fr).toInt()}% de tus manos son freerolls (campo débil): el nivel se limita a ${L.cap.toInt()}.", 13)
        if (worst.isNotEmpty()) Muted("• Tu categoría más débil: ${cn[worst[0]]} (${L.C[worst[0]]!!.v!!.toInt()}/100).", 13)
        Muted("• Resultado ${if (L.x.evn > 0) "ajustado por EV de ${L.x.evn} all-ins" else "sin ajuste por all-ins"}: ${f1(L.x.adjM)} bb/100 ± ${f1(L.x.ci)}.", 13)
    }
    Sec("Perfil por categoría") { Radar(CK.map { LBL[it]!! }, listOf(Triple(CK.map { L.C[it]!!.v ?: 0.0 }, PC.Ac, "Tu perfil"))) }
    Sec("Puntaje por categoría") { BarChart(CK.map { LBL[it]!! }, CK.map { L.C[it]!!.v ?: 0.0 }, true) }
    Sec("Qué subir primero (impacto si llevas la stat al rango)") {
        Table(
            listOf("Stat", "Tu valor", "Ideal", "Puntaje", "Impacto", "Qué hacer"),
            L.imp.take(10).map { r ->
                listOf<Any>(r.r.e.name, fv(r.r), fmtB(r.r.e.lo) + "–" + fmtB(r.r.e.hi) + unitOf(r.r.e), r.r.sc!!.toInt().toString(), "+" + f2(r.gain), TxtC(if (r.r.v!! < r.r.e.lo) r.r.e.tl else r.r.e.th))
            }, listOf(160, 80, 90, 70, 70, 300), rowH = 92
        )
    }
    Sec("Todas las estadísticas puntuadas") {
        Table(
            listOf("Categoría", "Stat", "Valor", "Ideal", "Puntaje", "Fiabilidad", "Peso"),
            L.R.filter { it.e.w > 0 }.map { r ->
                listOf<Any>(CATN[r.e.cat] ?: r.e.cat, r.e.name, fv(r), fmtB(r.e.lo) + "–" + fmtB(r.e.hi) + unitOf(r.e), if (r.sc == null) "muestra corta" else r.sc.toInt().toString(), (100 * r.r).toInt().toString() + "%", fmtB(r.e.w))
            }, listOf(140, 200, 80, 90, 90, 80, 60)
        )
    }
    Sec("Matemática de tus decisiones") {
        Muted("• Pot odds: equity requerida = pago / (bote + pago). Pagar ½ bote exige 25%; bote completo 33%.", 13)
        Muted("• MDF (defensa mínima) = bote / (bote + apuesta): vs ½ bote defiende ≥67%; vs bote ≥50%.", 13)
        Muted("• Fold equity mínima de un farol = apuesta / (bote + apuesta): una apuesta de ½ bote necesita que foldeen ≥33%.", 13)
        Muted("• M (Harrington) = stack / (SB+BB+antes). M<6: all-in o fold; M<10: poco margen para jugar postflop.", 13)
        if (mdf.isNotEmpty()) Muted("• Tus datos: " + mdf.joinToString(" · "), 13)
    }
    Sec("Qué se espera en cada nivel") { Table(listOf("Nivel", "Desde", "Perfil"), TIERS.map { listOf<Any>(it.name, it.lo, it.desc) }, listOf(130, 60, 420)) }
    Muted("Puntaje heurístico basado en estadísticas, no mide habilidad real. Con pocas manos, freerolls o torneos de campo suelto es orientativo.")
}

// ===================== PERFIL =====================
@Composable
fun TabPer(e: Env) {
    val hs = e.hs; val s = e.s
    val x = remember(hs, e.vm.evVer) { ctx(hs, s) }
    val b = B(s); val R_ = rows(s, x)
    fun r(id: String) = R_.first { it.e.id == id }
    val V = r("vpip").v ?: 0.0; val P = r("pfr").v ?: 0.0; val AF = r("af").v ?: 0.0
    val ty = if (V < 17 && P < 13) "Nit" to "Muy selectivo y pasivo: pierdes valor y eres fácil de leer."
    else if (V > 40 && P > 30) "Maniaco" to "Entras y subes con casi todo: alta varianza."
    else if (V > 30 && P < V - 12) "Calling station" to "Juegas mucho pagando: la mayor fuga típica."
    else if (V > 26 && P > 20) "LAG" to "Suelto-agresivo: correcto si el postflop lo respalda."
    else if (P >= V - 6 && V >= 17) "TAG" to "Tight-agresivo: perfil base sólido."
    else "Tight-pasivo" to "Selectivo pero con demasiados calls."
    val nc = hs.count { it.cards == null }
    Kpis(listOf(kp("Arquetipo", ty.first, ty.second), kp("bb/100", f1(b.m), "IC95% ±" + f1(b.ci), toneOf(b.m)), kp("Agresión post (AF)", f2(AF), "ref. 1.5–3")))
    for (c in CATN.keys) Sec(CATN[c]!!) { StatTbl(R_.filter { it.e.cat == c }) }
    Muted("«Inconcluso» = muestra insuficiente para decidir. bb/100 no corrige ICM ni la suerte en all-ins (ver All-ins & EV).")
    Sec("Calidad de datos") {
        Muted("${hs.size} manos · ${hs.map { it.tid }.toSet().size} torneos · $nc sin cartas de Hero · ${hs.count { it.sd == 1 }} con showdown · verificación de fichas: ${aud(hs)} (resultado de cada mano + stack = stack de la siguiente).")
    }
}

// ===================== PREFLOP =====================
@Composable
fun TabPre(e: Env) {
    val hs = e.hs; val s = e.s
    val x = remember(hs, e.vm.evVer) { ctx(hs, s) }
    val R_ = rows(s, x, listOf("Pre", "Torneo"))
    val B_ = listOf(Triple("≤8 bb", 0.0, 8.0), Triple("8–12", 8.0, 12.0), Triple("12–15", 12.0, 15.0), Triple("15–20", 15.0, 20.0), Triple("20–30", 20.0, 30.0), Triple("30+", 30.0, 1e9))
        .map { (l, a, b) -> val z = hs.filter { it.stack / it.bb > a - 1e-9 && it.stack / it.bb < b }; Triple(l, z, S(z)) }
    val PS = PO.map { p -> p to S(hs.filter { it.pos == p }) }
    val aiH = hs.filter { it.cvs == 1 }
    fun dfn(lab: String, f: String) = listOf<Any>(lab, fmtN(gc(s, f + "f_o")), q(s, f + "f_x", f + "f_o"), q(s, f + "c_x", f + "f_o"), q(s, f + "3_x", f + "f_o"))
    Kpis(
        listOf(
            kp("VPIP / PFR", q(s, "vpip_x", "vpip_o", 0) + " / " + q(s, "pfr_x", "pfr_o", 0)), kp("RFI", q(s, "rfi_x", "rfi_o")), kp("Steal", q(s, "stl_x", "stl_o")),
            kp("3-bet", q(s, "t3_x", "t3_o")), kp("Fold a 3-bet", q(s, "f3_x", "f3_o")), kp("4-bet", q(s, "b4_x", "b4_o")), kp("Open medio", f1(SR(SM["osz"]!!, s, x).v) + " bb")
        )
    )
    Sec("Estadísticas preflop") { StatTbl(R_) }
    Sec("Mezcla de acciones por posición") {
        StackedBars(PO, listOf(Triple("Fold", mixp(hs, 'f'), Color(0xFF4A3A41)), Triple("Check", mixp(hs, 'x'), Color(0xFF7A6A72)), Triple("Call / limp", mixp(hs, 'c'), PC.Wn), Triple("Raise", mixp(hs, 'r'), PC.Ac)))
    }
    Sec("Qué haces preflop") {
        Donut(
            listOf(
                Triple("Fold", pfc(hs, 'f', null), Color(0xFF4A3A41)), Triple("Check BB", pfc(hs, 'x', null), Color(0xFF7A6A72)), Triple("Limp", pfc(hs, 'c', false), Color(0xFFC9A24A)),
                Triple("Call", pfc(hs, 'c', true), PC.Wn), Triple("Open / raise", pfc(hs, 'r', false), PC.Ac), Triple("3-bet+", pfc(hs, 'r', true), Color(0xFFFF8FA3))
            ), fmtN(hs.size), "manos"
        )
    }
    Sec("Por posición") {
        Table(
            listOf("Pos", "Manos", "VPIP", "PFR", "RFI", "Limp", "3-bet", "Fold a open", "Fold a 3-bet", "Open medio", "bb/100"),
            PS.map { (p, z) ->
                listOf<Any>(p, z.n, q(z, "vpip_x", "vpip_o"), q(z, "pfr_x", "pfr_o"), q(z, "rfi_x", "rfi_o"), q(z, "lim_x", "lim_o"), q(z, "t3_x", "t3_o"), q(z, "ffo_x", "ffo_o"), q(z, "f3_x", "f3_o"),
                    if (gc(z, "osz_n_$p") > 0) f1(gc(z, "osz_s_$p") / gc(z, "osz_n_$p")) + " bb" else "–", nbc(B(z).m))
            }
        )
    }
    Sec("Defensa de ciegas vs robo (CO/BTN/SB abren)") {
        Table(listOf("Situación", "Casos", "Fold", "Call", "3-bet"), listOf(dfn("BB vs steal", "bb"), dfn("SB vs steal (CO/BTN)", "sb")), listOf(170, 70, 80, 80, 80))
    }
    Sec("Zonas de stack: push/fold") {
        Table(
            listOf("Stack", "Manos", "VPIP", "PFR", "RFI", "Open-shove*", "All-in", "bb/100"),
            B_.map { (l, z, t) -> listOf<Any>(l, t.n, q(t, "vpip_x", "vpip_o"), q(t, "pfr_x", "pfr_o"), q(t, "rfi_x", "rfi_o"), q(t, "shv_x", "shv_o"), pc(z.count { it.ai == 1 }.toDouble(), t.n.toDouble()), nbc(B(t).m)) }
        )
        Muted("*Open-shove: % de veces que, siendo primero en el bote con ≤15 bb, hiciste all-in.")
    }
    Sec("Cuando te hacen all-in preflop") {
        if (gc(s, "cvs_o") > 0) Kpis(listOf(kp("Casos", fmtN(gc(s, "cvs_o"))), kp("Pagaste", q(s, "cvs_x", "cvs_o")), kp("Neto bb en esas manos", f1(aiH.sumOf { it.nb }), "", toneOf(aiH.sumOf { it.nb }))))
        else Muted("Sin casos.")
    }
    Sec("Distribución de acciones preflop") {
        val n = max(hs.size, 1).toDouble()
        BarChart(listOf("Fold", "Check BB", "Limp", "Call", "Open/raise", "3-bet+"), listOf(pfc(hs, 'f', null), pfc(hs, 'x', null), pfc(hs, 'c', false), pfc(hs, 'c', true), pfc(hs, 'r', false), pfc(hs, 'r', true)).map { 100 * it / n }, true)
    }
    HandSec("All-ins preflop: tus mayores ganancias", byNb(hs.filter { it.ai == 1 && it.aiSt == "pre" }, 4, true))
    HandSec("All-ins preflop: tus mayores pérdidas", byNb(hs.filter { it.ai == 1 && it.aiSt == "pre" }, 4, false))
}

// ===================== POSTFLOP =====================
fun grp(hs: List<Hand>, label: String, fn: (Hand) -> Boolean): List<Any> {
    val z = hs.filter(fn); val t = S(z); val b = B(t)
    return listOf(label, t.n, q(t, "cb_x", "cb_o", 0), q(t, "fcb_x", "fcb_o", 0), q(t, "sd", "saw", 0), q(t, "wsd", "sd", 0), q(t, "wsf", "saw", 0), nbc(t.nb), nbc(b.m), f1(b.ci))
}

@Composable
fun TabPost(e: Env) {
    val hs = e.hs; val s = e.s
    val x = remember(hs, e.vm.evVer) { ctx(hs, s) }
    val R_ = rows(s, x, listOf("Post", "Mate"))
    val SG = listOf("Calle", "Apuestas+raises", "Calls", "Folds", "Checks", "AF", "AFq", "Fold a apuesta", "Call", "Raise", "Apuesta rival (% bote)", "MDF", "Equity req.", "Defiendes", "Tus apuestas (% bote)")
    val GH = listOf("Grupo", "Manos viendo flop", "C-bet", "Fold c-bet", "WTSD", "W\$SD", "WWSF", "Neto bb", "bb/100", "±IC")
    val sv = hs.filter { it.saw == 1 }
    val rS = SK.map { z ->
        val bb = gc(s, "ab_$z"); val c = gc(s, "ac_$z"); val f = gc(s, "af_$z"); val m = gc(s, "mdf_n_$z")
        listOf<Any>(
            z, bb.toInt(), c.toInt(), f.toInt(), gc(s, "ax_$z").toInt(), if (c > 0) f2(bb / c) else "–", if (bb + c + f > 0) pc(bb, bb + c + f) else "–",
            q(s, "fold_${z}_x", "fold_${z}_o"), q(s, "call_${z}_x", "call_${z}_o"), q(s, "raise_${z}_x", "raise_${z}_o"),
            if (gc(s, "osb_n_$z") > 0) f1(100 * gc(s, "osb_s_$z") / gc(s, "osb_n_$z")) + "%" else "–",
            if (m > 0) f1(100 * gc(s, "mdf_s_$z") / m) + "%" else "–", if (m > 0) f1(100 * gc(s, "req_s_$z") / m) + "%" else "–",
            if (m > 0) f1(100 * (1 - gc(s, "mf_x_$z") / m)) + "%" else "–", if (gc(s, "bsz_n_$z") > 0) f1(100 * gc(s, "bsz_s_$z") / gc(s, "bsz_n_$z")) + "%" else "–"
        )
    }
    val spr = listOf(Triple("≤3", 0.0, 3.0), Triple("3–6", 3.0, 6.0), Triple("6–13", 6.0, 13.0), Triple("13+", 13.0, 1e9))
    Kpis(
        listOf(
            kp("C-bet", q(s, "cb_x", "cb_o")), kp("Fold a C-bet", q(s, "fcb_x", "fcb_o")), kp("2º barril", q(s, "b2_x", "b2_o")), kp("3er barril", q(s, "b3_x", "b3_o")),
            kp("Check-raise flop", q(s, "xr_flop_x", "xr_flop_o")), kp("Donk", q(s, "dnk_x", "dnk_o")), kp("WTSD", q(s, "sd", "saw")), kp("W\$SD", q(s, "wsd", "sd")),
            kp("WWSF", q(s, "wsf", "saw")), kp("Gana sin showdown", pc(gc(s, "wnsd"), gc(s, "saw")), "de manos con flop")
        )
    )
    Sec("Estadísticas postflop y de sizing") { StatTbl(R_) }
    Sec("Por calle") { Table(SG, rS, SG.indices.map { if (it == 0) 70 else 100 }) }
    Sec("Embudo de manos") {
        val it0 = listOf("Manos repartidas" to s.n.toDouble(), "Entras al bote (VPIP)" to gc(s, "vpip_x"), "Ves el flop" to gc(s, "saw"), "Llegas a showdown" to gc(s, "sd"), "Ganas el showdown" to gc(s, "wsd"))
        val m = if (it0[0].second == 0.0) 1.0 else it0[0].second
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            it0.forEachIndexed { i, (l, v) ->
                Column {
                    Row { Text(l, color = PC.Tx, fontSize = 13.sp, modifier = Modifier.weight(1f)); Text(fmtN(v), fontWeight = FontWeight.SemiBold, color = PC.Tx, fontSize = 13.sp) }
                    Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(6.dp)).background(PC.P2)) {
                        Box(Modifier.fillMaxWidth((v / m).toFloat().coerceIn(0f, 1f)).height(14.dp).background(Brush.horizontalGradient(listOf(Color(0xFF8F1230), PC.Ac)), RoundedCornerShape(6.dp)))
                    }
                    Muted(if (i > 0) pc(v, it0[i - 1].second, 0) + " del paso previo" else "100%", 11)
                }
            }
        }
    }
    Sec("Embudo de barriles") {
        BarChart(listOf("C-bet", "2º barril", "3er barril"), listOf(100 * gc(s, "cb_x") / max(gc(s, "cb_o"), 1.0), 100 * gc(s, "b2_x") / max(gc(s, "b2_o"), 1.0), 100 * gc(s, "b3_x") / max(gc(s, "b3_o"), 1.0)), true)
    }
    Sec("Por tipo de bote") {
        Table(GH, listOf(grp(sv, "Limpeado") { it.pt == 0 }, grp(sv, "Single-raised") { it.pt == 1 }, grp(sv, "3-bet pot") { it.pt == 2 }, grp(sv, "4-bet+ pot") { it.pt >= 3 }), GH.indices.map { if (it == 0) 130 else 85 })
    }
    Sec("Posición y rivales") {
        Table(
            GH, listOf(grp(sv, "En posición") { it.ip == true }, grp(sv, "Fuera de posición") { it.ip == false }, grp(sv, "Heads-up") { it.nOpp == 1 }, grp(sv, "Multiway (2+ rivales)") { it.nOpp >= 2 },
                grp(sv, "Agresor preflop") { it.agg == 1 }, grp(sv, "Defensor / caller") { it.agg == 0 }), GH.indices.map { if (it == 0) 150 else 85 }
        )
    }
    Sec("Por SPR en flop (stack efectivo / bote)") {
        Table(GH, spr.map { (l, a, b) -> grp(sv, "SPR $l") { it.spr != null && it.spr!! >= a && it.spr!! < b } }, GH.indices.map { if (it == 0) 110 else 85 })
    }
    Sec("Apuestas cuando te pasan (flop/turn/river)") {
        Table(listOf("Calle", "Apuestas cuando pasan", "IP", "OOP"), SK.map { z -> listOf<Any>(z, q(s, "bt_${z}_x", "bt_${z}_o"), q(s, "bt_${z}_IP_x", "bt_${z}_IP_o"), q(s, "bt_${z}_OOP_x", "bt_${z}_OOP_o")) }, listOf(80, 150, 80, 80))
    }
    HandSec("Postflop: tus mayores ganancias", byNb(hs.filter { it.fs != "pre" }, 4, true))
    HandSec("Postflop: tus mayores pérdidas", byNb(hs.filter { it.fs != "pre" }, 4, false))
}

// ===================== ALL-INS & EV =====================
@Composable
fun TabEV(e: Env) {
    val hs = e.hs; val s = e.s; val vm = e.vm; val open = LocalOpen.current
    val ver = vm.evVer
    val A = hs.filter { it.ai == 1 }
    val E = remember(hs, ver) { evSum(hs) }
    val cov = hs.count { it.anyAI == 1 && it.ai == 0 }
    val sh = A.filter { it.aiK == 's' }; val ca = A.filter { it.aiK == 'c' }; val bl = A.filter { it.aiK == 'b' }
    val fe = sh.filter { it.aiCalled == 0 }
    fun win(z: List<Hand>) = z.count { it.net > 0 }
    fun tot(z: List<Hand>) = z.sumOf { it.nb }
    fun rowAI(lab: String, z: List<Hand>) = listOf<Any>(lab, z.size, if (z.isNotEmpty()) pc(win(z).toDouble(), z.size.toDouble(), 0) else "–", nbc(tot(z)), if (z.isNotEmpty()) nbc(tot(z) / z.size) else "–")
    val rs = ArrayList<List<Any>>()
    for (st in listOf("pre", "flop", "turn", "river")) {
        rs.add(rowAI("$st · shove", sh.filter { it.aiSt == st })); rs.add(rowAI("$st · call", ca.filter { it.aiSt == st }))
    }
    val Lh = remember(hs, ver) { hs.filter { it.eq != null }.sortedWith(CMP) }
    val S2 = remember(Lh) { Lh.sortedBy { it.eq!!.lk } }
    if (vm.evBusy) Note("Calculando EV de ${vm.evTotal} all-ins en segundo plano… ${vm.evDone}/${vm.evTotal}. La pantalla se actualizará sola.")
    Sec("Todos tus all-ins (con o sin cartas visibles)") {
        Kpis(
            listOf(
                kp("All-ins de Hero", A.size.toString(), pc(A.size.toDouble(), hs.size.toDouble()) + " de las manos"),
                kp("Como agresor (shove)", sh.size.toString(), "${fe.size} sin pago (${pc(fe.size.toDouble(), sh.size.toDouble(), 0)})"),
                kp("Pagando all-in", ca.size.toString()), kp("All-in en ciegas", bl.size.toString()),
                kp("Ganados (real)", pc(win(A).toDouble(), A.size.toDouble(), 0), "${win(A)} de ${A.size}"),
                kp("Neto en all-ins", f1(tot(A)), "bb", toneOf(tot(A))),
                kp("Rival all-in, tú cubres", cov.toString(), "tú pagaste con fichas restantes"),
                kp("Fold equity (shoves sin pago)", f1(tot(fe)), "bb ganados sin showdown", toneOf(tot(fe)))
            )
        )
        Spacer(Modifier.height(10.dp))
        Table(listOf("Tipo", "Manos", "Ganadas", "Neto bb", "bb/all-in"), rs.filter { (it[1] as Int) > 0 })
    }
    Sec("EV exacto con cartas conocidas (heads-up y multiway, con side pots)") {
        if (E.n > 0) {
            Kpis(
                listOf(
                    kp("All-ins con EV", E.n.toString(), "${E.unk} sin cartas rivales visibles"), kp("Ganados / esperados", "${E.w} / ${f1(E.x)}", "por equity"),
                    kp("Real (bb)", f1(E.real)), kp("EV (bb)", f1(E.ev), "lo que debías ganar"), kp("Suerte (bb)", f1(E.luck), "real − EV", toneOf(E.luck)),
                    kp("Suerte por all-in", f1(E.luck / E.n), "bb", toneOf(E.luck))
                )
            )
        } else Muted(if (E.pend > 0 || vm.evBusy) "Calculando…" else "No hay all-ins con las cartas de todos los jugadores visibles en esta selección.")
    }
    if (E.n > 0) {
        Sec("Real vs EV acumulado (bb)") {
            var a = 0.0; var ee = 0.0
            val Ar = ArrayList<Double>(); val Er = ArrayList<Double>()
            for (h in Lh) { a += h.nb; ee += h.eq!!.ev; Ar.add(a); Er.add(ee) }
            MultiLine(listOf(Ar, Er), listOf(PC.Ac, PC.Gr2), listOf("Real", "EV (ajustado por suerte)"))
        }
        Sec("Peor y mejor suerte") {
            val rowsL = S2.take(10) + S2.takeLast(10).reversed()
            Table(
                listOf("Tú", "Rivales", "Mesa al all-in", "Equity", "Real bb", "EV bb", "Suerte bb"),
                rowsL.map { h ->
                    val z = h.eq!!
                    listOf<Any>(CardsC(h.cards), z.pl.joinToString(" | ") { it.joinToString("") }, if (z.b.isEmpty()) "—" else z.b.joinToString(" "), f1(100 * z.e) + "%" + (if (z.exact) "" else "~"), nbc(h.nb), f1(z.ev), nbc(z.lk))
                },
                listOf(100, 130, 130, 80, 80, 80, 80), onRow = { open(rowsL[it].id) }
            )
            Muted("Equity con ~ = Monte Carlo (preflop); sin ~ = enumeración exacta de todas las runouts. EV = parte esperada de cada bote (incluye side pots) − fichas puestas. No incluye ICM.")
        }
    }
}
