package com.pokerlab

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.onSizeChanged as onSize
import kotlin.math.abs

/** Apariencia de una celda de la matriz 13x13. */
class RCell(
    val bg: Color = PC.P2,
    val segs: List<Pair<Color, Float>>? = null,
    val alpha: Float = 1f,
    val fill: Float = 0f,
    val fillColor: Color = PC.Ac,
    val label: String = "",
    val sub: String = "",
    val txt: Color = PC.Tx,
    val hot: Boolean = false
)

private fun cellAt(o: Offset, w: Int, h: Int): String? {
    if (w == 0 || h == 0) return null
    val c = (o.x / w * 13).toInt().coerceIn(0, 12)
    val r = (o.y / h * 13).toInt().coerceIn(0, 12)
    return classAt(r, c)
}

/** Matriz 13x13 (pares en la diagonal, suited arriba, offsuit abajo). */
@Composable
fun RangeGrid(
    cell: (String) -> RCell,
    selected: String? = null,
    mark: String? = null,
    onTap: (String) -> Unit = {},
    onDrag: ((String) -> Unit)? = null
) {
    val tm = rememberTextMeasurer()
    val tapCb by rememberUpdatedState(onTap)
    val dragCb by rememberUpdatedState(onDrag)
    var sz by remember { mutableStateOf(IntSize.Zero) }
    var m: Modifier = Modifier.fillMaxWidth().aspectRatio(1f).onSize { sz = it }
        .pointerInput(Unit) { detectTapGestures { o -> cellAt(o, sz.width, sz.height)?.let { tapCb(it) } } }
    if (onDrag != null) {
        m = m.pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { o -> cellAt(o, sz.width, sz.height)?.let { dragCb?.invoke(it) } },
                onDrag = { ch, _ -> ch.consume(); cellAt(ch.position, sz.width, sz.height)?.let { dragCb?.invoke(it) } }
            )
        }
    }
    Canvas(m) {
        val cw = size.width / 13f; val chh = size.height / 13f
        val gap = 1.2.dp.toPx(); val rr = CornerRadius(3.dp.toPx())
        for (i in 0 until 13) for (j in 0 until 13) {
            val z = classAt(i, j); val c = cell(z)
            val tl = Offset(j * cw + gap, i * chh + gap)
            val s2 = Size(cw - 2 * gap, chh - 2 * gap)
            drawRoundRect(c.bg, tl, s2, rr)
            if (c.segs != null) {
                val p = Path().apply { addRoundRect(RoundRect(tl.x, tl.y, tl.x + s2.width, tl.y + s2.height, rr)) }
                clipPath(p) {
                    var xx = tl.x
                    for ((col, f) in c.segs) {
                        val w = s2.width * f
                        if (w > 0.2f) drawRect(col.copy(alpha = c.alpha), Offset(xx, tl.y), Size(w + 0.5f, s2.height))
                        xx += w
                    }
                }
            }
            if (c.fill > 0f) {
                val p = Path().apply { addRoundRect(RoundRect(tl.x, tl.y, tl.x + s2.width, tl.y + s2.height, rr)) }
                clipPath(p) { drawRect(c.fillColor, Offset(tl.x, tl.y + s2.height * (1 - c.fill)), Size(s2.width, s2.height * c.fill)) }
            }
            if (c.hot) drawRoundRect(PC.Ac, tl, s2, rr, style = Stroke(1.5.dp.toPx()))
            if (z == mark) drawRoundRect(PC.Wn, tl, s2, rr, style = Stroke(2.dp.toPx()))
            if (z == selected) drawRoundRect(Color.White, tl, s2, rr, style = Stroke(2.dp.toPx()))
            if (c.label.isNotEmpty()) {
                txt(tm, c.label, j * cw + cw / 2, i * chh + chh * (if (c.sub.isEmpty()) .5f else .36f), TextStyle(fontSize = 9.sp, color = c.txt, fontWeight = FontWeight.Bold), 1)
                if (c.sub.isNotEmpty()) txt(tm, c.sub, j * cw + cw / 2, i * chh + chh * .74f, TextStyle(fontSize = 7.5.sp, color = c.txt.copy(alpha = .85f)), 1)
            }
        }
    }
}

/** Versión pequeña sin texto ni gestos (para comparar muchas matrices). */
@Composable
fun MiniGrid(cell: (String) -> RCell, modifier: Modifier = Modifier) {
    Canvas(modifier.aspectRatio(1f)) {
        val cw = size.width / 13f
        val gap = .6.dp.toPx()
        for (i in 0 until 13) for (j in 0 until 13) {
            val c = cell(classAt(i, j))
            val tl = Offset(j * cw + gap, i * cw + gap); val s2 = Size(cw - 2 * gap, cw - 2 * gap)
            drawRect(c.bg, tl, s2)
            if (c.segs != null) {
                var xx = tl.x
                for ((col, f) in c.segs) { val w = s2.width * f; if (w > 0.1f) drawRect(col.copy(alpha = c.alpha), Offset(xx, tl.y), Size(w, s2.height)); xx += w }
            }
            if (c.fill > 0f) drawRect(c.fillColor, Offset(tl.x, tl.y + s2.height * (1 - c.fill)), Size(s2.width, s2.height * c.fill))
        }
    }
}

@Composable
fun GradientLegend(lo: String, hi: String, c: Color) {
    Column {
        Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Brush.horizontalGradient(listOf(c.copy(alpha = .08f), c))))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(lo, color = PC.Mu, fontSize = 10.sp); Text(hi, color = PC.Mu, fontSize = 10.sp)
        }
    }
}

// ===================== editor de rangos =====================
private fun rep(z: String): List<String> =
    if (z.length == 2) listOf(z[0] + "h", z[1] + "d") else if (z[2] == 's') listOf(z[0] + "h", z[1] + "h") else listOf(z[0] + "h", z[1] + "d")

val STRENGTH: List<String> by lazy {
    GRID_CLASSES.sortedWith(
        compareByDescending<String> { chen(rep(it)) }
            .thenByDescending { it.length == 2 }
            .thenByDescending { it.length == 3 && it[2] == 's' }
            .thenBy { RK.indexOf(it[0]) }.thenBy { RK.indexOf(it[1]) }
    )
}

fun topPercent(p: Double): Map<String, Float> {
    val target = 1326 * p / 100
    var acc = 0.0
    val m = LinkedHashMap<String, Float>()
    for (z in STRENGTH) { if (acc >= target) break; m[z] = 1f; acc += clsSizeOf(z) }
    return m
}

private fun pick(f: (String) -> Boolean): Map<String, Float> = GRID_CLASSES.filter(f).associateWith { 1f }
private val BW = "AKQJT"

private val PRESETS: List<Pair<String, () -> Map<String, Float>>> = listOf(
    "Top 10%" to { topPercent(10.0) }, "Top 20%" to { topPercent(20.0) }, "Top 30%" to { topPercent(30.0) }, "Top 40%" to { topPercent(40.0) },
    "Pares" to { pick { it.length == 2 } }, "Broadways" to { pick { BW.indexOf(it[0]) >= 0 && BW.indexOf(it[1]) >= 0 } },
    "Axs" to { pick { it.length == 3 && it[0] == 'A' && it[2] == 's' } },
    "Suited conn." to { pick { it.length == 3 && it[2] == 's' && abs(RK.indexOf(it[0]) - RK.indexOf(it[1])) == 1 } },
    "Todo" to { pick { true } }, "Limpiar" to { emptyMap<String, Float>() }
)

@Composable
fun RangeEditor(title: String, text: String, onText: (String) -> Unit) {
    val map = remember(text) { parseClassRange(text) }
    var brush by remember { mutableStateOf(1f) }
    val combos = map.entries.sumOf { (clsSizeOf(it.key) * it.value).toDouble() }
    fun apply(z: String, toggle: Boolean) {
        val nm = LinkedHashMap(map)
        if (brush <= 0f) nm.remove(z)
        else if (toggle && map[z] == brush) nm.remove(z) else nm[z] = brush
        onText(classMapToText(nm))
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, fontWeight = FontWeight.SemiBold, color = PC.Tx, fontSize = 14.sp)
            Text(f1(combos) + " combos · " + f1(100 * combos / 1326) + "% del total", color = PC.Mu, fontSize = 12.sp)
        }
        RangeGrid(
            cell = { z ->
                val w = map[z] ?: 0f
                RCell(bg = PC.P2, fill = w, fillColor = PC.Ac.copy(alpha = .9f), label = z, txt = if (w > .5f) Color.White else PC.Mu)
            },
            onTap = { apply(it, true) }, onDrag = { apply(it, false) }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            listOf(1f to "Pintar 100%", .5f to "50%", .25f to "25%", 0f to "Borrar").forEach { (v, l) ->
                FilterChip(
                    selected = brush == v, onClick = { brush = v }, label = { Text(l) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PC.Ac, selectedLabelColor = Color.White)
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            PRESETS.forEach { (l, f) ->
                AssistChip(onClick = { onText(classMapToText(f())) }, label = { Text(l, fontSize = 12.sp) }, colors = AssistChipDefaults.assistChipColors(labelColor = PC.Tx))
            }
        }
        Muted("Toca o arrastra sobre la matriz para pintar. Pares en la diagonal, suited arriba y offsuit abajo. «Top N%» ordena por fuerza heurística (Chen), no por equity de solver.")
        Expand("Texto del rango") {
            OutlinedTextField(text, onText, minLines = 2, modifier = Modifier.fillMaxWidth(), textStyle = TextStyle(fontSize = 12.sp))
        }
    }
}

/** Selector de mesa: 4 palos x 13 rangos. */
@Composable
fun BoardPicker(board: String, onBoard: (String) -> Unit) {
    val cur = board.split(',', ' ').map { it.trim() }.filter { it.length == 2 }
    val ranks = "AKQJT98765432"
    val suits = listOf('s' to "♠", 'h' to "♥", 'd' to "♦", 'c' to "♣")
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        suits.forEach { (s, g) ->
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                ranks.forEach { r ->
                    val c = "" + r + s
                    val on = cur.contains(c)
                    val red = s == 'h' || s == 'd'
                    Box(
                        Modifier.weight(1f).aspectRatio(.8f).clip(RoundedCornerShape(4.dp))
                            .background(if (on) PC.Ac else PC.P2)
                            .pointerInput(c, cur) { detectTapGestures { onBoard((if (on) cur - c else if (cur.size < 5) cur + c else cur).joinToString(",")) } },
                        contentAlignment = androidx.compose.ui.Alignment.Center
                    ) {
                        Text((if (r == 'T') "10" else r.toString()) + g, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (on) Color.White else if (red) PC.Bd else PC.Tx, maxLines = 1)
                    }
                }
            }
        }
    }
}
