package com.pokerlab

import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Solver CFR+ heads-up para UNA calle (la mesa dada).
 * - Árbol: check / apuesta 50% del bote / all-in; ante apuesta: fold / call / all-in.
 * - Los valores en showdown usan la equity real contra el rango rival, promediada sobre todas las
 *   cartas que faltan (turn/river exacto, flop con muestra aleatoria de 160 runouts).
 * - No resuelve calles posteriores, ICM ni botes multiway.
 */
class ClsInfo(val frac: Double, val strat: DoubleArray, val combos: List<Pair<String, DoubleArray>>)

class SNode(
    val player: String, val title: String, val actions: List<String>, val cls: Map<String, ClsInfo>,
    val freq: DoubleArray, val combos: Double, val children: List<SNode?>
)

class SolveResult(
    val root: SNode, val nOop: Int, val nIp: Int, val iterations: Int, val pot: Double, val stack: Double,
    val board: List<String>, val eqOop: Double, val eqOopCls: Map<String, Double>, val eqIpCls: Map<String, Double>,
    val heroCombo: String?, val heroStrategy: DoubleArray?, val actions: List<String>
)

fun classAt(i: Int, j: Int): String =
    if (i == j) "" + RK[i] + RK[j] else if (i < j) "" + RK[i] + RK[j] + "s" else "" + RK[j] + RK[i] + "o"

val GRID_CLASSES: List<String> = (0 until 13).flatMap { i -> (0 until 13).map { j -> classAt(i, j) } }

fun clsSizeOf(k: String): Double = if (k.length == 2) 6.0 else if (k[2] == 's') 4.0 else 12.0

fun handClsName(c1: Int, c2: Int): String {
    val r1 = c1 shr 2; val r2 = c2 shr 2
    val a = max(r1, r2); val b = min(r1, r2)
    val ra = "23456789TJQKA"
    return if (a == b) "" + ra[a] + ra[a] else "" + ra[a] + ra[b] + (if ((c1 and 3) == (c2 and 3)) "s" else "o")
}

class SolverCancelled : RuntimeException()

private class Combo(val c1: Int, val c2: Int, var w: Double) {
    val name: String get() = cardName(c1) + cardName(c2)
}

private const val RANKS = "23456789TJQKA"
private const val SUITS = "cdhs"
private fun cardName(c: Int): String = "" + RANKS[c shr 2] + SUITS[c and 3]

private fun parseCard(s: String): Int {
    val r = RANKS.indexOf(s[0].uppercaseChar())
    val su = SUITS.indexOf(s[1].lowercaseChar())
    if (r < 0 || su < 0) throw IllegalArgumentException("Carta inválida: $s")
    return r * 4 + su
}

private fun parseRange(txt: String, blocked: Set<Int>): List<Combo> {
    val map = LinkedHashMap<Int, Combo>()
    fun add(a: Int, b: Int, w: Double) {
        if (blocked.contains(a) || blocked.contains(b) || a == b) return
        val lo = min(a, b); val hi = max(a, b)
        val key = lo * 52 + hi
        val ex = map[key]
        if (ex == null) map[key] = Combo(lo, hi, w) else ex.w = max(ex.w, w)
    }
    for (raw in txt.split(',', ' ', '\n', ';')) {
        var t = raw.trim()
        if (t.isEmpty()) continue
        var w = 1.0
        val ci = t.indexOf(':')
        if (ci >= 0) {
            w = t.substring(ci + 1).toDoubleOrNull() ?: throw IllegalArgumentException("Peso inválido en $t")
            t = t.substring(0, ci)
        }
        val plus = t.endsWith("+")
        if (plus) t = t.dropLast(1)
        if (t.length == 4 && SUITS.indexOf(t[1].lowercaseChar()) >= 0 && SUITS.indexOf(t[3].lowercaseChar()) >= 0) {
            add(parseCard(t.substring(0, 2)), parseCard(t.substring(2, 4)), w)
            continue
        }
        if (t.length < 2) throw IllegalArgumentException("Rango inválido: $raw")
        val r1 = RANKS.indexOf(t[0].uppercaseChar()); val r2 = RANKS.indexOf(t[1].uppercaseChar())
        if (r1 < 0 || r2 < 0) throw IllegalArgumentException("Rango inválido: $raw")
        val suf = t.getOrNull(2)?.lowercaseChar()
        if (r1 == r2) {
            for (r in r1..(if (plus) 12 else r1))
                for (s1 in 0 until 4) for (s2 in s1 + 1 until 4) add(r * 4 + s1, r * 4 + s2, w)
        } else {
            val hi = max(r1, r2); val lo = min(r1, r2)
            for (lr in lo..(if (plus) hi - 1 else lo)) {
                if (suf == null || suf == 's') for (s in 0 until 4) add(hi * 4 + s, lr * 4 + s, w)
                if (suf == null || suf == 'o') for (s1 in 0 until 4) for (s2 in 0 until 4) if (s1 != s2) add(hi * 4 + s1, lr * 4 + s2, w)
            }
        }
    }
    return map.values.toList()
}

/** Convierte un rango en texto a pesos por clase de mano (AA, AKs, AKo...). */
fun parseClassRange(txt: String): Map<String, Float> {
    val cs = try { parseRange(txt, emptySet()) } catch (e: Exception) { return emptyMap() }
    val sum = HashMap<String, Double>()
    for (c in cs) { val k = handClsName(c.c1, c.c2); sum[k] = (sum[k] ?: 0.0) + c.w }
    return sum.mapValues { min(1f, (it.value / clsSizeOf(it.key)).toFloat()) }
}

fun classMapToText(m: Map<String, Float>): String =
    GRID_CLASSES.filter { (m[it] ?: 0f) > 0.005f }.joinToString(",") {
        val w = m[it]!!
        if (w >= 0.995f) it else it + ":" + String.format(Locale.US, "%.2f", w)
    }

private class Node(val player: Int, val foldBy: Int, val fi: Double, val pot: Double) {
    var actions: List<String> = emptyList()
    var children: List<Node> = emptyList()
    var nh = 0
    var regret = DoubleArray(0)
    var sSum = DoubleArray(0)
}

private fun fmtAmt(x: Double) = String.format(Locale.US, "%.1f", x)

fun solveSpot(
    boardStr: String, pot: Double, stack: Double, ipStr: String, oopStr: String,
    iterations: Int, heroCards: List<String>?,
    onProgress: (Int) -> Unit, cancelled: () -> Boolean
): SolveResult {
    val bd = boardStr.split(',', ' ').map { it.trim() }.filter { it.isNotEmpty() }.map { parseCard(it) }
    if (bd.size !in 3..5 || bd.toSet().size != bd.size) throw IllegalArgumentException("La mesa debe tener de 3 a 5 cartas distintas (ej. Qs,Jh,2h).")
    if (pot <= 0 || stack <= 0) throw IllegalArgumentException("Bote y stack deben ser mayores que 0.")
    val blocked = bd.toSet()
    val oop = parseRange(oopStr, blocked)
    val ip = parseRange(ipStr, blocked)
    if (oop.isEmpty() || ip.isEmpty()) throw IllegalArgumentException("Un rango quedó vacío (¿cartas bloqueadas por la mesa?).")
    if (oop.size > 700 || ip.size > 700) throw IllegalArgumentException("Rangos demasiado grandes (máx. 700 combos cada uno).")
    val nO = oop.size; val nI = ip.size
    val iters = iterations.coerceIn(10, 3000)

    // ---- runouts ----
    val deck = (0 until 52).filter { !blocked.contains(it) }
    val need = 5 - bd.size
    val runs = ArrayList<IntArray>()
    when (need) {
        0 -> runs.add(IntArray(0))
        1 -> for (c in deck) runs.add(intArrayOf(c))
        else -> {
            val rnd = java.util.Random(12345)
            val seen = HashSet<Int>()
            while (runs.size < 160) {
                val a = deck[rnd.nextInt(deck.size)]; val b = deck[rnd.nextInt(deck.size)]
                if (a == b) continue
                val key = min(a, b) * 52 + max(a, b)
                if (seen.add(key)) runs.add(intArrayOf(a, b))
            }
        }
    }
    val R = runs.size
    fun ranks(cs: List<Combo>): Array<IntArray> = Array(cs.size) { i ->
        val c = cs[i]
        IntArray(R) { r ->
            val ru = runs[r]
            var bad = false
            for (x in ru) if (x == c.c1 || x == c.c2) bad = true
            if (bad) -1 else {
                val arr = IntArray(2 + bd.size + ru.size)
                arr[0] = c.c1; arr[1] = c.c2
                for (k in bd.indices) arr[2 + k] = bd[k]
                for (k in ru.indices) arr[2 + bd.size + k] = ru[k]
                ev7(arr)
            }
        }
    }
    val rO = ranks(oop); val rI = ranks(ip)
    val W = FloatArray(nO * nI)
    for (i in 0 until nO) {
        if (cancelled()) throw SolverCancelled()
        val a = oop[i]
        for (j in 0 until nI) {
            val b = ip[j]
            if (a.c1 == b.c1 || a.c1 == b.c2 || a.c2 == b.c1 || a.c2 == b.c2) continue
            var win = 0.0; var valid = 0
            val ro = rO[i]; val ri = rI[j]
            for (r in 0 until R) {
                val x = ro[r]; val y = ri[r]
                if (x < 0 || y < 0) continue
                valid++
                if (x > y) win += 1.0 else if (x == y) win += 0.5
            }
            W[i * nI + j] = if (valid > 0) (win / valid - 0.5).toFloat() else 0f
        }
    }
    val sameO = IntArray(nO) { i -> ip.indexOfFirst { it.c1 == oop[i].c1 && it.c2 == oop[i].c2 } }
    val sameI = IntArray(nI) { j -> oop.indexOfFirst { it.c1 == ip[j].c1 && it.c2 == ip[j].c2 } }
    val cO = Array(nO) { intArrayOf(oop[it].c1, oop[it].c2) }
    val cI = Array(nI) { intArrayOf(ip[it].c1, ip[it].c2) }

    // ---- árbol ----
    val p0 = pot
    fun showdown(xo: Double, xi: Double) = Node(-1, -1, 0.0, p0 + xo + xi)
    fun fold(by: Int, xf: Double) = Node(-1, by, p0 / 2 + xf, 0.0)
    fun mk(player: Int, acts: List<String>, ch: List<Node>): Node {
        val nd = Node(player, -1, 0.0, 0.0)
        nd.actions = acts; nd.children = ch
        nd.nh = if (player == 0) nO else nI
        nd.regret = DoubleArray(acts.size * nd.nh)
        nd.sSum = DoubleArray(acts.size * nd.nh)
        return nd
    }
    fun withX(player: Int, xo: Double, xi: Double, v: Double) = if (player == 0) Pair(v, xi) else Pair(xo, v)

    fun facing(player: Int, xo: Double, xi: Double): Node {
        // 'player' debe responder a una apuesta ya hecha (xo != xi)
        val mine = if (player == 0) xo else xi
        val theirs = if (player == 0) xi else xo
        val acts = ArrayList<String>(); val ch = ArrayList<Node>()
        acts.add("FOLD"); ch.add(fold(player, mine))
        acts.add("CALL"); ch.add(showdown(theirs, theirs))
        if (theirs < stack - 1e-9 && mine < stack - 1e-9) {
            acts.add("RAISE " + fmtAmt(stack))
            val (no, ni) = withX(player, xo, xi, stack)
            ch.add(facing(1 - player, no, ni))
        }
        return mk(player, acts, ch)
    }

    fun open(player: Int, xo: Double, xi: Double, checked: Boolean): Node {
        val cur = pot + xo + xi
        val rem = stack - max(xo, xi)
        val acts = ArrayList<String>(); val ch = ArrayList<Node>()
        acts.add("CHECK")
        ch.add(if (player == 0) open(1, xo, xi, true) else showdown(xo, xi))
        val b = 0.5 * cur
        if (b < rem - 1e-9 && b > 0.01) {
            acts.add("BET " + fmtAmt(b))
            val (no, ni) = withX(player, xo, xi, (if (player == 0) xo else xi) + b)
            ch.add(facing(1 - player, no, ni))
        }
        if (rem > 0.01) {
            acts.add("BET " + fmtAmt(stack))
            val (no, ni) = withX(player, xo, xi, stack)
            ch.add(facing(1 - player, no, ni))
        }
        return mk(player, acts, ch)
    }

    val root = open(0, 0.0, 0.0, false)

    // ---- CFR vectorial ----
    fun sumCompat(trav: Int, opp: DoubleArray): DoubleArray {
        val mine = if (trav == 0) cO else cI
        val theirs = if (trav == 0) cI else cO
        val same = if (trav == 0) sameO else sameI
        val rc = DoubleArray(52); var T = 0.0
        for (j in opp.indices) { rc[theirs[j][0]] += opp[j]; rc[theirs[j][1]] += opp[j]; T += opp[j] }
        return DoubleArray(mine.size) { i -> T - rc[mine[i][0]] - rc[mine[i][1]] + (if (same[i] >= 0) opp[same[i]] else 0.0) }
    }

    fun strat(nd: Node): DoubleArray {
        val a = nd.actions.size; val nh = nd.nh
        val s = DoubleArray(a * nh)
        for (h in 0 until nh) {
            var sum = 0.0
            for (k in 0 until a) sum += nd.regret[k * nh + h]
            if (sum > 1e-12) for (k in 0 until a) s[k * nh + h] = nd.regret[k * nh + h] / sum
            else for (k in 0 until a) s[k * nh + h] = 1.0 / a
        }
        return s
    }

    fun cfr(nd: Node, trav: Int, rT: DoubleArray, rO2: DoubleArray, t: Int): DoubleArray {
        if (nd.player == -1) {
            val nT = rT.size
            if (nd.foldBy == -1) {
                val u = DoubleArray(nT)
                if (trav == 0) {
                    for (i in 0 until nO) { var sum = 0.0; val base = i * nI; for (j in 0 until nI) sum += W[base + j] * rO2[j]; u[i] = nd.pot * sum }
                } else {
                    for (i in 0 until nO) { val ri = rO2[i]; if (ri == 0.0) continue; val base = i * nI; for (j in 0 until nI) u[j] -= nd.pot * W[base + j] * ri }
                }
                return u
            }
            val cs = sumCompat(trav, rO2)
            val sign = if (nd.foldBy == trav) -1.0 else 1.0
            return DoubleArray(nT) { sign * nd.fi * cs[it] }
        }
        val a = nd.actions.size; val nh = nd.nh
        val s = strat(nd)
        if (nd.player == trav) {
            val util = Array(a) { k ->
                val nr = DoubleArray(nh) { h -> rT[h] * s[k * nh + h] }
                cfr(nd.children[k], trav, nr, rO2, t)
            }
            val v = DoubleArray(nh)
            for (k in 0 until a) for (h in 0 until nh) v[h] += s[k * nh + h] * util[k][h]
            for (k in 0 until a) for (h in 0 until nh) {
                val idx = k * nh + h
                nd.regret[idx] = max(0.0, nd.regret[idx] + util[k][h] - v[h])
                nd.sSum[idx] += t * rT[h] * s[idx]
            }
            return v
        }
        val v = DoubleArray(rT.size)
        for (k in 0 until a) {
            val no = DoubleArray(nh) { h -> rO2[h] * s[k * nh + h] }
            val u = cfr(nd.children[k], trav, rT, no, t)
            for (h in u.indices) v[h] += u[h]
        }
        return v
    }

    val wO = DoubleArray(nO) { oop[it].w }
    val wI = DoubleArray(nI) { ip[it].w }
    for (t in 1..iters) {
        if (cancelled()) throw SolverCancelled()
        cfr(root, 0, wO, wI, t)
        cfr(root, 1, wI, wO, t)
        if (t % 5 == 0 || t == iters) onProgress(t)
    }

    // ---- equity de rangos ----
    var eNum = 0.0; var eDen = 0.0
    val eO = DoubleArray(nO); val eI = DoubleArray(nI); val dO = DoubleArray(nO); val dI = DoubleArray(nI)
    for (i in 0 until nO) for (j in 0 until nI) {
        val a1 = oop[i]; val b1 = ip[j]
        if (a1.c1 == b1.c1 || a1.c1 == b1.c2 || a1.c2 == b1.c1 || a1.c2 == b1.c2) continue
        val e = W[i * nI + j] + 0.5
        val w = wO[i] * wI[j]
        eNum += w * e; eDen += w
        eO[i] += wI[j] * e; dO[i] += wI[j]
        eI[j] += wO[i] * (1 - e); dI[j] += wO[i]
    }
    fun clsEq(cs: List<Combo>, e: DoubleArray, d: DoubleArray, w: DoubleArray): Map<String, Double> {
        val n = HashMap<String, Double>(); val m = HashMap<String, Double>()
        for (h in cs.indices) {
            if (d[h] <= 0) continue
            val k = handClsName(cs[h].c1, cs[h].c2)
            n[k] = (n[k] ?: 0.0) + w[h] * e[h] / d[h]; m[k] = (m[k] ?: 0.0) + w[h]
        }
        return n.mapValues { it.value / m[it.key]!! }
    }

    // ---- árbol de estrategias promedio ----
    fun snode(nd: Node, reO: DoubleArray, reI: DoubleArray, title: String): SNode? {
        if (nd.player == -1) return null
        val a = nd.actions.size; val nh = nd.nh
        val own = if (nd.player == 0) oop else ip
        val reach = if (nd.player == 0) reO else reI
        val st = Array(nh) { h ->
            var sum = 0.0
            for (k in 0 until a) sum += nd.sSum[k * nh + h]
            DoubleArray(a) { k -> if (sum > 0) 100.0 * nd.sSum[k * nh + h] / sum else 100.0 / a }
        }
        val kids = (0 until a).map { k ->
            val nr = DoubleArray(nh) { h -> reach[h] * st[h][k] / 100.0 }
            if (nd.player == 0) snode(nd.children[k], nr, reI, nd.actions[k]) else snode(nd.children[k], reO, nr, nd.actions[k])
        }
        val groups = LinkedHashMap<String, ArrayList<Int>>()
        for (h in 0 until nh) groups.getOrPut(handClsName(own[h].c1, own[h].c2)) { ArrayList() }.add(h)
        val cls = LinkedHashMap<String, ClsInfo>()
        for ((k, idx) in groups) {
            val tot = idx.sumOf { reach[it] }
            val sv = DoubleArray(a) { j -> if (tot > 1e-12) idx.sumOf { reach[it] * st[it][j] } / tot else idx.sumOf { st[it][j] } / idx.size }
            cls[k] = ClsInfo(min(1.0, tot / clsSizeOf(k)), sv, idx.map { own[it].name to st[it] })
        }
        val totR = reach.sum()
        val freq = DoubleArray(a) { j -> if (totR > 1e-12) (0 until nh).sumOf { reach[it] * st[it][j] } / totR else 100.0 / a }
        return SNode(if (nd.player == 0) "OOP" else "IP", title, nd.actions, cls, freq, totR, kids)
    }
    val sroot = snode(root, wO, wI, "Inicio")!!

    val a = root.actions.size
    var hero: DoubleArray? = null
    var heroCombo: String? = null
    if (heroCards != null && heroCards.size == 2) {
        val h1 = parseCard(heroCards[0]); val h2 = parseCard(heroCards[1])
        val idx = oop.indexOfFirst { (it.c1 == min(h1, h2) && it.c2 == max(h1, h2)) }
        if (idx >= 0) {
            var sum = 0.0
            for (k in 0 until a) sum += root.sSum[k * nO + idx]
            hero = DoubleArray(a) { k -> if (sum > 0) 100.0 * root.sSum[k * nO + idx] / sum else 100.0 / a }
            heroCombo = oop[idx].name
        }
    }
    return SolveResult(
        sroot, nO, nI, iters, pot, stack, bd.map { cardName(it) }, if (eDen > 0) eNum / eDen else 0.5,
        clsEq(oop, eO, dO, wO), clsEq(ip, eI, dI, wI), heroCombo, hero, root.actions
    )
}

fun abs2(x: Double) = abs(x)
