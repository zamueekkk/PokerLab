package com.pokerlab

import kotlin.math.max
import kotlin.math.min

fun CI(x: String): Int = "23456789TJQKA".indexOf(x[0]) * 4 + "cdhs".indexOf(x[1])

private fun straightTop(m: Int): Int {
    val q = (m shl 1) or ((m shr 12) and 1)
    for (h in 13 downTo 4) if (((q shr (h - 4)) and 31) == 31) return h - 1
    return -1
}

private fun pk(a: IntArray): Int {
    var v = 0
    for (x in a) v = v * 13 + x
    return v
}

/** Evalúa 7 cartas (índices 0..51 = rango*4+palo). Mayor = mejor. */
fun ev7(c: IntArray): Int {
    val rc = IntArray(13); val sc = IntArray(4); val sr = IntArray(4)
    for (x in c) {
        val r = x shr 2; val s = x and 3
        rc[r]++; sc[s]++; sr[s] = sr[s] or (1 shl r)
    }
    var f = -1
    for (i in 0 until 4) if (sc[i] >= 5) { f = i; break }
    if (f >= 0) {
        val s = straightTop(sr[f])
        if (s >= 0) return 80_000_000 + s
    }
    val g = ArrayList<IntArray>()
    for (r in 12 downTo 0) if (rc[r] > 0) g.add(intArrayOf(rc[r], r))
    g.sortWith { a, b -> if (b[0] != a[0]) b[0] - a[0] else b[1] - a[1] }
    val n = g[0][0]
    val n2 = if (g.size > 1) g[1][0] else 0
    if (n == 4) {
        var k = 0
        for (i in 1 until g.size) k = max(k, g[i][1])
        return 70_000_000 + pk(intArrayOf(g[0][1], k))
    }
    if (n == 3 && n2 >= 2) return 60_000_000 + pk(intArrayOf(g[0][1], g[1][1]))
    if (f >= 0) {
        val a = ArrayList<Int>()
        var r = 12
        while (r >= 0 && a.size < 5) { if (((sr[f] shr r) and 1) == 1) a.add(r); r-- }
        return 50_000_000 + pk(a.toIntArray())
    }
    var m = 0
    for (r in 0 until 13) if (rc[r] > 0) m = m or (1 shl r)
    val s = straightTop(m)
    if (s >= 0) return 40_000_000 + s
    if (n == 3) return 30_000_000 + pk(intArrayOf(g[0][1], g[1][1], g[2][1]))
    if (n == 2 && n2 == 2) {
        var k = 0
        for (i in 2 until g.size) k = max(k, g[i][1])
        return 20_000_000 + pk(intArrayOf(g[0][1], g[1][1], k))
    }
    if (n == 2) return 10_000_000 + pk(intArrayOf(g[0][1], g[1][1], g[2][1], g[3][1]))
    return pk(IntArray(5) { g[it][1] })
}

class EqCalc(val share: Double, val eq: Double, val exact: Boolean)
private class Layer(var amt: Double, val el: List<String>)

fun evMulti(
    act: List<String>, cards: Map<String, List<String>>, inv: Map<String, Double>,
    bd: IntArray, N: Int, seed: Int
): EqCalc? {
    var sd = seed
    fun rnd(): Double {
        sd += 0x6D2B79F5
        var t = (sd xor (sd ushr 15)) * (1 or sd)
        t = (t + (t xor (t ushr 7)) * (61 or t)) xor t
        return ((t xor (t ushr 14)).toLong() and 0xFFFFFFFFL).toDouble() / 4294967296.0
    }
    val hc = HashMap<String, IntArray>()
    for (p in act) hc[p] = (cards[p] ?: return null).map { CI(it) }.toIntArray()
    val used = HashSet<Int>()
    for (x in bd) used.add(x)
    for (p in act) for (c in hc[p]!!) used.add(c)
    if (used.size != bd.size + act.size * 2) return null
    val dk = (0 until 52).filter { !used.contains(it) }.toIntArray()
    val all = inv.keys.toList()
    val lv = act.map { inv[it] ?: 0.0 }.filter { it > 0 }.distinct().sorted()
    val lay = ArrayList<Layer>()
    var prev = 0.0
    for (Lv in lv) {
        var amt = 0.0
        for (p in all) {
            val ip = inv[p] ?: 0.0
            amt += max(0.0, min(ip, Lv) - min(ip, prev))
        }
        lay.add(Layer(amt, act.filter { (inv[it] ?: 0.0) >= Lv }))
        prev = Lv
    }
    var ex = 0.0
    for (p in all) if (!act.contains(p)) ex += max(0.0, (inv[p] ?: 0.0) - prev)
    if (lay.isEmpty()) return null
    lay[lay.size - 1].amt += ex
    val need = 5 - bd.size
    var share = 0.0
    var cnt = 0
    val hole = IntArray(7)
    fun run(extra: IntArray) {
        val b = bd + extra
        val r = HashMap<String, Int>()
        for (p in act) {
            val h = hc[p]!!
            hole[0] = h[0]; hole[1] = h[1]
            for (i in b.indices) hole[2 + i] = b[i]
            r[p] = ev7(hole.copyOf(2 + b.size))
        }
        for (l in lay) {
            var best = -1
            val w = ArrayList<String>()
            for (p in l.el) {
                val v = r[p]!!
                if (v > best) { best = v; w.clear(); w.add(p) } else if (v == best) w.add(p)
            }
            if (w.contains("Hero")) share += l.amt / w.size
        }
        cnt++
    }
    when (need) {
        0 -> run(IntArray(0))
        1 -> for (a in dk) run(intArrayOf(a))
        2 -> for (i in dk.indices) for (j in i + 1 until dk.size) run(intArrayOf(dk[i], dk[j]))
        else -> for (t in 0 until N) {
            val e = IntArray(need)
            for (i in 0 until need) {
                val j = i + Math.floor(rnd() * (dk.size - i)).toInt()
                val tmp = dk[i]; dk[i] = dk[j]; dk[j] = tmp
                e[i] = dk[i]
            }
            run(e)
        }
    }
    val T = lay.sumOf { it.amt }
    return EqCalc(share / cnt, share / cnt / T, need <= 2)
}

fun evh(h: Hand): EqRes? {
    if (h.eqDone) return h.eq
    var res: EqRes? = null
    val d = h.evd
    if (d != null && d.act.all { d.cards[it] != null }) {
        val nb = when (d.st) { "pre" -> 0; "flop" -> 3; "turn" -> 4; else -> 5 }
        val bd = d.board.take(nb)
        if (bd.size >= nb) {
            val seed = (h.id.toLongOrNull() ?: 1L) % 4294967291L
            val r = evMulti(d.act, d.cards, d.inv, bd.map { CI(it) }.toIntArray(), if (d.act.size == 2) 12000 else 8000, seed.toInt())
            if (r != null) {
                val ev = (r.share - (d.inv["Hero"] ?: 0.0)) / h.bb
                res = EqRes(r.eq, ev, h.nb - ev, d.act.filter { it != "Hero" }.map { d.cards[it]!! }, bd, d.st, d.act.size, r.exact)
            }
        }
    }
    h.eq = res
    h.eqDone = true
    return res
}

class EvSum(val n: Int, val real: Double, val ev: Double, val pend: Int, val unk: Int, val w: Int, val x: Double) {
    val luck: Double get() = real - ev
}

fun evSum(hs: List<Hand>): EvSum {
    var n = 0; var real = 0.0; var ev = 0.0; var pend = 0; var unk = 0; var w = 0; var x = 0.0
    for (h in hs) {
        if (h.evd == null) continue
        if (!h.eqDone) { pend++; continue }
        val e = h.eq
        if (e == null) { unk++; continue }
        n++; real += h.nb; ev += e.ev
        if (h.nb > 0) w++
        x += e.e
    }
    return EvSum(n, real, ev, pend, unk, w, x)
}
