package com.pokerlab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { PokerLabTheme { AppRoot() } }
    }
}

@Composable
fun TabBody(id: String, e: Env) {
    when (id) {
        "res" -> TabRes(e)
        "seg" -> TabSeg(e)
        "niv" -> TabNiv(e)
        "per" -> TabPer(e)
        "pre" -> TabPre(e)
        "post" -> TabPost(e)
        "ev" -> TabEV(e)
        "solver" -> TabSolver(e)
        "fug" -> TabFug(e)
        "rev" -> TabRev(e)
        "tor" -> TabTor(e)
        "ran" -> TabRan(e)
        "pos" -> TabPos(e)
        "pat" -> TabPat(e)
        "man" -> TabMan(e)
        "hnd" -> TabHnd(e)
        "riv" -> TabRiv(e)
        "gra" -> TabGra(e)
        "av" -> TabAv(e)
        "cla" -> TabCl(e)
    }
}

private val CL = linkedMapOf("all" to "Todo", "7" to "7 días", "30" to "30 días", "90" to "90 días", "mes" to "Este mes", "c" to "Personalizado")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot() {
    val vm: MainVm = viewModel()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.importUris(it) }
    val export = rememberCsvExporter()
    var menu by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var editName by remember { mutableStateOf(false) }
    val pick = { picker.launch(arrayOf("text/plain", "*/*")) }

    BackHandler(enabled = vm.tour != null || drawer.isOpen) {
        if (drawer.isOpen) scope.launch { drawer.close() } else vm.tour = null
    }

    CompositionLocalProvider(LocalOpen provides { id -> vm.openReplay(id) }) {
        ModalNavigationDrawer(
            drawerState = drawer,
            drawerContent = {
                ModalDrawerSheet(drawerContainerColor = PC.P) {
                    Column(Modifier.verticalScroll(rememberScrollState()).padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(8.dp)) {
                            Box(Modifier.size(36.dp).clip(RoundedCornerShape(9.dp)).background(PC.Ac), contentAlignment = Alignment.Center) { Text("♠", color = Color.White, fontSize = 20.sp) }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("Poker Lab", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = PC.Tx)
                                Muted("Análisis de torneos CoinPoker")
                            }
                        }
                        val items = if (vm.H.isEmpty()) TABS.filterKeys { it == "solver" } else TABS
                        items.forEach { (k, v) ->
                            GROUPS[k]?.let { if (vm.H.isNotEmpty()) Text(it, color = PC.Mu.copy(alpha = .8f), fontSize = 12.sp, modifier = Modifier.padding(start = 14.dp, top = 14.dp, bottom = 2.dp)) }
                            NavigationDrawerItem(
                                label = { Text(v) }, selected = vm.tab == k && vm.tour == null,
                                onClick = { vm.tab = k; vm.tour = null; scope.launch { drawer.close() } },
                                colors = NavigationDrawerItemDefaults.colors(selectedContainerColor = PC.P2, unselectedContainerColor = Color.Transparent, selectedTextColor = PC.Tx, unselectedTextColor = PC.Mu)
                            )
                        }
                    }
                }
            }
        ) {
            Scaffold(
                containerColor = PC.Bg,
                topBar = {
                    TopAppBar(
                        title = { Text(if (vm.tour != null) "Torneo" else TABS[vm.tab] ?: "", fontWeight = FontWeight.SemiBold) },
                        navigationIcon = { IconButton(onClick = { scope.launch { drawer.open() } }) { Text("☰", fontSize = 20.sp, color = PC.Tx) } },
                        actions = {
                            IconButton(onClick = pick) { Text("＋", fontSize = 22.sp, color = PC.Ac) }
                            Box {
                                IconButton(onClick = { menu = true }) { Text("⋮", fontSize = 20.sp, color = PC.Tx) }
                                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                    DropdownMenuItem(text = { Text("Cargar historial (.txt)") }, onClick = { menu = false; pick() })
                                    if (vm.H.isNotEmpty()) {
                                        DropdownMenuItem(text = { Text("⬇ Exportar CSV (filtro actual)") }, onClick = { menu = false; export(vm.filtered()) })
                                        DropdownMenuItem(text = { Text("Editar perfil") }, onClick = { menu = false; editName = true })
                                        DropdownMenuItem(text = { Text("Borrar historial guardado") }, onClick = { menu = false; confirmClear = true })
                                    }
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = PC.Bg, titleContentColor = PC.Tx)
                    )
                }
            ) { pad ->
                Column(Modifier.padding(pad).fillMaxSize()) {
                    if (vm.importing) LinearProgressIndicator(Modifier.fillMaxWidth(), color = PC.Ac, trackColor = PC.P2)
                    when {
                        vm.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = PC.Ac) }
                        vm.H.isEmpty() && vm.tab != "solver" -> EmptyState(onPick = pick, onSolver = { vm.tab = "solver" })
                        else -> Content(vm)
                    }
                }
            }
        }

        val rid = vm.replayId
        if (rid != null) {
            val h = vm.H.find { it.id == rid }
            if (h != null) ReplayDialog(h, { vm.replayId = null }) { hh, d, i -> vm.sendToSolver(hh, d, i) }
        }
        if (vm.askName || editName) NameDialog(vm, editName) { editName = false }
        if (confirmClear) AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Borrar historial") },
            text = { Text("Se eliminarán las manos guardadas en este dispositivo. Tus archivos .txt originales no se tocan.") },
            confirmButton = { TextButton(onClick = { vm.clearAll(); confirmClear = false }) { Text("Borrar") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun Content(vm: MainVm) {
    val scroll = rememberScrollState()
    LaunchedEffect(vm.tab, vm.tour, vm.tt) { scroll.scrollTo(0) }
    Column(Modifier.fillMaxSize()) {
        if (vm.tour == null && vm.H.isNotEmpty()) FilterBar(vm)
        Column(
            Modifier.weight(1f).verticalScroll(scroll).padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            val t = vm.tour
            if (t != null) TourScreen(vm, t) else MainTab(vm)
            if (t == null && vm.H.isNotEmpty()) PagerNav(vm)
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun MainTab(vm: MainVm) {
    val seg = vm.tab == "seg"
    val fh = remember(vm.H, vm.sel, vm.dr, seg) { vm.filtered() }
    val s = remember(fh) { S(fh) }
    if (vm.tab == "solver") TabSolver(Env(vm, fh, s))
    else if (fh.isEmpty()) Muted("Sin manos en este filtro.")
    else TabBody(vm.tab, Env(vm, fh, s))
}

@Composable
private fun FilterBar(vm: MainVm) {
    val T = remember(vm.H) { tours(vm.H) }
    val opts = remember(T, vm.H.size) {
        listOf("all" to "Todos (${vm.H.size} manos)", "fr" to "Solo freerolls", "pd" to "Solo con buy-in") + T.map { it.id to (it.name.take(30) + " · " + it.id + " (" + it.hs.size + ")") }
    }
    Column(Modifier.padding(horizontal = 14.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically, modifier = Modifier.horizontalScroll(rememberScrollState())) {
            Drop("Torneo: ", opts, vm.sel) { vm.sel = it }
            if (vm.tab != "seg") {
                CL.forEach { (k, v) ->
                    FilterChip(
                        selected = vm.dr.m == k, onClick = { vm.dr = Rng(k, vm.dr.f, vm.dr.t) }, label = { Text(v) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PC.Ac, selectedLabelColor = Color.White)
                    )
                }
                if (vm.dr.m == "c") {
                    DateField("Desde", vm.dr.f) { vm.dr = Rng("c", it, vm.dr.t) }
                    DateField("Hasta", vm.dr.t) { vm.dr = Rng("c", vm.dr.f, it) }
                }
            }
        }
    }
}

@Composable
private fun PagerNav(vm: MainVm) {
    val ks = TABS.keys.toList()
    val ix = ks.indexOf(vm.tab)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        OutlinedButton(onClick = { vm.tab = ks[(ix + ks.size - 1) % ks.size] }) { Text("← " + TABS[ks[(ix + ks.size - 1) % ks.size]], fontSize = 12.sp, maxLines = 1) }
        OutlinedButton(onClick = { vm.tab = ks[(ix + 1) % ks.size] }) { Text(TABS[ks[(ix + 1) % ks.size]] + " →", fontSize = 12.sp, maxLines = 1) }
    }
}

@Composable
private fun EmptyState(onPick: () -> Unit, onSolver: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(88.dp).clip(RoundedCornerShape(24.dp)).background(PC.Ac), contentAlignment = Alignment.Center) { Text("♠", color = Color.White, fontSize = 48.sp) }
        Spacer(Modifier.height(20.dp))
        Text("Poker Lab", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = PC.Tx)
        Spacer(Modifier.height(6.dp))
        Text(
            "Carga tu historial de manos de CoinPoker (.txt). Todo se procesa en tu teléfono; no se sube nada.",
            color = PC.Mu, textAlign = TextAlign.Center, fontSize = 14.sp
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onPick, colors = ButtonDefaults.buttonColors(containerColor = PC.Ac)) { Text("Cargar historial (.txt)") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onSolver) { Text("Solver CFR heads-up") }
    }
}

@Composable
private fun NameDialog(vm: MainVm, edit: Boolean, onDone: () -> Unit) {
    var v by remember { mutableStateOf(vm.uname) }
    AlertDialog(
        onDismissRequest = { vm.skipName(); onDone() },
        title = { Text(if (edit) "Tu perfil" else "Bienvenido a Poker Lab") },
        text = {
            Column {
                Text("¿Cómo quieres que te llame?", color = PC.Mu)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(v, { v = it.take(24) }, singleLine = true, placeholder = { Text("Tu nombre") })
            }
        },
        confirmButton = { TextButton(onClick = { vm.setName(v.ifBlank { "Jugador" }); onDone() }) { Text("Entrar a la mesa") } },
        dismissButton = { TextButton(onClick = { vm.skipName(); onDone() }) { Text("Omitir") } }
    )
}
